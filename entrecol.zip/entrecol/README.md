# EntreCOL+ — Sistema de nómina, películas, libros y reportes

Aplicación web en PHP 8, MySQL 8 / MariaDB, HTML5, CSS3, JavaScript (Fetch API), Bootstrap 5 y Chart.js. Todo se ejecuta desde el navegador en `http://localhost/entrecol/`. No requiere Python, Node.js ni aplicaciones de escritorio.

## 1. Requisitos

- XAMPP con Apache y MySQL (o MariaDB) activos.
- PHP 8.1 o superior.
- Extensiones PHP habilitadas: `gd`, `pdo_mysql`, `mbstring`, `zip`, `openssl`.
- Composer (para instalar Dompdf).
- MySQL Workbench (para importar la base de datos).

## 2. Montar el proyecto

1. Copie la carpeta `entrecol` dentro de `C:\xampp\htdocs\` para que quede en `C:\xampp\htdocs\entrecol`.
2. Abra una terminal en `C:\xampp\htdocs\entrecol` y ejecute:

```
composer install
```

Al terminar debe existir la carpeta `vendor` con el archivo `vendor\autoload.php`. Dompdf es la librería que genera los PDF de los reportes.

## 3. Configurar PHP (php.ini)

Abra `C:\xampp\php\php.ini` (o desde el panel de XAMPP: Apache → Config → PHP (php.ini)) y verifique o cambie:

```
extension=gd
extension=pdo_mysql
extension=mbstring
extension=zip
extension=openssl
upload_max_filesize = 25M
post_max_size = 25M
```

Importante: el valor por defecto de XAMPP para `upload_max_filesize` es 2 MB. El archivo `Books.json` supera ese tamaño, por eso debe quedar en 25M. Después de guardar, reinicie Apache desde el panel de XAMPP.

## 4. Crear la base de datos

1. Abra MySQL Workbench y conéctese a la instancia local (usuario `root`).
2. Menú **File → Open SQL Script…** y seleccione `entrecol\sql\entrecol.sql`.
3. Presione el botón de rayo (**Execute**).

El script crea la base `entrecol`, todas las tablas, las restricciones, los datos iniciales (nómina, películas, libros), el usuario de la aplicación `entrecol_app` y el usuario administrador. Si vuelve a ejecutarlo, reemplaza la base anterior.

La aplicación se conecta con el usuario `entrecol_app`. Su contraseña está en `config\database.php` (constante `DB_CLAVE`), igual que los demás parámetros de conexión.

## 5. Iniciar y entrar

1. En XAMPP inicie **Apache** y **MySQL**.
2. Abra `http://localhost/entrecol/`.
3. Ingrese con:
   - Usuario: `admin`
   - Contraseña: `Admin.EntreCOL2026`
4. Resuelva el CAPTCHA (código de 5 caracteres) e ingrese.

Después del primer ingreso cambie la contraseña desde **Mi cuenta** (menú de su usuario en la barra superior). Debe escribir la contraseña actual, y la nueva debe tener mínimo 10 caracteres, letras y números.

El botón de la luna en la barra superior activa el **modo oscuro**. La preferencia se guarda en el navegador.

## 6. Doble factor de autenticación (2FA)

1. En el menú de su usuario (barra superior) elija **Seguridad (2FA)**.
2. Presione **Iniciar configuración** y escanee el código QR con Google Authenticator o Microsoft Authenticator (o escriba la clave manualmente).
3. Ingrese el código de 6 dígitos que muestra la aplicación y confirme.
4. Guarde los 8 códigos de recuperación. Cada código sirve una sola vez si pierde el teléfono.

A partir de ese momento, cada ingreso pide además el código de la aplicación.

## 7. Módulos

| Módulo | Qué hace |
|---|---|
| Inicio | Totales de empleados, películas y libros, y tres gráficos: empleados por dependencia, salario promedio por cargo y películas por año. |
| Nómina | Listado con filtros por nombre, dependencia, cargo, EPS, pensión, ARL, fecha de ingreso y rango de salario, y orden por código, nombre, ingreso, salario o dependencia. Botón **Exportar CSV** (descarga el listado con los filtros aplicados). Alta, edición y eliminación de empleados. Botón **Catálogos** para dependencias, cargos, EPS, fondos de pensión y ARL. |
| Novedades | Pestaña **Registros**: novedades por periodo, con filtros por periodo, nombre, dependencia y días mínimos de incapacidad o vacaciones. Pestaña **Novedades pendientes**: empleados activos sin novedad en el periodo elegido (consulta de solo lectura), con exportación CSV y acceso directo para registrarles la novedad. |
| Películas | Filtros por título, género, rango de años y orden por título, año o ID. Paginación, botón **Exportar CSV**, alta, edición y eliminación. |
| Libros | Filtros por título o autor, editorial, idioma, calificación mínima y máxima, años y fechas de publicación, páginas y orden por título, calificación, reseñas, año o páginas. Paginación, botón **Exportar CSV**, alta, edición y eliminación. |
| Importar | Carga de archivos XLSX (nómina y novedades), DAT (películas) y JSON (libros), con validación, detección de duplicados e informe por registro. Historial de importaciones con filtros por tipo, usuario, archivo y fechas. |
| Reportes | Nómina, información personal, salud y pensión, novedades, entretenimiento, libros, salario promedio por cargo y películas por año. Se muestran en pantalla con tabla y gráfico, y se pueden exportar a PDF con vista previa, descarga e impresión. |
| Usuarios | Administración de cuentas y roles, con filtros por nombre o usuario, rol y estado (requiere permiso `usuarios.administrar`). |
| Auditoría | Registro de inicios de sesión, cambios, importaciones y generación de PDF, con filtros por módulo, acción, usuario y fechas. |
| Mi cuenta | Cada usuario cambia su propia contraseña, verificando la actual. Muestra también si su 2FA está activo. |

Los listados usan filtros que se aplican al escribir o al cambiar una opción. Los botones **Limpiar filtros** restablecen la búsqueda. La exportación CSV usa separador `;` y codificación UTF-8 con BOM, para que Excel en Colombia abra los acentos correctamente.

Los permisos de cada rol se administran en la base de datos (tablas `rol`, `permiso` y `rol_permiso`).

## 8. Importar archivos

- **XLSX de nómina**: la aplicación detecta las hojas por sus encabezados (`CODIGO`, `NOMBRE DEL EMPLEADO`, `DEPENDENCIA`, `CARGO`, `FECHA INGRESO`, `EPS`, `ARL`, `PENSION`, `SUELDO`) y las hojas de novedades por sus columnas (`NOVEDAD INCAPACIDAD`, `NOVEDAD VACACIONES`, etc.). En novedades puede indicar el periodo (MM/AAAA).
- **DAT de películas**: una línea por película con el formato `id::titulo::generos`, con géneros separados por `|`.
- **JSON de libros**: arreglo de objetos con los campos del catálogo de libros. Las filas inválidas (calificación fuera de 0–5, ISBN-13 mal formado, fecha inválida) se registran como errores sin detener la importación.

Cada importación se ejecuta en una transacción. Los duplicados se reportan como `DUPLICADO` y los datos inválidos como `VALIDACION`, con el número de fila y el motivo. Los archivos subidos se guardan en `uploads\` con un nombre aleatorio.

## 9. Reportes y PDF

En **Reportes** elija el reporte y sus parámetros, luego:

- **Generar en pantalla**: muestra la tabla y el gráfico (torta o barras, según el reporte).
- **Vista previa PDF**: muestra el PDF en el mismo navegador.
- **Descargar PDF** / **Imprimir PDF**: genera el archivo A4 con los mismos datos. Cada PDF generado se registra en la auditoría y se guarda en `generated_reports\`.

## 10. Datos de demostración

La nómina original del documento tiene 20 empleados. Para completar la base hasta 2.000 se agregaron **1.980 empleados sintéticos** (códigos 5021 a 7000) con nombres, salarios y novedades generados aleatoriamente, identificables porque sus códigos son mayores a 5020. Si desea trabajar solo con los datos reales, ejecute en MySQL Workbench:

```sql
USE entrecol;
DELETE FROM empleado WHERE id_empleado > 5020;
```

Las novedades de esos empleados se eliminan en cascada.

Los conteos de la base son: 2.000 empleados, 6.000 novedades, 10.681 películas (con 19 géneros), 11.121 libros válidos (6 registros de `Books.json` no pasaron la validación en la carga inicial).

## 11. Solución de problemas

| Mensaje | Causa y solución |
|---|---|
| `Falta instalar Dompdf` | No se ejecutó `composer install` en la carpeta del proyecto. |
| `El archivo supera el tamaño permitido por el servidor` | Ajuste `upload_max_filesize` y `post_max_size` a 25M y reinicie Apache. |
| `El código CAPTCHA no es correcto` | Escriba el código de la imagen actual; el CAPTCHA cambia en cada intento. |
| `Token de seguridad inválido` | Recargue la página (la sesión expiró). |
| `La cuenta está bloqueada temporalmente` | Tras 5 contraseñas incorrectas la cuenta se bloquea 15 minutos. |
| Error de conexión a la base de datos | Verifique que MySQL esté iniciado y que `DB_CLAVE` en `config\database.php` coincida con el usuario `entrecol_app`. |
| Acentos mal mostrados | Verifique que la importación de `sql\entrecol.sql` se haga desde MySQL Workbench o con el charset utf8mb4. |
| Estilos, gráficos o íconos no aparecen | Bootstrap, Chart.js, qrcode, Bootstrap Icons y la fuente Inter se cargan desde internet. Verifique la conexión. |
| Error `Respuesta no válida del servidor` | Abra la aplicación desde `http://localhost/entrecol/` (Apache de XAMPP), no desde Live Server ni desde un archivo local. |

## 12. Seguridad implementada

- Contraseñas con `password_hash` / `password_verify` (bcrypt).
- CAPTCHA propio en cada ingreso, de un solo uso y con vencimiento de 5 minutos. Cada intento queda registrado.
- Bloqueo temporal de la cuenta tras 5 intentos fallidos de contraseña **o de código 2FA** (15 minutos).
- Doble factor TOTP (RFC 6238) con el secreto cifrado en AES-256-GCM y códigos de recuperación de un solo uso.
- Sesiones con cookie `HttpOnly` y `SameSite=Strict`. El identificador de sesión se regenera al validar la contraseña y al completar el 2FA.
- Cambio de contraseña propia con verificación de la contraseña actual, reglas de complejidad y auditoría.
- Token CSRF en cabecera `X-CSRF-Token` para todas las escrituras (POST, PUT, DELETE).
- Consultas preparadas con PDO en todo el acceso a datos; el JavaScript nunca envía SQL.
- Salida escapada en el navegador (`esc()`) y en los PDF (`htmlspecialchars`).
- Validación de tipo, extensión, tamaño y contenido de los archivos importados.
- Control de permisos por rol en cada endpoint y en el menú.
- Auditoría de inicios de sesión, cambios, importaciones y PDF.

Limitaciones conocidas, documentadas para un entorno académico:

- Un mismo código TOTP puede usarse dos veces dentro de su ventana de 30 segundos (no se guarda el último paso usado).
- La cookie de sesión no lleva el atributo `Secure`, porque el sistema funciona en `http://localhost`. En un servidor con HTTPS debe activarse.
- El mensaje de cuenta bloqueada revela que el usuario existe.
- El formulario de ingreso no usa token CSRF (el CAPTCHA y el límite de intentos mitigan el riesgo).

## 13. Estructura

```
entrecol/
├── index.php              redirige a frontend/login.html
├── composer.json          dependencia Dompdf
├── config/database.php    conexión y constantes
├── services/              sesión, CSRF, TOTP, CAPTCHA, cifrado, importadores, reportes, PDF
├── backend/               endpoints JSON (auth incluido mi_cuenta.php, usuarios, empleados, novedades, peliculas, libros, importaciones, reportes, auditoria)
├── frontend/              páginas HTML (incluye mi-cuenta.html), css/app.css (estilos y modo oscuro) y js/ (comun.js y un script por página)
├── sql/entrecol.sql       base de datos para MySQL Workbench
├── uploads/               archivos importados
└── generated_reports/     PDF generados
```
