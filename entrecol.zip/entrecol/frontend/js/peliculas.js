let GENEROS = [];
let PAGINA = 1;
let ID_EDITANDO = null;

function definicionesFiltros() {
    return [
        { nombre: 'q', etiqueta: 'Título', placeholder: 'Buscar por título…' },
        { nombre: 'genero', etiqueta: 'Género', tipo: 'select', vacio: 'Todos', opciones: GENEROS.map((g) => ({ valor: g, texto: g })) },
        { nombre: 'anio_desde', etiqueta: 'Año desde', tipo: 'number', min: 1880, max: 2100 },
        { nombre: 'anio_hasta', etiqueta: 'Año hasta', tipo: 'number', min: 1880, max: 2100 },
        {
            nombre: 'orden', etiqueta: 'Ordenar por', tipo: 'select', vacio: 'Título (predeterminado)', opciones: [
                { valor: 'anio', texto: 'Año' },
                { valor: 'id', texto: 'ID' },
            ],
        },
        { nombre: 'dir', etiqueta: 'Sentido', tipo: 'select', vacio: 'Ascendente', opciones: [{ valor: 'desc', texto: 'Descendente' }] },
    ];
}

function refrescarFiltros() {
    pintarFiltros(el('filtros'), definicionesFiltros(), () => {
        PAGINA = 1;
        cargarPeliculas().catch(avisarError);
    });
}

async function cargarGeneros() {
    GENEROS = (await api('peliculas/index.php?generos=1')).generos.map((g) => g.nombre);
    el('fGeneros').innerHTML = GENEROS.map((g) => `<div class="col"><div class="form-check">`
        + `<input class="form-check-input" type="checkbox" value="${esc(g)}" id="genero-${esc(g.replace(/\s+/g, '-'))}">`
        + `<label class="form-check-label" for="genero-${esc(g.replace(/\s+/g, '-'))}">${esc(g)}</label></div></div>`).join('');
}

async function cargarPeliculas(pagina = PAGINA) {
    PAGINA = pagina;
    const parametros = leerFiltros(el('filtros'));
    parametros.set('pagina', pagina);
    const r = await api('peliculas/index.php?' + parametros);
    el('totalPeliculas').textContent = `${r.total} película(s)`;
    const editar = puede('peliculas.editar');
    el('tablaPeliculas').innerHTML = r.peliculas.length
        ? r.peliculas.map((p) => `<tr>
            <td>${esc(p.id_pelicula)}</td>
            <td class="fw-semibold">${esc(p.titulo)}</td>
            <td>${esc(p.anio ?? '')}</td>
            <td class="texto-largo">${esc(p.generos || '')}</td>
            <td class="text-end acciones">${editar ? `
                <button class="btn btn-sm btn-outline-primary" data-editar="${esc(p.id_pelicula)}" title="Editar"><i class="bi bi-pencil"></i></button>
                <button class="btn btn-sm btn-outline-danger" data-eliminar="${esc(p.id_pelicula)}" title="Eliminar"><i class="bi bi-trash"></i></button>` : ''}
            </td></tr>`).join('')
        : filaVacia(5, 'No hay películas con los filtros aplicados.');
    paginar(el('paginacion'), r.pagina, r.paginas, (nueva) => cargarPeliculas(nueva).catch(avisarError));
}

function marcarGeneros(seleccionados) {
    el('fGeneros').querySelectorAll('input').forEach((c) => {
        c.checked = seleccionados.includes(c.value);
    });
}

async function abrirPelicula(id = null) {
    ID_EDITANDO = id;
    el('formPelicula').reset();
    el('tituloPelicula').textContent = id ? 'Editar película' : 'Nueva película';
    marcarGeneros([]);
    if (id) {
        const r = await api(`peliculas/index.php?id=${encodeURIComponent(id)}`);
        el('fTitulo').value = r.pelicula.titulo;
        el('fAnio').value = r.pelicula.anio ?? '';
        marcarGeneros(r.pelicula.generos);
    }
    modal('modalPelicula').show();
}

async function guardarPelicula(evento) {
    evento.preventDefault();
    if (!evento.target.checkValidity()) {
        evento.target.reportValidity();
        return;
    }
    const generos = [...el('fGeneros').querySelectorAll('input:checked')].map((c) => c.value);
    const datos = { titulo: el('fTitulo').value.trim(), anio: el('fAnio').value, generos };
    if (ID_EDITANDO) {
        datos.id_pelicula = ID_EDITANDO;
    }
    try {
        const r = await api('peliculas/index.php', { metodo: ID_EDITANDO ? 'PUT' : 'POST', datos });
        modal('modalPelicula').hide();
        mostrarAviso(r.mensaje);
        await cargarPeliculas(PAGINA);
    } catch (error) {
        avisarError(error);
    }
}

async function eliminarPelicula(id) {
    if (!window.confirm('¿Eliminar esta película?')) {
        return;
    }
    try {
        const r = await api(`peliculas/index.php?id=${encodeURIComponent(id)}`, { metodo: 'DELETE' });
        mostrarAviso(r.mensaje);
        await cargarPeliculas(PAGINA);
    } catch (error) {
        avisarError(error);
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    if (!await iniciarPagina('peliculas.html', 'peliculas.consultar')) {
        return;
    }
    el('btnNueva').classList.toggle('d-none', !puede('peliculas.editar'));
    el('btnNueva').onclick = () => abrirPelicula().catch(avisarError);
    el('btnCsv').onclick = () => descargarCsv('peliculas/index.php', leerFiltros(el('filtros'))).catch(avisarError);
    el('formPelicula').addEventListener('submit', guardarPelicula);
    el('tablaPeliculas').addEventListener('click', (evento) => {
        const boton = evento.target.closest('button');
        if (!boton) {
            return;
        }
        if (boton.dataset.editar) {
            abrirPelicula(boton.dataset.editar).catch(avisarError);
        } else if (boton.dataset.eliminar) {
            eliminarPelicula(boton.dataset.eliminar);
        }
    });
    await cargarGeneros();
    refrescarFiltros();
    await cargarPeliculas(1);
});
