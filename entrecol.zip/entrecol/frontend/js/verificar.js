document.addEventListener('DOMContentLoaded', () => {
    el('formVerificar').addEventListener('submit', async (evento) => {
        evento.preventDefault();
        const error = el('error');
        const boton = el('btnVerificar');
        error.classList.add('d-none');
        boton.disabled = true;
        try {
            await api('auth/verificar_2fa.php', { metodo: 'POST', datos: { codigo: el('codigo').value.trim() } });
            location.href = 'inicio.html';
        } catch (err) {
            error.textContent = err.message;
            error.classList.remove('d-none');
            boton.disabled = false;
        }
    });
});
