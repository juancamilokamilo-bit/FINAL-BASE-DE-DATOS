let USUARIOS = new Map();
let ID_EDITANDO = null;
let ROLES = [];

function definicionesFiltros() {
    return [
        { nombre: 'q', etiqueta: 'Nombre o usuario', placeholder: 'Buscar…' },
        { nombre: 'rol', etiqueta: 'Rol', tipo: 'select', vacio: 'Todos', opciones: ROLES.map((r) => ({ valor: r.id_rol, texto: r.nombre })) },
        { nombre: 'activo', etiqueta: 'Estado', tipo: 'select', vacio: 'Todos', opciones: [
            { valor: '1', texto: 'Activos' },
            { valor: '0', texto: 'Inactivos' },
        ] },
    ];
}

function refrescarFiltros() {
    pintarFiltros(el('filtros'), definicionesFiltros(), () => cargarUsuarios().catch(avisarError));
}

async function cargarUsuarios() {
    const r = await api('usuarios/index.php?' + leerFiltros(el('filtros')));
    USUARIOS = new Map(r.usuarios.map((u) => [String(u.id_usuario), u]));
    el('totalUsuarios').textContent = `${r.usuarios.length} usuario(s)`;
    el('tablaUsuarios').innerHTML = r.usuarios.length
        ? r.usuarios.map((u) => `<tr>
            <td class="fw-semibold">${esc(u.nombre_completo)}</td>
            <td class="font-monospace">${esc(u.nombre_usuario)}</td>
            <td>${esc(u.correo)}</td>
            <td><span class="badge text-bg-primary-subtle text-primary-emphasis">${esc(u.rol)}</span></td>
            <td>${Number(u.activo) === 1 ? '<span class="badge text-bg-success">Activo</span>' : '<span class="badge text-bg-secondary">Inactivo</span>'}</td>
            <td>${Number(u.totp_activo) === 1 ? '<i class="bi bi-shield-check text-success"></i>' : '<span class="text-secondary small">No</span>'}</td>
            <td class="small">${esc(u.ultimo_acceso ? String(u.ultimo_acceso).slice(0, 16).replace('T', ' ') : 'Nunca')}</td>
            <td class="text-end"><button class="btn btn-sm btn-outline-primary" data-editar="${esc(u.id_usuario)}" title="Editar"><i class="bi bi-pencil"></i></button></td>
            </tr>`).join('')
        : filaVacia(8, 'No hay usuarios con los filtros aplicados.');
}

function abrirUsuario(id = null) {
    ID_EDITANDO = id;
    el('formUsuario').reset();
    el('tituloUsuario').textContent = id ? 'Editar usuario' : 'Nuevo usuario';
    el('fUsuario').disabled = Boolean(id);
    el('fClave').required = !id;
    el('ayudaClave').textContent = id ? 'Déjela vacía para conservar la contraseña actual. Si la escribe, debe tener mínimo 10 caracteres.' : 'Mínimo 10 caracteres.';
    el('bloqueEstado').classList.toggle('d-none', !id);
    llenarSelect(el('fRol'), ROLES.map((r) => ({ id: r.id_rol, nombre: r.nombre })), { vacio: 'Seleccione…' });
    if (id) {
        const u = USUARIOS.get(String(id));
        el('fNombre').value = u.nombre_completo;
        el('fUsuario').value = u.nombre_usuario;
        el('fCorreo').value = u.correo;
        el('fRol').value = u.id_rol;
        el('fActivo').value = String(u.activo);
    }
    modal('modalUsuario').show();
}

async function guardarUsuario(evento) {
    evento.preventDefault();
    if (!evento.target.checkValidity()) {
        evento.target.reportValidity();
        return;
    }
    const datos = {
        nombre_completo: el('fNombre').value.trim(),
        correo: el('fCorreo').value.trim(),
        id_rol: el('fRol').value,
    };
    try {
        if (ID_EDITANDO) {
            datos.id_usuario = ID_EDITANDO;
            datos.activo = Number(el('fActivo').value);
            if (el('fClave').value !== '') {
                datos.clave = el('fClave').value;
            }
        } else {
            datos.nombre_usuario = el('fUsuario').value.trim();
            datos.clave = el('fClave').value;
        }
        const r = await api('usuarios/index.php', { metodo: ID_EDITANDO ? 'PUT' : 'POST', datos });
        modal('modalUsuario').hide();
        mostrarAviso(r.mensaje);
        await cargarUsuarios();
    } catch (error) {
        avisarError(error);
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    if (!await iniciarPagina('usuarios.html', 'usuarios.administrar')) {
        return;
    }
    el('btnNuevo').onclick = () => abrirUsuario();
    el('formUsuario').addEventListener('submit', guardarUsuario);
    el('tablaUsuarios').addEventListener('click', (evento) => {
        const boton = evento.target.closest('button[data-editar]');
        if (boton) {
            abrirUsuario(boton.dataset.editar);
        }
    });
    ROLES = (await api('usuarios/index.php?roles=1')).roles;
    refrescarFiltros();
    await cargarUsuarios().catch(avisarError);
});
