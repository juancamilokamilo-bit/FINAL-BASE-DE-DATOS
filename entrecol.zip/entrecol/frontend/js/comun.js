const API = '../backend/';
const TEMA_CLAVE = 'entrecol_tema';
let SESION = null;

const esc = (valor) => String(valor ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const pesos = (valor) => '$' + Number(valor || 0).toLocaleString('es-CO', { maximumFractionDigits: 0 });
const el = (id) => document.getElementById(id);
const modal = (id) => bootstrap.Modal.getOrCreateInstance(el(id));
const avisarError = (error) => mostrarAviso(error.message, 'danger');

const MENU = [
    { href: 'inicio.html', texto: 'Inicio', icono: 'bi-speedometer2' },
    { href: 'empleados.html', texto: 'Nómina', icono: 'bi-people', permiso: 'nomina.consultar' },
    { href: 'novedades.html', texto: 'Novedades', icono: 'bi-calendar2-check', permiso: 'nomina.consultar' },
    { href: 'peliculas.html', texto: 'Películas', icono: 'bi-film', permiso: 'peliculas.consultar' },
    { href: 'libros.html', texto: 'Libros', icono: 'bi-book', permiso: 'libros.consultar' },
    { href: 'importaciones.html', texto: 'Importar', icono: 'bi-cloud-arrow-up', permiso: 'importar.ejecutar' },
    { href: 'reportes.html', texto: 'Reportes', icono: 'bi-file-earmark-bar-graph', permiso: 'reportes.consultar' },
    { href: 'usuarios.html', texto: 'Usuarios', icono: 'bi-person-gear', permiso: 'usuarios.administrar' },
    { href: 'auditoria.html', texto: 'Auditoría', icono: 'bi-clipboard-data', permiso: 'auditoria.consultar' },
];

async function api(ruta, opciones = {}) {
    const { metodo = 'GET', datos, formulario } = opciones;
    const cabeceras = {};
    if (SESION) {
        cabeceras['X-CSRF-Token'] = SESION.csrf;
    }
    let cuerpo;
    if (formulario) {
        cuerpo = formulario;
    } else if (datos !== undefined) {
        cabeceras['Content-Type'] = 'application/json';
        cuerpo = JSON.stringify(datos);
    }
    const respuesta = await fetch(API + ruta, { method: metodo, headers: cabeceras, body: cuerpo, credentials: 'same-origin' });
    let json;
    try {
        json = await respuesta.json();
    } catch {
        json = { ok: false, mensaje: 'Respuesta no válida del servidor (' + respuesta.status + ')' };
    }
    if (respuesta.status === 401 && !ruta.startsWith('auth/')) {
        location.href = 'login.html';
        throw new Error('Su sesión expiró');
    }
    if (!json.ok) {
        throw new Error(json.mensaje || 'Ocurrió un error');
    }
    return json;
}

function puede(permiso) {
    return SESION?.usuario?.permisos?.includes(permiso) ?? false;
}

function mostrarAviso(mensaje, tipo = 'success') {
    const contenedor = el('avisos');
    if (!contenedor) {
        return;
    }
    const aviso = document.createElement('div');
    aviso.className = `toast show align-items-center text-bg-${tipo} border-0`;
    aviso.setAttribute('role', 'alert');
    aviso.innerHTML = `<div class="d-flex"><div class="toast-body">${esc(mensaje)}</div>`
        + '<button type="button" class="btn-close btn-close-white me-2 m-auto" aria-label="Cerrar"></button></div>';
    aviso.querySelector('button').onclick = () => aviso.remove();
    contenedor.appendChild(aviso);
    setTimeout(() => aviso.remove(), 6000);
}

function temaActual() {
    try {
        return localStorage.getItem(TEMA_CLAVE) === 'dark' ? 'dark' : 'light';
    } catch {
        return 'light';
    }
}

function aplicarTema(tema) {
    const oscuro = tema === 'dark';
    document.documentElement.setAttribute('data-bs-theme', oscuro ? 'dark' : 'light');
    const boton = el('btnTema');
    if (boton) {
        boton.innerHTML = oscuro ? '<i class="bi bi-sun"></i>' : '<i class="bi bi-moon-stars"></i>';
        boton.title = oscuro ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro';
        boton.setAttribute('aria-label', boton.title);
    }
    if (window.Chart) {
        Chart.defaults.color = oscuro ? '#cbd5e1' : '#475569';
        Chart.defaults.borderColor = oscuro ? '#2a3150' : '#e3e7f0';
        Object.values(Chart.instances).forEach((grafico) => grafico.update());
    }
}

function alternarTema() {
    const nuevo = temaActual() === 'dark' ? 'light' : 'dark';
    try {
        localStorage.setItem(TEMA_CLAVE, nuevo);
    } catch {
    }
    aplicarTema(nuevo);
}

function plantillaNavegacion() {
    return `<nav class="navbar navbar-expand-lg app-navbar sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold d-flex align-items-center gap-2" href="inicio.html"><i class="bi bi-buildings"></i>EntreCOL+</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menuPrincipal" aria-controls="menuPrincipal" aria-expanded="false" aria-label="Abrir menú">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="menuPrincipal">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0" id="navegacion"></ul>
            <div class="d-flex align-items-center gap-2 flex-wrap">
                <button class="btn btn-sm btn-outline-light" id="btnTema" type="button"></button>
                <div class="dropdown">
                    <button class="btn btn-sm btn-light dropdown-toggle d-flex align-items-center gap-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-person-circle"></i><span id="usuarioActual"></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow">
                        <li><a class="dropdown-item" href="mi-cuenta.html"><i class="bi bi-key me-2"></i>Mi cuenta</a></li>
                        <li><a class="dropdown-item" href="configurar-2fa.html"><i class="bi bi-shield-lock me-2"></i>Seguridad (2FA)</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><button class="dropdown-item text-danger" id="btnSalir" type="button"><i class="bi bi-box-arrow-right me-2"></i>Cerrar sesión</button></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>`;
}

function pintarNavegacion(actual) {
    const barra = el('barra');
    if (barra) {
        barra.innerHTML = plantillaNavegacion();
    }
    const lista = el('navegacion');
    if (lista) {
        lista.innerHTML = MENU.filter((i) => !i.permiso || puede(i.permiso))
            .map((i) => `<li class="nav-item"><a class="nav-link ${i.href === actual ? 'active' : ''}" href="${i.href}"><i class="bi ${i.icono} me-1"></i>${esc(i.texto)}</a></li>`)
            .join('');
    }
    if (el('usuarioActual')) {
        el('usuarioActual').textContent = `${SESION.usuario.nombre}`;
    }
    if (el('btnTema')) {
        el('btnTema').onclick = alternarTema;
    }
    if (el('btnSalir')) {
        el('btnSalir').onclick = async () => {
            try {
                await api('auth/logout.php', { metodo: 'POST' });
            } finally {
                location.href = 'login.html';
            }
        };
    }
    aplicarTema(temaActual());
}

async function iniciarPagina(actual, permiso = null) {
    const respuesta = await fetch(API + 'auth/sesion.php', { credentials: 'same-origin' });
    const json = await respuesta.json().catch(() => ({ ok: false }));
    if (!json.ok) {
        location.href = 'login.html';
        return false;
    }
    SESION = json;
    pintarNavegacion(actual);
    if (permiso && !puede(permiso)) {
        el('contenido').innerHTML = '<div class="alert alert-danger">No tiene permisos para ver esta sección.</div>';
        return false;
    }
    return true;
}

function llenarSelect(select, items, { vacio = 'Seleccione…', valor = 'id', texto = 'nombre' } = {}) {
    select.innerHTML = `<option value="">${esc(vacio)}</option>`
        + items.map((i) => `<option value="${esc(i[valor])}">${esc(i[texto])}</option>`).join('');
}

function controlFiltro(definicion) {
    const atributos = `data-filtro="${esc(definicion.nombre)}" aria-label="${esc(definicion.etiqueta)}"`;
    if (definicion.tipo === 'select') {
        const opciones = (definicion.opciones || []).map((o) => `<option value="${esc(o.valor)}">${esc(o.texto)}</option>`).join('');
        return `<select class="form-select form-select-sm" ${atributos}><option value="">${esc(definicion.vacio || 'Todos')}</option>${opciones}</select>`;
    }
    const extra = [
        definicion.min !== undefined ? `min="${esc(definicion.min)}"` : '',
        definicion.step !== undefined ? `step="${esc(definicion.step)}"` : '',
        definicion.placeholder ? `placeholder="${esc(definicion.placeholder)}"` : '',
        definicion.maxlength ? `maxlength="${esc(definicion.maxlength)}"` : '',
    ].join(' ');
    return `<input class="form-control form-control-sm" type="${esc(definicion.tipo || 'text')}" ${atributos} ${extra}>`;
}

function leerFiltros(contenedor) {
    const parametros = new URLSearchParams();
    contenedor.querySelectorAll('[data-filtro]').forEach((control) => {
        const valor = control.value.trim();
        if (valor !== '') {
            parametros.set(control.dataset.filtro, valor);
        }
    });
    return parametros;
}

function pintarFiltros(contenedor, definiciones, alCambiar) {
    const anteriores = contenedor.querySelectorAll('[data-filtro]').length ? leerFiltros(contenedor) : null;
    contenedor.innerHTML = `<div class="row g-2 align-items-end">`
        + definiciones.map((d) => `<div class="${d.ancho || 'col-12 col-sm-6 col-lg-4 col-xl-3'}">`
            + `<label class="form-label small fw-semibold mb-1">${esc(d.etiqueta)}</label>${controlFiltro(d)}</div>`).join('')
        + `<div class="col-12 col-xl-auto"><button type="button" class="btn btn-sm btn-outline-secondary w-100" data-limpiar>`
        + '<i class="bi bi-x-circle me-1"></i>Limpiar filtros</button></div></div>';
    if (anteriores) {
        anteriores.forEach((valor, clave) => {
            const control = contenedor.querySelector(`[data-filtro="${clave}"]`);
            if (control) {
                control.value = valor;
            }
        });
    }
    let temporizador = null;
    contenedor.querySelectorAll('[data-filtro]').forEach((control) => {
        const inmediato = control.tagName === 'SELECT' || control.type === 'date' || control.type === 'number';
        control.addEventListener(inmediato ? 'change' : 'input', () => {
            clearTimeout(temporizador);
            temporizador = setTimeout(() => alCambiar(), inmediato ? 0 : 350);
        });
    });
    contenedor.querySelector('[data-limpiar]').onclick = () => {
        contenedor.querySelectorAll('[data-filtro]').forEach((control) => {
            control.value = '';
        });
        alCambiar();
    };
}

async function descargarCsv(ruta, parametros) {
    const consulta = new URLSearchParams(parametros);
    consulta.set('exportar', 'csv');
    const respuesta = await fetch(API + ruta + '?' + consulta.toString(), { credentials: 'same-origin' });
    if (respuesta.status === 401) {
        location.href = 'login.html';
        return;
    }
    if (!respuesta.ok || !(respuesta.headers.get('Content-Type') || '').includes('text/csv')) {
        const error = await respuesta.json().catch(() => ({}));
        throw new Error(error.mensaje || 'No se pudo generar el archivo CSV');
    }
    const nombre = (respuesta.headers.get('Content-Disposition') || '').match(/filename="([^"]+)"/)?.[1] || 'listado.csv';
    const url = URL.createObjectURL(await respuesta.blob());
    const enlace = document.createElement('a');
    enlace.href = url;
    enlace.download = nombre;
    document.body.appendChild(enlace);
    enlace.click();
    enlace.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function paginar(contenedor, pagina, paginas, alCambiar) {
    if (paginas <= 1) {
        contenedor.innerHTML = '';
        return;
    }
    contenedor.innerHTML = `<button class="btn btn-sm btn-outline-secondary" data-p="${pagina - 1}" ${pagina <= 1 ? 'disabled' : ''}>Anterior</button>`
        + `<span class="mx-3 small align-self-center text-secondary">Página ${pagina} de ${paginas}</span>`
        + `<button class="btn btn-sm btn-outline-secondary" data-p="${pagina + 1}" ${pagina >= paginas ? 'disabled' : ''}>Siguiente</button>`;
    contenedor.querySelectorAll('button').forEach((b) => b.onclick = () => alCambiar(Number(b.dataset.p)));
}

function fechaCorta(valor) {
    if (!valor) {
        return '';
    }
    const [a, m, d] = String(valor).slice(0, 10).split('-');
    return `${d}/${m}/${a}`;
}

function filaVacia(columnas, mensaje) {
    return `<tr><td colspan="${columnas}" class="text-center text-secondary py-4">${esc(mensaje)}</td></tr>`;
}
