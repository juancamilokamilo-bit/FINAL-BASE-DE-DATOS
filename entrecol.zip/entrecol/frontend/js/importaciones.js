const filasDetalle = (lista) => (lista && lista.length
    ? lista.map((d) => `<tr>
        <td>${esc(d.referencia ?? '')}</td>
        <td><span class="badge text-bg-${(d.tipo_error ?? d.tipo) === 'DUPLICADO' ? 'warning' : 'danger'}">${esc(d.tipo_error ?? d.tipo ?? '')}</span></td>
        <td class="texto-largo">${esc(d.motivo ?? '')}</td>
        <td class="texto-largo font-monospace small">${esc(d.contenido ?? '')}</td>
    </tr>`).join('')
    : filaVacia(4, 'Sin registros con novedad.'));

function definicionesHistorial() {
    return [
        { nombre: 'tipo', etiqueta: 'Tipo', tipo: 'select', vacio: 'Todos', opciones: [
            { valor: 'XLSX', texto: 'XLSX' },
            { valor: 'DAT', texto: 'DAT' },
            { valor: 'JSON', texto: 'JSON' },
        ] },
        { nombre: 'archivo', etiqueta: 'Nombre del archivo', placeholder: 'Buscar archivo…' },
        { nombre: 'usuario', etiqueta: 'Usuario', placeholder: 'Nombre de usuario' },
        { nombre: 'desde', etiqueta: 'Desde', tipo: 'date' },
        { nombre: 'hasta', etiqueta: 'Hasta', tipo: 'date' },
    ];
}

async function cargarHistorial() {
    const r = await api('importaciones/index.php?' + leerFiltros(el('filtrosHistorial')));
    el('historial').innerHTML = r.historial.length
        ? r.historial.map((h) => `<tr>
            <td>${esc(h.id_importacion)}</td>
            <td>${esc(String(h.fecha_hora).slice(0, 16).replace('T', ' '))}</td>
            <td class="texto-largo">${esc(h.nombre_archivo)}</td>
            <td><span class="badge text-bg-secondary">${esc(h.tipo_archivo)}</span></td>
            <td>${esc(h.usuario || '')}</td>
            <td class="text-end">${esc(h.total_registros)}</td>
            <td class="text-end">${esc(h.registros_insertados)}</td>
            <td class="text-end">${esc(h.registros_duplicados)}</td>
            <td class="text-end">${esc(h.registros_error)}</td>
            <td class="text-end"><button class="btn btn-sm btn-outline-primary" data-detalle="${esc(h.id_importacion)}" title="Ver detalle"><i class="bi bi-list-ul"></i></button></td>
            </tr>`).join('')
        : filaVacia(10, 'No hay importaciones con los filtros aplicados.');
}

function refrescarFiltrosHistorial() {
    pintarFiltros(el('filtrosHistorial'), definicionesHistorial(), () => cargarHistorial().catch(avisarError));
}

async function verDetalle(id) {
    const r = await api('importaciones/index.php?id=' + encodeURIComponent(id));
    el('detalleId').textContent = `#${id}`;
    el('detalleTabla').innerHTML = filasDetalle(r.detalles);
    el('tarjetaDetalle').classList.remove('d-none');
    el('tarjetaDetalle').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function importar(evento) {
    evento.preventDefault();
    const formulario = evento.target;
    if (!formulario.checkValidity()) {
        formulario.reportValidity();
        return;
    }
    const archivo = el('fArchivo').files[0];
    if (!archivo) {
        avisarError(new Error('Seleccione un archivo'));
        return;
    }
    const datos = new FormData();
    datos.append('tipo', el('fTipo').value);
    datos.append('archivo', archivo);
    datos.append('periodo', el('fPeriodo').value.trim());
    el('btnImportar').disabled = true;
    try {
        const r = await api('importaciones/index.php', { metodo: 'POST', formulario: datos });
        el('rTotal').textContent = r.total;
        el('rInsertados').textContent = r.insertados;
        el('rDuplicados').textContent = r.duplicados;
        el('rErrores').textContent = r.errores;
        el('rDetalles').innerHTML = filasDetalle(r.detalles);
        el('tarjetaResultado').classList.remove('d-none');
        mostrarAviso(r.mensaje);
        el('fArchivo').value = '';
        await cargarHistorial();
    } catch (error) {
        avisarError(error);
    } finally {
        el('btnImportar').disabled = false;
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    if (!await iniciarPagina('importaciones.html', 'importar.ejecutar')) {
        return;
    }
    el('formImportar').addEventListener('submit', importar);
    el('historial').addEventListener('click', (evento) => {
        const boton = evento.target.closest('button[data-detalle]');
        if (boton) {
            verDetalle(boton.dataset.detalle).catch(avisarError);
        }
    });
    el('btnCerrarDetalle').onclick = () => el('tarjetaDetalle').classList.add('d-none');
    refrescarFiltrosHistorial();
    await cargarHistorial().catch(avisarError);
});
