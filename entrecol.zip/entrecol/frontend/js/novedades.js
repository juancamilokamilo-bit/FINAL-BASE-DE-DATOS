let ID_EDITANDO = null;
let NOVEDADES = new Map();
let EMPLEADOS = [];
let DEPENDENCIAS = [];

function definicionesFiltros() {
    return [
        { nombre: 'periodo', etiqueta: 'Periodo', tipo: 'select', vacio: 'Todos los periodos', opciones: PERIODOS.map((p) => ({ valor: p, texto: p })) },
        { nombre: 'q', etiqueta: 'Nombre', placeholder: 'Buscar por nombre…' },
        { nombre: 'dependencia', etiqueta: 'Dependencia', tipo: 'select', vacio: 'Todas', opciones: DEPENDENCIAS.map((d) => ({ valor: d.id, texto: d.nombre })) },
        { nombre: 'dias_incapacidad_min', etiqueta: 'Días de incapacidad (mínimo)', tipo: 'number', min: 0, max: 31 },
        { nombre: 'dias_vacaciones_min', etiqueta: 'Días de vacaciones (mínimo)', tipo: 'number', min: 0, max: 31 },
    ];
}

let PERIODOS = [];

async function cargarPeriodos() {
    PERIODOS = (await api('novedades/index.php?periodos=1')).periodos;
    llenarSelect(el('periodoPendientes'), PERIODOS.map((p) => ({ id: p, nombre: p })), { vacio: 'Seleccione un periodo' });
}

async function cargarCatalogos() {
    const r = await api('empleados/index.php?catalogo=todos');
    DEPENDENCIAS = r.catalogos.dependencias;
}

async function cargarEmpleados() {
    EMPLEADOS = (await api('empleados/index.php')).empleados;
    llenarSelect(el('fEmpleado'), EMPLEADOS.map((e) => ({ id: e.codigo, nombre: `${e.codigo} · ${e.nombre_completo}` })), { vacio: 'Seleccione…' });
}

function refrescarFiltros() {
    pintarFiltros(el('filtrosRegistros'), definicionesFiltros(), () => cargarNovedades().catch(avisarError));
}

const valorMonto = (valor) => pesos(valor);
const celdaFecha = (valor) => (valor ? fechaCorta(valor) : '—');

async function cargarNovedades() {
    const r = await api('novedades/index.php?' + leerFiltros(el('filtrosRegistros')));
    NOVEDADES = new Map(r.novedades.map((n) => [String(n.id_novedad), n]));
    el('totalNovedades').textContent = `${r.novedades.length} registro(s)`;
    const editar = puede('nomina.editar');
    el('tablaNovedades').innerHTML = r.novedades.length
        ? r.novedades.map((n) => `<tr>
            <td>${esc(n.codigo)}</td>
            <td class="fw-semibold">${esc(n.nombre_completo)}</td>
            <td>${esc(n.dependencia)}</td>
            <td>${esc(n.cargo)}</td>
            <td>${esc(n.periodo)}</td>
            <td class="text-end">${esc(n.dias_trabajados)}</td>
            <td class="text-end">${esc(n.dias_incapacidad)}</td>
            <td class="text-end">${esc(n.dias_vacaciones)}</td>
            <td>${celdaFecha(n.fecha_inicio_incapacidad)}</td>
            <td>${celdaFecha(n.fecha_fin_incapacidad)}</td>
            <td>${celdaFecha(n.fecha_inicio_vacaciones)}</td>
            <td>${celdaFecha(n.fecha_fin_vacaciones)}</td>
            <td class="text-end">${valorMonto(n.bonificacion)}</td>
            <td class="text-end">${valorMonto(n.auxilio_transporte)}</td>
            <td class="text-end acciones">${editar ? `
                <button class="btn btn-sm btn-outline-primary" data-editar="${esc(n.id_novedad)}" title="Editar"><i class="bi bi-pencil"></i></button>
                <button class="btn btn-sm btn-outline-danger" data-eliminar="${esc(n.id_novedad)}" title="Eliminar"><i class="bi bi-trash"></i></button>` : ''}
            </td></tr>`).join('')
        : filaVacia(15, 'No hay novedades con los filtros aplicados.');
}

async function cargarPendientes() {
    const periodo = el('periodoPendientes').value;
    if (!periodo) {
        throw new Error('Seleccione un periodo para consultar');
    }
    const r = await api('novedades/index.php?pendientes=1&periodo=' + encodeURIComponent(periodo));
    el('totalPendientes').textContent = `${r.total} empleado(s) sin novedad en ${periodo}`;
    const editar = puede('nomina.editar');
    el('tablaPendientes').innerHTML = r.pendientes.length
        ? r.pendientes.map((p) => `<tr>
            <td>${esc(p.codigo)}</td>
            <td class="fw-semibold">${esc(p.nombre_completo)}</td>
            <td>${esc(p.dependencia)}</td>
            <td>${esc(p.cargo)}</td>
            <td class="text-end">${pesos(p.salario)}</td>
            <td class="text-end">${editar ? `<button class="btn btn-sm btn-outline-primary" data-registrar="${esc(p.codigo)}" data-periodo="${esc(periodo)}"><i class="bi bi-plus-lg"></i> Registrar</button>` : ''}</td>
            </tr>`).join('')
        : filaVacia(6, `Todos los empleados activos tienen novedad en ${periodo}.`);
}

function abrirNovedad(novedad = null, codigo = null, periodo = null) {
    ID_EDITANDO = novedad ? novedad.id_novedad : null;
    el('formNovedad').reset();
    el('tituloNovedad').textContent = ID_EDITANDO ? 'Editar novedad' : 'Nueva novedad';
    el('fEmpleado').disabled = Boolean(ID_EDITANDO);
    if (novedad) {
        el('fEmpleado').value = novedad.codigo;
        el('fPeriodo').value = novedad.periodo;
        el('fTrabajados').value = novedad.dias_trabajados;
        el('fIncapacidad').value = novedad.dias_incapacidad;
        el('fVacaciones').value = novedad.dias_vacaciones;
        el('fIniIncapacidad').value = novedad.fecha_inicio_incapacidad || '';
        el('fFinIncapacidad').value = novedad.fecha_fin_incapacidad || '';
        el('fIniVacaciones').value = novedad.fecha_inicio_vacaciones || '';
        el('fFinVacaciones').value = novedad.fecha_fin_vacaciones || '';
        el('fBonificacion').value = novedad.bonificacion;
        el('fAuxilio').value = novedad.auxilio_transporte;
    } else {
        el('fEmpleado').value = codigo || '';
        el('fPeriodo').value = periodo || '';
    }
    modal('modalNovedad').show();
}

async function guardarNovedad(evento) {
    evento.preventDefault();
    if (!evento.target.checkValidity()) {
        evento.target.reportValidity();
        return;
    }
    const datos = {
        id_empleado: el('fEmpleado').value,
        periodo: el('fPeriodo').value.trim(),
        dias_trabajados: el('fTrabajados').value,
        dias_incapacidad: el('fIncapacidad').value,
        dias_vacaciones: el('fVacaciones').value,
        fecha_inicio_incapacidad: el('fIniIncapacidad').value,
        fecha_fin_incapacidad: el('fFinIncapacidad').value,
        fecha_inicio_vacaciones: el('fIniVacaciones').value,
        fecha_fin_vacaciones: el('fFinVacaciones').value,
        bonificacion: el('fBonificacion').value || 0,
        auxilio_transporte: el('fAuxilio').value || 0,
    };
    if (ID_EDITANDO) {
        datos.id_novedad = ID_EDITANDO;
    }
    try {
        const r = await api('novedades/index.php', { metodo: ID_EDITANDO ? 'PUT' : 'POST', datos });
        modal('modalNovedad').hide();
        mostrarAviso(r.mensaje);
        await Promise.all([cargarNovedades(), cargarPeriodos()]);
    } catch (error) {
        avisarError(error);
    }
}

async function eliminarNovedad(id) {
    if (!window.confirm('¿Eliminar esta novedad?')) {
        return;
    }
    try {
        const r = await api(`novedades/index.php?id=${encodeURIComponent(id)}`, { metodo: 'DELETE' });
        mostrarAviso(r.mensaje);
        await cargarNovedades();
    } catch (error) {
        avisarError(error);
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    if (!await iniciarPagina('novedades.html', 'nomina.consultar')) {
        return;
    }
    const editar = puede('nomina.editar');
    el('btnNueva').classList.toggle('d-none', !editar);
    el('btnNueva').onclick = () => abrirNovedad();
    el('formNovedad').addEventListener('submit', guardarNovedad);
    el('btnConsultarPendientes').onclick = () => cargarPendientes().catch(avisarError);
    el('btnCsvPendientes').onclick = () => {
        const periodo = el('periodoPendientes').value;
        if (!periodo) {
            avisarError(new Error('Seleccione un periodo para exportar'));
            return;
        }
        descargarCsv('novedades/index.php', { pendientes: 1, periodo }).catch(avisarError);
    };
    el('tablaNovedades').addEventListener('click', (evento) => {
        const boton = evento.target.closest('button');
        if (!boton) {
            return;
        }
        if (boton.dataset.editar) {
            abrirNovedad(NOVEDADES.get(boton.dataset.editar));
        } else if (boton.dataset.eliminar) {
            eliminarNovedad(boton.dataset.eliminar);
        }
    });
    el('tablaPendientes').addEventListener('click', (evento) => {
        const boton = evento.target.closest('button[data-registrar]');
        if (boton) {
            abrirNovedad(null, boton.dataset.registrar, boton.dataset.periodo);
        }
    });
    await Promise.all([cargarPeriodos(), cargarCatalogos(), cargarEmpleados()]);
    refrescarFiltros();
    await cargarNovedades();
});
