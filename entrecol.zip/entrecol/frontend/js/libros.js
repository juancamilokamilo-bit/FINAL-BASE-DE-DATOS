let LIBROS = new Map();
let PAGINA = 1;
let ID_EDITANDO = null;

const CALIFICACIONES = [0, 1, 2, 3, 4, 4.5, 5].map((v) => ({ valor: String(v), texto: String(v) }));

function definicionesFiltros() {
    return [
        { nombre: 'q', etiqueta: 'Título o autor', placeholder: 'Buscar…' },
        { nombre: 'editorial', etiqueta: 'Editorial', placeholder: 'Nombre de la editorial' },
        { nombre: 'idioma', etiqueta: 'Idioma', placeholder: 'Ej.: eng, spa, en-US', maxlength: 10 },
        { nombre: 'rating_min', etiqueta: 'Calificación mínima', tipo: 'select', vacio: 'Cualquiera', opciones: CALIFICACIONES },
        { nombre: 'rating_max', etiqueta: 'Calificación máxima', tipo: 'select', vacio: 'Cualquiera', opciones: CALIFICACIONES },
        { nombre: 'anio_desde', etiqueta: 'Año de publicación desde', tipo: 'number', min: 0, max: 2100 },
        { nombre: 'anio_hasta', etiqueta: 'Año de publicación hasta', tipo: 'number', min: 0, max: 2100 },
        { nombre: 'fecha_desde', etiqueta: 'Fecha desde', tipo: 'date' },
        { nombre: 'fecha_hasta', etiqueta: 'Fecha hasta', tipo: 'date' },
        { nombre: 'paginas_min', etiqueta: 'Páginas mínimas', tipo: 'number', min: 0 },
        { nombre: 'paginas_max', etiqueta: 'Páginas máximas', tipo: 'number', min: 0 },
        {
            nombre: 'orden', etiqueta: 'Ordenar por', tipo: 'select', vacio: 'Título (predeterminado)', opciones: [
                { valor: 'calificacion', texto: 'Calificación' },
                { valor: 'resenas', texto: 'Reseñas' },
                { valor: 'anio', texto: 'Año de publicación' },
                { valor: 'paginas', texto: 'Páginas' },
            ],
        },
        { nombre: 'dir', etiqueta: 'Sentido', tipo: 'select', vacio: 'Ascendente', opciones: [{ valor: 'desc', texto: 'Descendente' }] },
    ];
}

function refrescarFiltros() {
    pintarFiltros(el('filtros'), definicionesFiltros(), () => {
        PAGINA = 1;
        cargarLibros(1).catch(avisarError);
    });
}

async function cargarLibros(pagina = PAGINA) {
    PAGINA = pagina;
    const parametros = leerFiltros(el('filtros'));
    parametros.set('pagina', pagina);
    const r = await api('libros/index.php?' + parametros);
    LIBROS = new Map(r.libros.map((l) => [String(l.id_libro), l]));
    el('totalLibros').textContent = `${r.total} libro(s)`;
    const editar = puede('libros.editar');
    el('tablaLibros').innerHTML = r.libros.length
        ? r.libros.map((l) => `<tr>
            <td class="fw-semibold texto-largo">${esc(l.titulo)}</td>
            <td class="texto-largo">${esc(l.autores || '')}</td>
            <td>${esc(l.editorial || '')}</td>
            <td>${esc(l.codigo_idioma)}</td>
            <td class="text-end">${esc(l.num_paginas ?? '')}</td>
            <td class="text-end">${esc(l.calificacion_promedio)}</td>
            <td class="text-end">${esc(l.cantidad_calificaciones)}</td>
            <td class="text-end">${esc(l.cantidad_resenas)}</td>
            <td>${fechaCorta(l.fecha_publicacion)}</td>
            <td class="text-end acciones">${editar ? `
                <button class="btn btn-sm btn-outline-primary" data-editar="${esc(l.id_libro)}" title="Editar"><i class="bi bi-pencil"></i></button>
                <button class="btn btn-sm btn-outline-danger" data-eliminar="${esc(l.id_libro)}" title="Eliminar"><i class="bi bi-trash"></i></button>` : ''}
            </td></tr>`).join('')
        : filaVacia(10, 'No hay libros con los filtros aplicados.');
    paginar(el('paginacion'), r.pagina, r.paginas, (nueva) => cargarLibros(nueva).catch(avisarError));
}

function abrirLibro(id = null) {
    ID_EDITANDO = id;
    el('formLibro').reset();
    el('tituloLibro').textContent = id ? 'Editar libro' : 'Nuevo libro';
    el('fIdioma').value = 'en';
    el('fCantCal').value = 0;
    el('fCantRes').value = 0;
    if (id) {
        const l = LIBROS.get(String(id));
        el('fTitulo').value = l.titulo;
        el('fIsbn13').value = l.isbn13;
        el('fIsbn').value = l.isbn || '';
        el('fAutores').value = l.autores || '';
        el('fEditorial').value = l.editorial || '';
        el('fIdioma').value = l.codigo_idioma;
        el('fPaginas').value = l.num_paginas ?? '';
        el('fCalificacion').value = l.calificacion_promedio;
        el('fCantCal').value = l.cantidad_calificaciones;
        el('fCantRes').value = l.cantidad_resenas;
        el('fFecha').value = l.fecha_publicacion || '';
    }
    modal('modalLibro').show();
}

async function guardarLibro(evento) {
    evento.preventDefault();
    if (!evento.target.checkValidity()) {
        evento.target.reportValidity();
        return;
    }
    const datos = {
        titulo: el('fTitulo').value.trim(),
        isbn13: el('fIsbn13').value.trim(),
        isbn: el('fIsbn').value.trim(),
        autores: el('fAutores').value,
        editorial: el('fEditorial').value.trim(),
        codigo_idioma: el('fIdioma').value.trim(),
        num_paginas: el('fPaginas').value,
        calificacion_promedio: el('fCalificacion').value,
        cantidad_calificaciones: el('fCantCal').value || 0,
        cantidad_resenas: el('fCantRes').value || 0,
        fecha_publicacion: el('fFecha').value,
    };
    if (ID_EDITANDO) {
        datos.id_libro = ID_EDITANDO;
    }
    try {
        const r = await api('libros/index.php', { metodo: ID_EDITANDO ? 'PUT' : 'POST', datos });
        modal('modalLibro').hide();
        mostrarAviso(r.mensaje);
        await cargarLibros(PAGINA);
    } catch (error) {
        avisarError(error);
    }
}

async function eliminarLibro(id) {
    if (!window.confirm('¿Eliminar este libro?')) {
        return;
    }
    try {
        const r = await api(`libros/index.php?id=${encodeURIComponent(id)}`, { metodo: 'DELETE' });
        mostrarAviso(r.mensaje);
        await cargarLibros(PAGINA);
    } catch (error) {
        avisarError(error);
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    if (!await iniciarPagina('libros.html', 'libros.consultar')) {
        return;
    }
    el('btnNuevo').classList.toggle('d-none', !puede('libros.editar'));
    el('btnNuevo').onclick = () => abrirLibro();
    el('btnCsv').onclick = () => descargarCsv('libros/index.php', leerFiltros(el('filtros'))).catch(avisarError);
    el('formLibro').addEventListener('submit', guardarLibro);
    el('tablaLibros').addEventListener('click', (evento) => {
        const boton = evento.target.closest('button');
        if (!boton) {
            return;
        }
        if (boton.dataset.editar) {
            abrirLibro(boton.dataset.editar);
        } else if (boton.dataset.eliminar) {
            eliminarLibro(boton.dataset.eliminar);
        }
    });
    refrescarFiltros();
    await cargarLibros(1);
});
