const CATALOGOS_ETIQUETAS = {
    dependencias: 'Dependencia',
    cargos: 'Cargo',
    eps: 'EPS',
    pensiones: 'Fondo de pensión',
    arl: 'ARL',
};
let CATALOGOS = {};
let EMPLEADOS = new Map();
let ID_EDITANDO = null;

const opciones = (lista) => (lista || []).map((i) => ({ valor: i.id, texto: i.nombre }));

function definicionesFiltros() {
    return [
        { nombre: 'q', etiqueta: 'Nombre', placeholder: 'Buscar por nombre…' },
        { nombre: 'dependencia', etiqueta: 'Dependencia', tipo: 'select', opciones: opciones(CATALOGOS.dependencias), vacio: 'Todas' },
        { nombre: 'cargo', etiqueta: 'Cargo', tipo: 'select', opciones: opciones(CATALOGOS.cargos), vacio: 'Todos' },
        { nombre: 'eps', etiqueta: 'EPS', tipo: 'select', opciones: opciones(CATALOGOS.eps), vacio: 'Todas' },
        { nombre: 'pension', etiqueta: 'Fondo de pensión', tipo: 'select', opciones: opciones(CATALOGOS.pensiones), vacio: 'Todos' },
        { nombre: 'arl', etiqueta: 'ARL', tipo: 'select', opciones: opciones(CATALOGOS.arl), vacio: 'Todas' },
        { nombre: 'ingreso_desde', etiqueta: 'Ingreso desde', tipo: 'date' },
        { nombre: 'ingreso_hasta', etiqueta: 'Ingreso hasta', tipo: 'date' },
        { nombre: 'salario_min', etiqueta: 'Salario mínimo', tipo: 'number', min: 0, step: 'any' },
        { nombre: 'salario_max', etiqueta: 'Salario máximo', tipo: 'number', min: 0, step: 'any' },
        {
            nombre: 'orden', etiqueta: 'Ordenar por', tipo: 'select', vacio: 'Nombre (predeterminado)', opciones: [
                { valor: 'codigo', texto: 'Código' },
                { valor: 'ingreso', texto: 'Fecha de ingreso' },
                { valor: 'salario', texto: 'Salario' },
                { valor: 'dependencia', texto: 'Dependencia' },
            ],
        },
        {
            nombre: 'dir', etiqueta: 'Sentido', tipo: 'select', vacio: 'Ascendente', opciones: [
                { valor: 'desc', texto: 'Descendente' },
            ],
        },
    ];
}

function refrescarFiltros() {
    pintarFiltros(el('filtros'), definicionesFiltros(), () => cargarEmpleados().catch(avisarError));
}

async function cargarCatalogos() {
    CATALOGOS = (await api('empleados/index.php?catalogo=todos')).catalogos;
}

async function cargarEmpleados() {
    const r = await api('empleados/index.php?' + leerFiltros(el('filtros')));
    EMPLEADOS = new Map(r.empleados.map((e) => [String(e.codigo), e]));
    el('totalEmpleados').textContent = `${r.total} empleado(s)`;
    const editar = puede('nomina.editar');
    el('tablaEmpleados').innerHTML = r.empleados.length
        ? r.empleados.map((e) => `<tr>
            <td>${esc(e.codigo)}</td>
            <td class="fw-semibold">${esc(e.nombre_completo)}</td>
            <td>${esc(e.dependencia)}</td>
            <td>${esc(e.cargo)}</td>
            <td>${fechaCorta(e.fecha_ingreso)}</td>
            <td>${esc(e.eps)}</td>
            <td>${esc(e.pension)}</td>
            <td>${esc(e.arl)}</td>
            <td class="text-end">${pesos(e.salario)}</td>
            <td class="text-end acciones">${editar ? `
                <button class="btn btn-sm btn-outline-primary" data-editar="${esc(e.codigo)}" title="Editar"><i class="bi bi-pencil"></i></button>
                <button class="btn btn-sm btn-outline-danger" data-eliminar="${esc(e.codigo)}" title="Eliminar"><i class="bi bi-trash"></i></button>` : ''}
            </td></tr>`).join('')
        : filaVacia(10, 'No hay empleados con los filtros aplicados.');
}

function llenarSelectosFormulario() {
    llenarSelect(el('fDependencia'), CATALOGOS.dependencias || [], { vacio: 'Seleccione…' });
    llenarSelect(el('fCargo'), CATALOGOS.cargos || [], { vacio: 'Seleccione…' });
    llenarSelect(el('fEps'), CATALOGOS.eps || [], { vacio: 'Seleccione…' });
    llenarSelect(el('fPension'), CATALOGOS.pensiones || [], { vacio: 'Seleccione…' });
    llenarSelect(el('fArl'), CATALOGOS.arl || [], { vacio: 'Seleccione…' });
}

function abrirEmpleado(codigo = null) {
    ID_EDITANDO = codigo;
    llenarSelectosFormulario();
    const formulario = el('formEmpleado');
    formulario.reset();
    el('tituloEmpleado').textContent = codigo ? 'Editar empleado' : 'Nuevo empleado';
    el('fCodigo').disabled = Boolean(codigo);
    if (codigo) {
        const e = EMPLEADOS.get(String(codigo));
        el('fCodigo').value = e.codigo;
        el('fNombre').value = e.nombre_completo;
        el('fDependencia').value = e.id_dependencia;
        el('fCargo').value = e.id_cargo;
        el('fIngreso').value = e.fecha_ingreso;
        el('fEps').value = e.id_eps;
        el('fPension').value = e.id_pension;
        el('fArl').value = e.id_arl;
        el('fSalario').value = e.salario;
    }
    modal('modalEmpleado').show();
}

async function guardarEmpleado(evento) {
    evento.preventDefault();
    if (!evento.target.checkValidity()) {
        evento.target.reportValidity();
        return;
    }
    const datos = {
        codigo: el('fCodigo').value,
        nombre_completo: el('fNombre').value.trim(),
        id_dependencia: el('fDependencia').value,
        id_cargo: el('fCargo').value,
        fecha_ingreso: el('fIngreso').value,
        id_eps: el('fEps').value,
        id_pension: el('fPension').value,
        id_arl: el('fArl').value,
        salario: el('fSalario').value,
    };
    try {
        const r = await api('empleados/index.php', { metodo: ID_EDITANDO ? 'PUT' : 'POST', datos });
        modal('modalEmpleado').hide();
        mostrarAviso(r.mensaje);
        await cargarEmpleados();
    } catch (error) {
        avisarError(error);
    }
}

async function eliminarEmpleado(codigo) {
    if (!window.confirm(`¿Eliminar al empleado ${codigo}? Esta acción no se puede deshacer.`)) {
        return;
    }
    try {
        const r = await api(`empleados/index.php?id=${encodeURIComponent(codigo)}`, { metodo: 'DELETE' });
        mostrarAviso(r.mensaje);
        await cargarEmpleados();
    } catch (error) {
        avisarError(error);
    }
}

function pintarCatalogo() {
    const clave = el('fCatalogo').value;
    const lista = CATALOGOS[clave] || [];
    el('listaCatalogo').innerHTML = lista.length
        ? lista.map((i) => `<li class="list-group-item d-flex justify-content-between align-items-center gap-2">
            <span>${esc(i.nombre)}</span>
            <span class="btn-group btn-group-sm">
                <button class="btn btn-outline-primary" data-cat-editar="${esc(i.id)}" title="Renombrar"><i class="bi bi-pencil"></i></button>
                <button class="btn btn-outline-danger" data-cat-eliminar="${esc(i.id)}" title="Eliminar"><i class="bi bi-trash"></i></button>
            </span></li>`).join('')
        : '<li class="list-group-item text-secondary">Sin registros.</li>';
}

async function recargarTodo() {
    await cargarCatalogos();
    refrescarFiltros();
    pintarCatalogo();
    await cargarEmpleados();
}

async function operarCatalogo(accion, id = null) {
    const clave = el('fCatalogo').value;
    try {
        if (accion === 'agregar') {
            const nombre = el('fNuevoCatalogo').value.trim();
            if (nombre === '') {
                throw new Error('Escriba un nombre para el registro');
            }
            const r = await api('empleados/index.php', { metodo: 'POST', datos: { catalogo: clave, nombre } });
            el('fNuevoCatalogo').value = '';
            mostrarAviso(r.mensaje);
        } else if (accion === 'renombrar') {
            const actual = (CATALOGOS[clave] || []).find((i) => String(i.id) === String(id));
            const nombre = window.prompt('Nuevo nombre', actual ? actual.nombre : '');
            if (nombre === null || nombre.trim() === '') {
                return;
            }
            const r = await api('empleados/index.php', { metodo: 'PUT', datos: { catalogo: clave, id, nombre: nombre.trim() } });
            mostrarAviso(r.mensaje);
        } else {
            if (!window.confirm('¿Eliminar este registro del catálogo?')) {
                return;
            }
            const r = await api(`empleados/index.php?catalogo=${encodeURIComponent(clave)}&id=${encodeURIComponent(id)}`, { metodo: 'DELETE' });
            mostrarAviso(r.mensaje);
        }
        await recargarTodo();
    } catch (error) {
        avisarError(error);
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    if (!await iniciarPagina('empleados.html', 'nomina.consultar')) {
        return;
    }
    const editar = puede('nomina.editar');
    el('btnNuevo').classList.toggle('d-none', !editar);
    el('btnCatalogos').classList.toggle('d-none', !editar);
    el('btnCsv').onclick = () => descargarCsv('empleados/index.php', leerFiltros(el('filtros'))).catch(avisarError);
    el('btnNuevo').onclick = () => abrirEmpleado();
    el('btnCatalogos').onclick = () => {
        pintarCatalogo();
        modal('modalCatalogo').show();
    };
    el('formEmpleado').addEventListener('submit', guardarEmpleado);
    el('fCatalogo').addEventListener('change', pintarCatalogo);
    el('btnAgregarCatalogo').onclick = () => operarCatalogo('agregar');
    el('listaCatalogo').addEventListener('click', (evento) => {
        const boton = evento.target.closest('button');
        if (!boton) {
            return;
        }
        if (boton.dataset.catEditar) {
            operarCatalogo('renombrar', boton.dataset.catEditar);
        } else if (boton.dataset.catEliminar) {
            operarCatalogo('eliminar', boton.dataset.catEliminar);
        }
    });
    el('tablaEmpleados').addEventListener('click', (evento) => {
        const boton = evento.target.closest('button');
        if (!boton) {
            return;
        }
        if (boton.dataset.editar) {
            abrirEmpleado(boton.dataset.editar);
        } else if (boton.dataset.eliminar) {
            eliminarEmpleado(boton.dataset.eliminar);
        }
    });
    await recargarTodo().catch(avisarError);
});
