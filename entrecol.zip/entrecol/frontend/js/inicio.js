const PALETA = ['#6366f1', '#22c55e', '#f59e0b', '#ef4444', '#06b6d4', '#a855f7', '#ec4899', '#84cc16', '#14b8a6', '#f97316', '#3b82f6', '#eab308'];

function dibujarGrafico(canvas, grafico, opciones = {}) {
    const circular = grafico.tipo === 'pie';
    return new Chart(el(canvas), {
        type: grafico.tipo,
        data: {
            labels: grafico.etiquetas,
            datasets: grafico.series.map((serie, i) => ({
                label: serie.nombre,
                data: serie.datos,
                backgroundColor: circular ? grafico.etiquetas.map((_, k) => PALETA[k % PALETA.length]) : PALETA[i % PALETA.length],
                borderRadius: circular ? 0 : 6,
                borderWidth: circular ? 2 : 0,
            })),
        },
        options: { responsive: true, maintainAspectRatio: false, ...opciones },
    });
}

const cargarTarjeta = (permiso, ruta, accion) => (puede(permiso)
    ? api(ruta).then(accion).catch(() => {})
    : Promise.resolve());

document.addEventListener('DOMContentLoaded', async () => {
    if (!await iniciarPagina('inicio.html')) {
        return;
    }
    el('saludo').textContent = `Bienvenido, ${SESION.usuario.nombre}. Resumen general de EntreCOL+.`;
    const verGraficos = puede('reportes.consultar');
    ['tarjetaGrafico', 'tarjetaSalario', 'tarjetaAnio'].forEach((id) => el(id).parentElement.classList.toggle('d-none', !verGraficos));

    await Promise.all([
        cargarTarjeta('nomina.consultar', 'empleados/index.php', (r) => {
            el('stEmpleados').textContent = r.total;
        }),
        cargarTarjeta('peliculas.consultar', 'peliculas/index.php', (r) => {
            el('stPeliculas').textContent = r.total;
        }),
        cargarTarjeta('libros.consultar', 'libros/index.php', (r) => {
            el('stLibros').textContent = r.total;
        }),
        cargarTarjeta('reportes.consultar', 'reportes/index.php?tipo=por_dependencia', (r) => {
            dibujarGrafico('graficoInicio', r.reporte.grafico, { plugins: { legend: { position: 'bottom' } } });
        }),
        cargarTarjeta('reportes.consultar', 'reportes/index.php?tipo=salario_promedio_cargo', (r) => {
            dibujarGrafico('graficoSalario', r.reporte.grafico, {
                indexAxis: 'y',
                plugins: {
                    legend: { display: false },
                    tooltip: { callbacks: { label: (contexto) => pesos(contexto.raw) } },
                },
                scales: { x: { ticks: { callback: (valor) => pesos(valor) } } },
            });
        }),
        cargarTarjeta('reportes.consultar', 'reportes/index.php?tipo=peliculas_por_anio', (r) => {
            dibujarGrafico('graficoAnio', r.reporte.grafico, {
                plugins: { legend: { display: false } },
                scales: { x: { ticks: { autoSkip: true, maxTicksLimit: 14, maxRotation: 0 } } },
            });
        }),
    ]);
});
