function definicionesFiltros() {
    return [
        { nombre: 'modulo', etiqueta: 'Módulo', placeholder: 'Ej.: nomina, libros…' },
        { nombre: 'accion', etiqueta: 'Acción', tipo: 'select', vacio: 'Todas', opciones: [
            { valor: 'INSERT', texto: 'Crear' },
            { valor: 'UPDATE', texto: 'Actualizar' },
            { valor: 'DELETE', texto: 'Eliminar' },
            { valor: 'LOGIN', texto: 'Inicio de sesión' },
            { valor: 'IMPORT', texto: 'Importación' },
        ] },
        { nombre: 'usuario', etiqueta: 'Usuario', placeholder: 'Nombre de usuario' },
        { nombre: 'desde', etiqueta: 'Desde', tipo: 'date' },
        { nombre: 'hasta', etiqueta: 'Hasta', tipo: 'date' },
    ];
}

async function cargarAuditoria() {
    const r = await api('auditoria/index.php?' + leerFiltros(el('filtros')));
    el('totalEventos').textContent = `${r.registros.length} evento(s)`;
    el('tablaAuditoria').innerHTML = r.registros.length
        ? r.registros.map((a) => `<tr>
            <td>${esc(String(a.fecha_hora).slice(0, 19).replace('T', ' '))}</td>
            <td>${esc(a.usuario || '')}</td>
            <td><span class="badge text-bg-secondary">${esc(a.accion)}</span></td>
            <td>${esc(a.modulo)}</td>
            <td class="font-monospace small">${esc(a.registro_afectado ?? '')}</td>
            <td class="texto-largo">${esc(a.descripcion ?? '')}</td>
            <td class="font-monospace small">${esc(a.ip ?? '')}</td>
            </tr>`).join('')
        : filaVacia(7, 'No hay eventos con los filtros aplicados.');
}

document.addEventListener('DOMContentLoaded', async () => {
    if (!await iniciarPagina('auditoria.html', 'auditoria.consultar')) {
        return;
    }
    pintarFiltros(el('filtros'), definicionesFiltros(), () => cargarAuditoria().catch(avisarError));
    await cargarAuditoria().catch(avisarError);
});
