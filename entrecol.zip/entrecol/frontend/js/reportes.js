const ORDEN = { nombre: 'orden', etiqueta: 'Orden', tipo: 'select', opciones: [['asc', 'Ascendente'], ['desc', 'Descendente']] };
const CODIGO = { nombre: 'codigo', etiqueta: 'Código del empleado', tipo: 'number', min: 1, valor: 5021 };
const PERIODO_DESDE = { nombre: 'desde', etiqueta: 'Desde (MM/AAAA)', tipo: 'text', patron: '(0[1-9]|1[0-2])/\\d{4}', ejemplo: '08/2026', valor: '08/2026' };
const PERIODO_HASTA = { nombre: 'hasta', etiqueta: 'Hasta (MM/AAAA)', tipo: 'text', patron: '(0[1-9]|1[0-2])/\\d{4}', ejemplo: '10/2026', valor: '10/2026' };
const ANIO_DESDE = { nombre: 'desde', etiqueta: 'Año desde', tipo: 'number', min: 1000, max: 2100 };
const ANIO_HASTA = { nombre: 'hasta', etiqueta: 'Año hasta', tipo: 'number', min: 1000, max: 2100 };
const GENERO = { nombre: 'genero', etiqueta: 'Género', tipo: 'genero' };
const MODO = { nombre: 'modo', etiqueta: 'Tipo', tipo: 'select', opciones: [['mejores', 'Mejor calificados'], ['peores', 'Peor calificados']] };

const REPORTES = [
    { valor: 'empleados', texto: 'Nómina completa', campos: [ORDEN] },
    { valor: 'por_dependencia', texto: 'Empleados por dependencia', campos: [ORDEN] },
    { valor: 'cargo_dependencia', texto: 'Cargos por dependencia', campos: [ORDEN] },
    { valor: 'info_personal', texto: 'Información personal de un empleado', campos: [CODIGO] },
    { valor: 'frecuencia_eps', texto: 'Frecuencia por EPS', campos: [] },
    { valor: 'frecuencia_pension', texto: 'Frecuencia por fondo de pensión', campos: [] },
    { valor: 'eps_dependencia', texto: 'EPS por dependencia', campos: [] },
    { valor: 'pension_dependencia', texto: 'Fondo de pensión por dependencia', campos: [] },
    { valor: 'cargo_eps', texto: 'Cargos por EPS', campos: [ORDEN] },
    { valor: 'cargo_pension', texto: 'Cargos por fondo de pensión', campos: [ORDEN] },
    { valor: 'novedades_rango', texto: 'Novedades por rango de periodos', campos: [PERIODO_DESDE, PERIODO_HASTA, ORDEN] },
    { valor: 'novedades_cantidad', texto: 'Cantidad de novedades por periodo', campos: [PERIODO_DESDE, PERIODO_HASTA] },
    { valor: 'peliculas_genero', texto: 'Películas por género', campos: [GENERO, ANIO_DESDE, ANIO_HASTA, ORDEN] },
    { valor: 'top_libros', texto: 'Libros con mejor calificación', campos: [{ nombre: 'n', etiqueta: 'Cantidad (N, máximo 500)', tipo: 'number', min: 1, max: 500, valor: 10 }] },
    { valor: 'top_anio', texto: 'Mejores o peores libros por año', campos: [MODO, { nombre: 'n', etiqueta: 'Cantidad por año (máximo 20)', tipo: 'number', min: 1, max: 20, valor: 5 }] },
    { valor: 'peliculas_n_generos', texto: 'Películas con N géneros', campos: [{ nombre: 'n', etiqueta: 'Cantidad de géneros (máximo 20)', tipo: 'number', min: 1, max: 20, valor: 2 }, ORDEN] },
    { valor: 'frecuencia_generos', texto: 'Frecuencia de géneros de películas', campos: [] },
    { valor: 'libros_anio', texto: 'Libros por año de publicación', campos: [ANIO_DESDE, ANIO_HASTA] },
    { valor: 'salario_promedio_cargo', texto: 'Salario promedio por cargo', campos: [] },
    { valor: 'peliculas_por_anio', texto: 'Películas por año', campos: [] },
];

let GENEROS = [];
let GRAFICO = null;
let URL_PDF = null;

const fallo = (err) => mostrarAviso(err.message, 'danger');
const reporteActual = () => REPORTES.find((r) => r.valor === el('fTipo').value);

function campoHtml(c) {
    const id = 'campo_' + c.nombre;
    const etiqueta = `<label class="form-label" for="${id}">${esc(c.etiqueta)}</label>`;
    let control;
    if (c.tipo === 'select' || c.tipo === 'genero') {
        const opciones = c.tipo === 'genero'
            ? [['', 'Seleccione un género'], ...GENEROS.map((g) => [g, g])]
            : c.opciones;
        control = `<select class="form-select" id="${id}" data-campo="${esc(c.nombre)}">`
            + opciones.map(([v, t]) => `<option value="${esc(v)}">${esc(t)}</option>`).join('') + '</select>';
    } else {
        const atributos = [
            c.min !== undefined ? `min="${c.min}"` : '',
            c.max !== undefined ? `max="${c.max}"` : '',
            c.patron ? `pattern="${esc(c.patron)}" placeholder="${esc(c.ejemplo)}"` : '',
        ].join(' ');
        control = `<input class="form-control" id="${id}" data-campo="${esc(c.nombre)}" type="${c.tipo}" ${atributos} value="${esc(c.valor ?? '')}">`;
    }
    return `<div class="col-lg-3 col-md-6">${etiqueta}${control}</div>`;
}

function pintarCampos() {
    el('camposReporte').innerHTML = reporteActual().campos.map(campoHtml).join('');
    el('tarjetaPdf').classList.add('d-none');
    el('tarjetaResultado').classList.add('d-none');
    el('tarjetaGrafico').classList.add('d-none');
}

function parametrosReporte() {
    const p = new URLSearchParams({ tipo: el('fTipo').value });
    document.querySelectorAll('#camposReporte [data-campo]').forEach((c) => {
        if (c.value !== '') {
            p.set(c.dataset.campo, c.value);
        }
    });
    return p.toString();
}

function pintarGrafico(grafico) {
    if (GRAFICO) {
        GRAFICO.destroy();
        GRAFICO = null;
    }
    el('tarjetaGrafico').classList.toggle('d-none', !grafico);
    if (!grafico) {
        return;
    }
    GRAFICO = new Chart(el('grafico'), {
        type: grafico.tipo === 'pie' ? 'pie' : 'bar',
        data: {
            labels: grafico.etiquetas,
            datasets: grafico.series.map((s) => ({ label: s.nombre, data: s.datos })),
        },
        options: { responsive: true, maintainAspectRatio: false },
    });
}

function pintarReporte(reporte) {
    el('reporteTitulo').textContent = reporte.titulo;
    el('reporteTotal').textContent = `${reporte.total} registro(s)`;
    const columnas = reporte.columnas.length;
    el('reporteTabla').innerHTML = `<thead class="table-light"><tr>${reporte.columnas.map((c) => `<th>${esc(c)}</th>`).join('')}</tr></thead>`
        + '<tbody>' + reporte.grupos.map((g) => {
            const encabezado = g.encabezado !== null
                ? `<tr class="table-primary"><td colspan="${columnas}"><strong>${esc(g.encabezado)}</strong> (${g.total})</td></tr>`
                : '';
            return encabezado + g.filas.map((f) => `<tr>${f.map((c) => `<td>${esc(c)}</td>`).join('')}</tr>`).join('');
        }).join('') + '</tbody>';
    el('tarjetaResultado').classList.remove('d-none');
    pintarGrafico(reporte.grafico);
}

async function generarReporte() {
    const { reporte } = await api('reportes/index.php?' + parametrosReporte());
    pintarReporte(reporte);
}

async function obtenerPdf() {
    const respuesta = await fetch(API + 'reportes/pdf.php?' + parametrosReporte(), { credentials: 'same-origin' });
    if (respuesta.status === 401) {
        location.href = 'login.html';
        throw new Error('Su sesión expiró');
    }
    if (!respuesta.ok || (respuesta.headers.get('Content-Type') ?? '').includes('application/json')) {
        const json = await respuesta.json().catch(() => ({}));
        throw new Error(json.mensaje || 'No fue posible generar el PDF');
    }
    return respuesta.blob();
}

async function vistaPreviaPdf() {
    const blob = await obtenerPdf();
    if (URL_PDF) {
        URL.revokeObjectURL(URL_PDF);
    }
    URL_PDF = URL.createObjectURL(blob);
    el('visorPdf').src = URL_PDF;
    el('tarjetaPdf').classList.remove('d-none');
}

async function descargarPdf() {
    const blob = await obtenerPdf();
    const enlace = document.createElement('a');
    enlace.href = URL.createObjectURL(blob);
    enlace.download = `reporte_${el('fTipo').value}.pdf`;
    document.body.appendChild(enlace);
    enlace.click();
    enlace.remove();
    setTimeout(() => URL.revokeObjectURL(enlace.href), 10000);
}

async function imprimirPdf() {
    const blob = await obtenerPdf();
    const url = URL.createObjectURL(blob);
    const marco = document.createElement('iframe');
    marco.style.display = 'none';
    marco.src = url;
    marco.onload = () => {
        marco.contentWindow.focus();
        marco.contentWindow.print();
        setTimeout(() => { marco.remove(); URL.revokeObjectURL(url); }, 60000);
    };
    document.body.appendChild(marco);
}

document.addEventListener('DOMContentLoaded', async () => {
    if (!await iniciarPagina('reportes.html', 'reportes.consultar')) {
        return;
    }
    const exporta = puede('reportes.exportar_pdf');
    document.querySelectorAll('.pdf-accion').forEach((b) => b.classList.toggle('d-none', !exporta));

    llenarSelect(el('fTipo'), REPORTES, { vacio: 'Seleccione un reporte', valor: 'valor', texto: 'texto' });
    el('fTipo').addEventListener('change', pintarCampos);
    el('btnGenerar').onclick = () => generarReporte().catch(fallo);
    el('btnVistaPrevia').onclick = () => vistaPreviaPdf().catch(fallo);
    el('btnDescargar').onclick = () => descargarPdf().catch(fallo);
    el('btnImprimir').onclick = () => imprimirPdf().catch(fallo);

    try {
        GENEROS = (await api('reportes/index.php?generos=1')).generos;
        el('fTipo').value = 'por_dependencia';
        pintarCampos();
        await generarReporte();
    } catch (err) {
        fallo(err);
    }
});
