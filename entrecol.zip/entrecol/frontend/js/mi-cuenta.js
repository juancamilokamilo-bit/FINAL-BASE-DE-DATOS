async function cargarCuenta() {
    const { cuenta } = await api('auth/mi_cuenta.php');
    el('cuentaNombre').textContent = cuenta.nombre;
    el('cuentaUsuario').textContent = cuenta.usuario;
    el('cuentaRol').textContent = cuenta.rol;
    el('cuenta2fa').innerHTML = cuenta.segundo_factor
        ? '<span class="badge text-bg-success">Activa</span>'
        : '<span class="badge text-bg-secondary">Inactiva</span> <a class="small" href="configurar-2fa.html">Activar</a>';
}

async function guardarClave(evento) {
    evento.preventDefault();
    const formulario = evento.target;
    if (!formulario.checkValidity()) {
        formulario.reportValidity();
        return;
    }
    const nueva = el('claveNueva').value;
    if (nueva !== el('confirmar').value) {
        avisarError(new Error('La confirmación no coincide con la nueva contraseña'));
        return;
    }
    el('btnGuardarClave').disabled = true;
    try {
        const r = await api('auth/mi_cuenta.php', {
            metodo: 'POST',
            datos: {
                clave_actual: el('claveActual').value,
                clave_nueva: nueva,
                confirmar: el('confirmar').value,
            },
        });
        formulario.reset();
        mostrarAviso(r.mensaje);
    } catch (error) {
        avisarError(error);
    } finally {
        el('btnGuardarClave').disabled = false;
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    if (!await iniciarPagina('mi-cuenta.html')) {
        return;
    }
    el('formClave').addEventListener('submit', guardarClave);
    await cargarCuenta().catch(avisarError);
});
