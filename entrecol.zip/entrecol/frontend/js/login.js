document.addEventListener('DOMContentLoaded', async () => {
    const sesion = await fetch(API + 'auth/sesion.php', { credentials: 'same-origin' }).then((r) => r.json()).catch(() => ({ ok: false }));
    if (sesion.ok) {
        location.href = 'inicio.html';
        return;
    }
    const imagen = el('imgCaptcha');
    const recargar = () => {
        imagen.src = API + 'auth/captcha.php?v=' + Date.now();
        el('captcha').value = '';
    };
    recargar();
    el('btnRecargar').onclick = recargar;
    el('formLogin').addEventListener('submit', async (evento) => {
        evento.preventDefault();
        const formulario = evento.target;
        const error = el('error');
        const boton = el('btnEntrar');
        error.classList.add('d-none');
        boton.disabled = true;
        try {
            const respuesta = await api('auth/login.php', {
                metodo: 'POST',
                datos: {
                    usuario: formulario.usuario.value.trim(),
                    clave: formulario.clave.value,
                    captcha: formulario.captcha.value.trim(),
                },
            });
            location.href = respuesta.requiere_2fa ? 'verificar.html' : 'inicio.html';
        } catch (err) {
            error.textContent = err.message;
            error.classList.remove('d-none');
            recargar();
        } finally {
            boton.disabled = false;
        }
    });
});
