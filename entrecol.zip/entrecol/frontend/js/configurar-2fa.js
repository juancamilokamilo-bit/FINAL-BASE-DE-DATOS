document.addEventListener('DOMContentLoaded', async () => {
    if (!await iniciarPagina('configurar-2fa.html')) {
        return;
    }

    const cargarEstado = async () => {
        const estado = await api('auth/configurar_2fa.php?accion=estado');
        el('estado').innerHTML = estado.activo
            ? '<span class="badge text-bg-success">Activo</span>'
            : '<span class="badge text-bg-secondary">Inactivo</span>';
        el('zonaDesactivar').classList.toggle('d-none', !estado.activo);
        el('zonaActivar').classList.toggle('d-none', estado.activo);
        if (!estado.activo) {
            const inicio = await api('auth/configurar_2fa.php?accion=iniciar');
            el('secreto').textContent = inicio.secreto;
            el('qr').innerHTML = '';
            new QRCode(el('qr'), { text: inicio.uri, width: 200, height: 200 });
        }
    };

    el('formConfirmar').addEventListener('submit', async (evento) => {
        evento.preventDefault();
        try {
            const respuesta = await api('auth/configurar_2fa.php', {
                metodo: 'POST',
                datos: { accion: 'confirmar', codigo: el('codigoConfirmar').value.trim() },
            });
            el('listaCodigos').innerHTML = respuesta.codigos
                .map((c) => `<li class="list-group-item font-monospace">${esc(c)}</li>`).join('');
            el('zonaCodigos').classList.remove('d-none');
            mostrarAviso(respuesta.mensaje);
            await cargarEstado();
        } catch (err) {
            mostrarAviso(err.message, 'danger');
        }
    });

    el('formDesactivar').addEventListener('submit', async (evento) => {
        evento.preventDefault();
        try {
            const respuesta = await api('auth/configurar_2fa.php', {
                metodo: 'POST',
                datos: { accion: 'desactivar', clave: el('claveDesactivar').value },
            });
            el('claveDesactivar').value = '';
            el('zonaCodigos').classList.add('d-none');
            mostrarAviso(respuesta.mensaje);
            await cargarEstado();
        } catch (err) {
            mostrarAviso(err.message, 'danger');
        }
    });

    await cargarEstado();
});
