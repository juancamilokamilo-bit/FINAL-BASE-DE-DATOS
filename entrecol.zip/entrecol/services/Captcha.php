<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Sesion.php';

function captcha_generar_imagen(): void
{
    iniciar_sesion_segura();
    $alfabeto = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $codigo = '';
    for ($i = 0; $i < 5; $i++) {
        $codigo .= $alfabeto[random_int(0, strlen($alfabeto) - 1)];
    }
    $_SESSION['captcha'] = ['codigo' => $codigo, 'expira' => time() + CAPTCHA_EXPIRA_SEGUNDOS];

    $pequena = imagecreatetruecolor(60, 20);
    imagefill($pequena, 0, 0, imagecolorallocate($pequena, 255, 255, 255));
    imagestring($pequena, 5, 6, 3, $codigo, imagecolorallocate($pequena, 20, 50, 110));

    $imagen = imagecreatetruecolor(150, 50);
    imagefill($imagen, 0, 0, imagecolorallocate($imagen, 240, 244, 250));
    imagecopyresampled($imagen, $pequena, 0, 0, 0, 0, 150, 50, 60, 20);

    for ($i = 0; $i < 6; $i++) {
        imageline(
            $imagen,
            random_int(0, 150), random_int(0, 50),
            random_int(0, 150), random_int(0, 50),
            imagecolorallocate($imagen, random_int(120, 200), random_int(120, 200), random_int(120, 200))
        );
    }

    header('Content-Type: image/png');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    imagepng($imagen);
    imagedestroy($pequena);
    imagedestroy($imagen);
}

function captcha_validar(string $respuesta): bool
{
    iniciar_sesion_segura();
    $captcha = $_SESSION['captcha'] ?? null;
    unset($_SESSION['captcha']);
    if ($captcha === null || $captcha['expira'] < time()) {
        return false;
    }
    return hash_equals($captcha['codigo'], strtoupper(trim($respuesta)));
}
