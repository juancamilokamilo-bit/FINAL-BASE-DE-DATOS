<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Sesion.php';

function auditar(string $accion, string $modulo, ?string $registro = null, ?string $descripcion = null, ?int $idUsuario = null): void
{
    $idUsuario ??= usuario_actual()['id'] ?? null;
    $stmt = conexion()->prepare(
        'INSERT INTO auditoria (id_usuario, accion, modulo, registro_afectado, descripcion, ip) VALUES (?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([$idUsuario, $accion, $modulo, $registro, $descripcion, $_SERVER['REMOTE_ADDR'] ?? null]);
}
