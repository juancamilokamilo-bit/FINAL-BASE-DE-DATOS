<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Respuesta.php';

function iniciar_sesion_segura(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_name('ENTRECOL_SID');
        session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Strict']);
        session_start();
    }
}

function usuario_actual(): ?array
{
    iniciar_sesion_segura();
    return $_SESSION['usuario'] ?? null;
}

function tiene_permiso(string $permiso): bool
{
    return in_array($permiso, usuario_actual()['permisos'] ?? [], true);
}

function validar_csrf(): void
{
    iniciar_sesion_segura();
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $token)) {
        error_api('Token de seguridad inválido. Recargue la página.', 419);
    }
}

function requerir_sesion(?string $permiso = null): array
{
    $usuario = usuario_actual();
    if ($usuario === null) {
        error_api('Debe iniciar sesión', 401);
    }
    if ($permiso !== null && !tiene_permiso($permiso)) {
        error_api('No tiene permisos para realizar esta operación', 403);
    }
    if (in_array($_SERVER['REQUEST_METHOD'] ?? '', ['POST', 'PUT', 'DELETE'], true)) {
        validar_csrf();
    }
    return $usuario;
}

function token_csrf(): string
{
    iniciar_sesion_segura();
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function iniciar_sesion_usuario(array $fila): void
{
    iniciar_sesion_segura();
    session_regenerate_id(true);
    $_SESSION = [];
    $_SESSION['usuario'] = [
        'id' => (int)$fila['id_usuario'],
        'nombre' => $fila['nombre_completo'],
        'usuario' => $fila['nombre_usuario'],
        'rol' => $fila['rol'],
        'permisos' => $fila['permisos'],
    ];
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    conexion()->prepare('UPDATE usuario SET ultimo_acceso = NOW() WHERE id_usuario = ?')->execute([$fila['id_usuario']]);
}

function cerrar_sesion(): void
{
    iniciar_sesion_segura();
    $_SESSION = [];
    session_destroy();
}

function cargar_usuario_completo(int $idUsuario): ?array
{
    $stmt = conexion()->prepare(
        'SELECT u.id_usuario, u.nombre_completo, u.nombre_usuario, u.password_hash, u.activo, u.intentos_fallidos,
                u.bloqueado_hasta, u.totp_activo, u.totp_secreto, r.nombre AS rol, u.id_rol
         FROM usuario u JOIN rol r ON r.id_rol = u.id_rol WHERE u.id_usuario = ?'
    );
    $stmt->execute([$idUsuario]);
    $fila = $stmt->fetch();
    if (!$fila) {
        return null;
    }
    $fila['permisos'] = permisos_de_rol((int)$fila['id_rol']);
    return $fila;
}

function permisos_de_rol(int $idRol): array
{
    $stmt = conexion()->prepare(
        'SELECT p.codigo FROM rol_permiso rp JOIN permiso p ON p.id_permiso = rp.id_permiso WHERE rp.id_rol = ?'
    );
    $stmt->execute([$idRol]);
    return array_column($stmt->fetchAll(), 'codigo');
}
