<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

function generar_codigos_recuperacion(int $idUsuario): array
{
    $pdo = conexion();
    $pdo->prepare('DELETE FROM codigo_recuperacion WHERE id_usuario = ?')->execute([$idUsuario]);
    $insertar = $pdo->prepare('INSERT INTO codigo_recuperacion (id_usuario, codigo_hash) VALUES (?, ?)');
    $codigos = [];
    for ($i = 0; $i < 8; $i++) {
        $hex = strtoupper(bin2hex(random_bytes(4)));
        $insertar->execute([$idUsuario, password_hash($hex, PASSWORD_DEFAULT)]);
        $codigos[] = substr($hex, 0, 4) . '-' . substr($hex, 4, 4);
    }
    return $codigos;
}

function usar_codigo_recuperacion(int $idUsuario, string $codigo): bool
{
    $limpio = strtoupper(str_replace(['-', ' '], '', $codigo));
    $pdo = conexion();
    $consulta = $pdo->prepare('SELECT id_codigo, codigo_hash FROM codigo_recuperacion WHERE id_usuario = ? AND usado = 0');
    $consulta->execute([$idUsuario]);
    foreach ($consulta->fetchAll() as $fila) {
        if (password_verify($limpio, $fila['codigo_hash'])) {
            $pdo->prepare('UPDATE codigo_recuperacion SET usado = 1 WHERE id_codigo = ?')->execute([$fila['id_codigo']]);
            return true;
        }
    }
    return false;
}
