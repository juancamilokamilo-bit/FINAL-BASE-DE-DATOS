<?php
declare(strict_types=1);

const BASE32_ALFABETO = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function base32_codificar(string $binario): string
{
    $bits = '';
    foreach (str_split($binario) as $caracter) {
        $bits .= str_pad(decbin(ord($caracter)), 8, '0', STR_PAD_LEFT);
    }
    $salida = '';
    foreach (str_split($bits, 5) as $trozo) {
        $salida .= BASE32_ALFABETO[bindec(str_pad($trozo, 5, '0'))];
    }
    return $salida;
}

function base32_decodificar(string $texto): string
{
    $bits = '';
    foreach (str_split(strtoupper($texto)) as $caracter) {
        $posicion = strpos(BASE32_ALFABETO, $caracter);
        if ($posicion !== false) {
            $bits .= str_pad(decbin($posicion), 5, '0', STR_PAD_LEFT);
        }
    }
    $binario = '';
    foreach (str_split($bits, 8) as $byte) {
        if (strlen($byte) === 8) {
            $binario .= chr(bindec($byte));
        }
    }
    return $binario;
}

function totp_generar_secreto(): string
{
    return base32_codificar(random_bytes(20));
}

function totp_codigo(string $secreto, int $momento, int $digitos = 6): string
{
    $contador = intdiv($momento, 30);
    $binario = pack('N2', $contador >> 32, $contador & 0xFFFFFFFF);
    $hash = hash_hmac('sha1', $binario, base32_decodificar($secreto), true);
    $desplazamiento = ord($hash[19]) & 0x0F;
    $valor = ((ord($hash[$desplazamiento]) & 0x7F) << 24)
        | ((ord($hash[$desplazamiento + 1]) & 0xFF) << 16)
        | ((ord($hash[$desplazamiento + 2]) & 0xFF) << 8)
        | (ord($hash[$desplazamiento + 3]) & 0xFF);
    return str_pad((string)($valor % (10 ** $digitos)), $digitos, '0', STR_PAD_LEFT);
}

function totp_verificar(string $secreto, string $codigo, int $ventana = 1): bool
{
    $codigo = preg_replace('/\s+/', '', $codigo);
    $ahora = time();
    for ($desfase = -$ventana; $desfase <= $ventana; $desfase++) {
        if (hash_equals(totp_codigo($secreto, $ahora + $desfase * 30), (string)$codigo)) {
            return true;
        }
    }
    return false;
}

function totp_uri(string $secreto, string $cuenta, string $emisor): string
{
    return 'otpauth://totp/' . rawurlencode($emisor . ':' . $cuenta)
        . '?secret=' . $secreto . '&issuer=' . rawurlencode($emisor) . '&digits=6&period=30';
}
