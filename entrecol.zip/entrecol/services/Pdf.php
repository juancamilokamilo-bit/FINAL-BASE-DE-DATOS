<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

function html_reporte_pdf(array $reporte): string
{
    $e = fn($valor) => htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
    $columnas = count($reporte['columnas']);
    $encabezado = '<tr>' . implode('', array_map(fn($c) => '<th>' . $e($c) . '</th>', $reporte['columnas'])) . '</tr>';
    $cuerpo = '';
    foreach ($reporte['grupos'] as $bloque) {
        if ($bloque['encabezado'] !== null) {
            $cuerpo .= '<tr class="grupo"><td colspan="' . $columnas . '">' . $e($bloque['encabezado'])
                . ' (' . (int)$bloque['total'] . ')</td></tr>';
        }
        foreach ($bloque['filas'] as $fila) {
            $cuerpo .= '<tr>' . implode('', array_map(fn($c) => '<td>' . $e($c) . '</td>', $fila)) . '</tr>';
        }
    }
    $seccionGrafico = '';
    if ($reporte['grafico'] !== null) {
        $grafico = $reporte['grafico'];
        $filasGrafico = '<tr><th>Categoría</th>'
            . implode('', array_map(fn($s) => '<th>' . $e($s['nombre']) . '</th>', $grafico['series'])) . '</tr>';
        foreach ($grafico['etiquetas'] as $i => $etiqueta) {
            $filasGrafico .= '<tr><td>' . $e($etiqueta) . '</td>'
                . implode('', array_map(fn($s) => '<td>' . $e($s['datos'][$i] ?? 0) . '</td>', $grafico['series'])) . '</tr>';
        }
        $seccionGrafico = '<h2>Datos del gráfico (' . ($grafico['tipo'] === 'pie' ? 'torta' : 'barras') . ')</h2>'
            . '<table>' . $filasGrafico . '</table>';
    }
    $generado = date('d/m/Y H:i');
    $total = (int)$reporte['total'];
    return '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>'
        . 'body{font-family:"DejaVu Sans",sans-serif;font-size:9px;color:#222}'
        . 'h1{font-size:15px;color:#1d3c6e;margin:0 0 2px 0}'
        . 'h2{font-size:11px;color:#1d3c6e;margin:12px 0 4px 0}'
        . '.meta{font-size:8px;color:#555;margin-bottom:8px}'
        . 'table{width:100%;border-collapse:collapse}'
        . 'th,td{border:1px solid #b8c2d1;padding:3px 4px;text-align:left;vertical-align:top}'
        . 'th{background:#e3eaf5;font-weight:bold}'
        . 'tr.grupo td{background:#eef3fa;font-weight:bold;color:#1d3c6e}'
        . '</style></head><body>'
        . '<h1>' . $e(APP_NOMBRE) . ' · ' . $e($reporte['titulo']) . '</h1>'
        . '<div class="meta">Generado: ' . $e($generado) . ' · Total de registros: ' . $total . '</div>'
        . '<table>' . $encabezado . $cuerpo . '</table>'
        . $seccionGrafico
        . '</body></html>';
}

function pdf_reporte(array $reporte): string
{
    $autoload = __DIR__ . '/../vendor/autoload.php';
    if (!is_file($autoload)) {
        throw new RuntimeException('Falta instalar Dompdf. Ejecute "composer install" dentro de la carpeta del proyecto.');
    }
    require_once $autoload;
    $opciones = new Dompdf\Options();
    $opciones->set('defaultFont', 'DejaVu Sans');
    $opciones->set('isRemoteEnabled', false);
    $dompdf = new Dompdf\Dompdf($opciones);
    $dompdf->loadHtml(html_reporte_pdf($reporte), 'UTF-8');
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    return $dompdf->output();
}
