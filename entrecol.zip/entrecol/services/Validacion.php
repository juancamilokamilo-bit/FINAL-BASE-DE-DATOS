<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Respuesta.php';

function catalogo_id(string $tabla, string $columna, string $columnaId, string $valor): int
{
    static $cache = [];
    $clave = $tabla . '|' . mb_strtolower($valor);
    if (isset($cache[$clave])) {
        return $cache[$clave];
    }
    $pdo = conexion();
    $stmt = $pdo->prepare(
        "INSERT INTO $tabla ($columna) VALUES (?) ON DUPLICATE KEY UPDATE $columnaId = LAST_INSERT_ID($columnaId)"
    );
    $stmt->execute([$valor]);
    $cache[$clave] = (int)$pdo->lastInsertId();
    return $cache[$clave];
}

function consultar_paginado(PDO $pdo, string $sql, array $params, int $limite, int $desplazamiento): array
{
    $stmt = $pdo->prepare($sql);
    foreach (array_values($params) as $i => $valor) {
        $stmt->bindValue($i + 1, $valor);
    }
    $stmt->bindValue(count($params) + 1, $limite, PDO::PARAM_INT);
    $stmt->bindValue(count($params) + 2, $desplazamiento, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function contar_registros(PDO $pdo, string $sql, array $params): int
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function pagina_actual(): int
{
    return max(1, entero($_GET['pagina'] ?? 1) ?? 1);
}

function filtros_sql(array $reglas, array $entrada): array
{
    $condiciones = [];
    $parametros = [];
    foreach ($reglas as $nombre => [$sql, $tipo]) {
        if (!isset($entrada[$nombre]) || is_array($entrada[$nombre]) || trim((string)$entrada[$nombre]) === '') {
            continue;
        }
        $valor = match ($tipo) {
            'like' => '%' . texto($entrada[$nombre], 300) . '%',
            'texto' => texto($entrada[$nombre], 200),
            'entero' => entero($entrada[$nombre]),
            'decimal' => decimal($entrada[$nombre]),
            'fecha' => fecha_iso($entrada[$nombre]),
            'periodo' => periodo_mes($entrada[$nombre]),
            default => throw new InvalidArgumentException('Tipo de filtro no válido'),
        };
        if ($valor === null || $valor === false) {
            throw new InvalidArgumentException("El valor del filtro $nombre no es válido");
        }
        $condiciones[] = $sql;
        array_push($parametros, ...array_fill(0, substr_count($sql, '?'), $valor));
    }
    return [$condiciones ? ' WHERE ' . implode(' AND ', $condiciones) : '', $parametros];
}

function orden_columna(array $permitidas, mixed $clave, string $defecto): string
{
    return is_scalar($clave) ? ($permitidas[(string)$clave] ?? $defecto) : $defecto;
}

function ejecutar_api(callable $accion): void
{
    try {
        $accion();
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            error_api('No se puede completar la operación: el registro tiene datos relacionados o ya existe', 409);
        }
        error_api('Error interno de base de datos', 500);
    } catch (InvalidArgumentException $e) {
        error_api($e->getMessage(), 422);
    } catch (RuntimeException $e) {
        error_api($e->getMessage(), 400);
    }
}

function requerir_campos(array $datos, array $campos): void
{
    $faltantes = [];
    foreach ($campos as $campo) {
        if (!isset($datos[$campo]) || trim((string)$datos[$campo]) === '') {
            $faltantes[] = $campo;
        }
    }
    if ($faltantes) {
        throw new InvalidArgumentException('Campos obligatorios: ' . implode(', ', $faltantes));
    }
}
