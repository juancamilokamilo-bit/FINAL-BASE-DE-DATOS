<?php
declare(strict_types=1);

function responder(array $datos, int $codigo = 200): never
{
    http_response_code($codigo);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function error_api(string $mensaje, int $codigo = 400, array $extra = []): never
{
    responder(array_merge(['ok' => false, 'mensaje' => $mensaje], $extra), $codigo);
}

function ok_api(array $datos = [], string $mensaje = 'Operación realizada'): never
{
    responder(array_merge(['ok' => true, 'mensaje' => $mensaje], $datos));
}

function entrada(): array
{
    $tipo = $_SERVER['CONTENT_TYPE'] ?? '';
    if (str_contains($tipo, 'application/json')) {
        $datos = json_decode(file_get_contents('php://input') ?: '[]', true);
        return is_array($datos) ? $datos : [];
    }
    return $_POST;
}

function metodo_permitido(string ...$metodos): void
{
    if (!in_array($_SERVER['REQUEST_METHOD'] ?? '', $metodos, true)) {
        error_api('Método HTTP no permitido', 405);
    }
}

function texto(mixed $valor, int $maximo = 255): string
{
    return mb_substr(trim((string)($valor ?? '')), 0, $maximo);
}

function entero(mixed $valor): ?int
{
    return filter_var($valor, FILTER_VALIDATE_INT) === false ? null : (int)$valor;
}

function decimal(mixed $valor): ?float
{
    return is_numeric($valor) ? (float)$valor : null;
}

function fecha_iso(mixed $valor): string|false|null
{
    $valor = trim((string)($valor ?? ''));
    if ($valor === '') {
        return null;
    }
    $fecha = DateTimeImmutable::createFromFormat('Y-m-d', $valor);
    return ($fecha && $fecha->format('Y-m-d') === $valor) ? $valor : false;
}

function periodo_mes(mixed $valor): ?string
{
    $valor = trim((string)($valor ?? ''));
    if (!preg_match('/^(0[1-9]|1[0-2])\/(\d{4})$/', $valor, $m)) {
        return null;
    }
    return $m[2] . '-' . $m[1] . '-01';
}

function orden_sql(mixed $valor): string
{
    return strtolower((string)$valor) === 'desc' ? 'DESC' : 'ASC';
}

function enviar_csv(string $nombre, array $encabezados, array $filas): never
{
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $nombre . '_' . date('Ymd_His') . '.csv"');
    header('Cache-Control: no-store');
    $salida = fopen('php://output', 'w');
    fwrite($salida, "\xEF\xBB\xBF");
    fputcsv($salida, $encabezados, ';');
    foreach ($filas as $fila) {
        fputcsv($salida, array_values($fila), ';');
    }
    fclose($salida);
    exit;
}
