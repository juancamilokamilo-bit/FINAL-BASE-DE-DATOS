<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Respuesta.php';
require_once __DIR__ . '/Validacion.php';

const COLUMNAS_EMPLEADOS = [
    'codigo' => 'CODIGO',
    'nombre' => 'NOMBRE DEL EMPLEADO',
    'dependencia' => 'DEPENDENCIA',
    'cargo' => 'CARGO',
    'ingreso' => 'FECHA INGRESO',
    'eps' => 'EPS',
    'arl' => 'ARL',
    'pension' => 'PENSION',
    'sueldo' => 'SUELDO',
];

const COLUMNAS_NOVEDADES = [
    'codigo' => 'CODIGO',
    'inc_marca' => 'NOVEDAD INCAPACIDAD',
    'vac_marca' => 'NOVEDAD VACACIONES',
    'dias_trabajados' => 'NUMERO DIAS TRABAJADOS EN EL MES',
    'dias_incapacidad' => 'NUMERO DIAS INCAPACIDADES EN EL MES',
    'dias_vacaciones' => 'NUMERO DE DIAS VACACIONES',
    'ini_vac' => 'FECHA DE INICIO DE VACACIONES',
    'fin_vac' => 'FECHA TERMINACION DE VACACIONES',
    'ini_inc' => 'FECHA INICIO INCAPACIDAD',
    'fin_inc' => 'FECHA TERMINACION INCAPACIDAD',
    'bonificacion' => 'BONIFICACION',
    'transporte' => 'TRANSPORTE',
];

function normalizar_encabezado(string $texto): string
{
    $texto = mb_strtoupper(trim($texto));
    $texto = strtr($texto, ['Á' => 'A', 'É' => 'E', 'Í' => 'I', 'Ó' => 'O', 'Ú' => 'U', 'Ü' => 'U', 'Ñ' => 'N']);
    return preg_replace('/\s+/', ' ', $texto);
}

function columna_indice(string $referencia): int
{
    $letras = preg_match('/^[A-Z]+/', $referencia, $coincidencia) ? $coincidencia[0] : 'A';
    $indice = 0;
    foreach (str_split($letras) as $letra) {
        $indice = $indice * 26 + (ord($letra) - 64);
    }
    return $indice - 1;
}

function leer_xlsx(string $ruta): array
{
    $zip = new ZipArchive();
    if ($zip->open($ruta) !== true) {
        throw new RuntimeException('El archivo XLSX no se puede abrir');
    }
    $compartidas = [];
    $xmlCompartidas = $zip->getFromName('xl/sharedStrings.xml');
    if ($xmlCompartidas !== false) {
        foreach (simplexml_load_string($xmlCompartidas)->si as $si) {
            $texto = '';
            if (isset($si->t)) {
                $texto = (string)$si->t;
            } else {
                foreach ($si->r as $fragmento) {
                    $texto .= (string)$fragmento->t;
                }
            }
            $compartidas[] = $texto;
        }
    }
    $libro = simplexml_load_string((string)$zip->getFromName('xl/workbook.xml'));
    $relaciones = simplexml_load_string((string)$zip->getFromName('xl/_rels/workbook.xml.rels'));
    if ($libro === false || $relaciones === false) {
        throw new RuntimeException('La estructura del archivo XLSX no es válida');
    }
    $destinos = [];
    foreach ($relaciones->Relationship as $relacion) {
        $destinos[(string)$relacion['Id']] = ltrim((string)$relacion['Target'], '/');
    }
    $espacioRelaciones = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
    $hojas = [];
    foreach ($libro->sheets->sheet as $hoja) {
        $rid = (string)$hoja->attributes($espacioRelaciones)['id'];
        $ruta_hoja = $destinos[$rid] ?? '';
        if (!str_starts_with($ruta_hoja, 'xl/')) {
            $ruta_hoja = 'xl/' . $ruta_hoja;
        }
        $xml = simplexml_load_string((string)$zip->getFromName($ruta_hoja));
        $filas = [];
        if ($xml !== false) {
            foreach ($xml->sheetData->row as $fila) {
                $valores = [];
                foreach ($fila->c as $celda) {
                    $tipo = (string)$celda['t'];
                    $valor = isset($celda->v) ? (string)$celda->v : null;
                    if ($tipo === 's' && $valor !== null) {
                        $valor = $compartidas[(int)$valor] ?? '';
                    } elseif ($tipo === 'inlineStr') {
                        $valor = (string)$celda->is->t;
                    }
                    $valores[columna_indice((string)$celda['r'])] = $valor;
                }
                if ($valores) {
                    $densa = [];
                    for ($i = 0; $i <= max(array_keys($valores)); $i++) {
                        $densa[] = $valores[$i] ?? null;
                    }
                    $filas[] = $densa;
                }
            }
        }
        $hojas[] = $filas;
    }
    $zip->close();
    return $hojas;
}

function hoja_con_encabezado(array $hojas, string $marcador): ?array
{
    foreach ($hojas as $filas) {
        if ($filas && in_array($marcador, array_map(fn($v) => normalizar_encabezado((string)$v), $filas[0]), true)) {
            return $filas;
        }
    }
    return null;
}

function mapear_columnas(array $encabezado, array $requeridas): array
{
    $normalizado = array_map(fn($v) => normalizar_encabezado((string)$v), $encabezado);
    $mapa = [];
    $faltantes = [];
    foreach ($requeridas as $clave => $nombre) {
        $posicion = array_search($nombre, $normalizado, true);
        if ($posicion === false) {
            $faltantes[] = $nombre;
        } else {
            $mapa[$clave] = $posicion;
        }
    }
    if ($faltantes) {
        throw new RuntimeException('Formato de archivo no válido. Faltan las columnas: ' . implode(', ', $faltantes));
    }
    return $mapa;
}

function fecha_flexible(mixed $valor): string|false|null
{
    $texto = trim((string)($valor ?? ''));
    if ($texto === '') {
        return null;
    }
    if (preg_match('/^\d{8}$/', $texto)) {
        $fecha = DateTimeImmutable::createFromFormat('!Ymd', $texto);
    } elseif (is_numeric($texto) && (float)$texto > 1000 && (float)$texto < 100000) {
        $fecha = (new DateTimeImmutable('1899-12-30'))->modify('+' . (int)floor((float)$texto) . ' days');
    } elseif (str_contains($texto, '/')) {
        $fecha = DateTimeImmutable::createFromFormat('!d/m/Y', $texto);
    } else {
        $fecha = DateTimeImmutable::createFromFormat('!Y-m-d', $texto);
    }
    return $fecha ? $fecha->format('Y-m-d') : false;
}

function nuevo_resultado(): array
{
    return ['total' => 0, 'insertados' => 0, 'duplicados' => 0, 'errores' => 0, 'detalles' => []];
}

function registrar_problema(array &$resultado, string $referencia, string $tipo, string $motivo, ?string $contenido = null): void
{
    $resultado['detalles'][] = [
        'referencia' => mb_substr($referencia, 0, 100),
        'tipo' => $tipo,
        'motivo' => mb_substr($motivo, 0, 300),
        'contenido' => $contenido !== null ? mb_substr($contenido, 0, 2000) : null,
    ];
    if ($tipo === 'DUPLICADO') {
        $resultado['duplicados']++;
    } else {
        $resultado['errores']++;
    }
}

function importar_empleados(array $filas, array &$resultado): void
{
    $mapa = mapear_columnas($filas[0], COLUMNAS_EMPLEADOS);
    $pdo = conexion();
    $existe = $pdo->prepare('SELECT 1 FROM empleado WHERE id_empleado = ?');
    $insertar = $pdo->prepare(
        'INSERT INTO empleado (id_empleado, nombre_completo, id_dependencia, id_cargo, fecha_ingreso, id_eps, id_arl, id_pension, salario, activo)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)'
    );
    $vistos = [];
    foreach (array_slice($filas, 1) as $n => $fila) {
        $resultado['total']++;
        $ref = 'Empleados fila ' . ($n + 2);
        $dato = fn(string $clave) => $fila[$mapa[$clave]] ?? null;
        $codigo = entero($dato('codigo'));
        $contenido = implode(' | ', array_map(fn($v) => (string)$v, $fila));
        if ($codigo === null || $codigo <= 0) {
            registrar_problema($resultado, $ref, 'VALIDACION', 'Código de empleado no válido', $contenido);
            continue;
        }
        $nombre = texto($dato('nombre'), 150);
        $dependencia = texto($dato('dependencia'), 100);
        $cargo = texto($dato('cargo'), 120);
        $eps = texto($dato('eps'), 100);
        $arl = texto($dato('arl'), 100);
        $pension = texto($dato('pension'), 100);
        $sueldo = decimal($dato('sueldo'));
        $ingreso = fecha_flexible($dato('ingreso'));
        if ($nombre === '' || $dependencia === '' || $cargo === '' || $eps === '' || $arl === '' || $pension === '') {
            registrar_problema($resultado, $ref, 'VALIDACION', 'Hay campos obligatorios vacíos', $contenido);
            continue;
        }
        if ($sueldo === null || $sueldo <= 0) {
            registrar_problema($resultado, $ref, 'VALIDACION', 'El sueldo debe ser un valor mayor a cero', $contenido);
            continue;
        }
        if ($ingreso === null || $ingreso === false) {
            registrar_problema($resultado, $ref, 'VALIDACION', 'La fecha de ingreso no es válida', $contenido);
            continue;
        }
        $repetido = isset($vistos[$codigo]);
        if (!$repetido) {
            $existe->execute([$codigo]);
            $repetido = (bool)$existe->fetchColumn();
        }
        if ($repetido) {
            registrar_problema($resultado, $ref, 'DUPLICADO', "El código $codigo ya existe", $contenido);
            continue;
        }
        $vistos[$codigo] = true;
        try {
            $insertar->execute([
                $codigo, $nombre,
                catalogo_id('dependencia', 'nombre', 'id_dependencia', $dependencia),
                catalogo_id('cargo', 'nombre', 'id_cargo', $cargo),
                $ingreso,
                catalogo_id('eps', 'nombre', 'id_eps', $eps),
                catalogo_id('arl', 'nombre', 'id_arl', $arl),
                catalogo_id('fondo_pension', 'nombre', 'id_pension', $pension),
                $sueldo,
            ]);
            $resultado['insertados']++;
        } catch (PDOException $e) {
            registrar_problema($resultado, $ref, 'VALIDACION', 'Error en base de datos: ' . $e->getMessage(), $contenido);
        }
    }
}

function importar_novedades(array $filas, string $periodo, array &$resultado): void
{
    $mapa = mapear_columnas($filas[0], COLUMNAS_NOVEDADES);
    $pdo = conexion();
    $empleado = $pdo->prepare('SELECT 1 FROM empleado WHERE id_empleado = ?');
    $duplicado = $pdo->prepare('SELECT 1 FROM novedad_mensual WHERE id_empleado = ? AND periodo = ?');
    $insertar = $pdo->prepare(
        'INSERT INTO novedad_mensual (id_empleado, periodo, dias_trabajados, dias_incapacidad, dias_vacaciones,
            fecha_inicio_incapacidad, fecha_fin_incapacidad, fecha_inicio_vacaciones, fecha_fin_vacaciones,
            bonificacion, auxilio_transporte)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $vistos = [];
    foreach (array_slice($filas, 1) as $n => $fila) {
        $resultado['total']++;
        $ref = 'Novedades fila ' . ($n + 2);
        $dato = fn(string $clave) => $fila[$mapa[$clave]] ?? null;
        $contenido = implode(' | ', array_map(fn($v) => (string)$v, $fila));
        $codigo = entero($dato('codigo'));
        if ($codigo === null) {
            registrar_problema($resultado, $ref, 'VALIDACION', 'Código de empleado no válido', $contenido);
            continue;
        }
        $trabajados = entero($dato('dias_trabajados')) ?? 0;
        $incapacidad = entero($dato('dias_incapacidad')) ?? 0;
        $vacaciones = entero($dato('dias_vacaciones')) ?? 0;
        $fechas = [
            fecha_flexible($dato('ini_inc')), fecha_flexible($dato('fin_inc')),
            fecha_flexible($dato('ini_vac')), fecha_flexible($dato('fin_vac')),
        ];
        if ($trabajados < 0 || $incapacidad < 0 || $vacaciones < 0 || $trabajados + $incapacidad + $vacaciones > 31) {
            registrar_problema($resultado, $ref, 'VALIDACION', 'Los días reportados no son válidos', $contenido);
            continue;
        }
        if (in_array(false, $fechas, true)) {
            registrar_problema($resultado, $ref, 'VALIDACION', 'Una fecha de novedad no es válida', $contenido);
            continue;
        }
        $empleado->execute([$codigo]);
        if (!$empleado->fetchColumn()) {
            registrar_problema($resultado, $ref, 'VALIDACION', "El empleado $codigo no está registrado", $contenido);
            continue;
        }
        $repetido = isset($vistos[$codigo]);
        if (!$repetido) {
            $duplicado->execute([$codigo, $periodo]);
            $repetido = (bool)$duplicado->fetchColumn();
        }
        if ($repetido) {
            registrar_problema($resultado, $ref, 'DUPLICADO', "Ya existe novedad del empleado $codigo en el periodo", $contenido);
            continue;
        }
        $vistos[$codigo] = true;
        try {
            $insertar->execute([
                $codigo, $periodo, $trabajados, $incapacidad, $vacaciones,
                $fechas[0], $fechas[1], $fechas[2], $fechas[3],
                decimal($dato('bonificacion')) ?? 0, decimal($dato('transporte')) ?? 0,
            ]);
            $resultado['insertados']++;
        } catch (PDOException $e) {
            registrar_problema($resultado, $ref, 'VALIDACION', 'Error en base de datos: ' . $e->getMessage(), $contenido);
        }
    }
}

function importar_dat(string $ruta, array &$resultado): void
{
    $contenido = file_get_contents($ruta);
    if (!mb_check_encoding($contenido, 'UTF-8')) {
        $contenido = mb_convert_encoding($contenido, 'UTF-8', 'Windows-1252');
    }
    $pdo = conexion();
    $existe = $pdo->prepare('SELECT 1 FROM pelicula WHERE id_pelicula = ?');
    $insertar = $pdo->prepare('INSERT INTO pelicula (id_pelicula, titulo, anio) VALUES (?, ?, ?)');
    $relacionar = $pdo->prepare('INSERT IGNORE INTO pelicula_genero (id_pelicula, id_genero) VALUES (?, ?)');
    foreach (preg_split('/\r?\n/', $contenido) as $n => $linea) {
        if (trim($linea) === '') {
            continue;
        }
        $resultado['total']++;
        $ref = 'Películas línea ' . ($n + 1);
        $partes = explode('::', $linea);
        if (count($partes) !== 3 || !ctype_digit($partes[0])) {
            registrar_problema($resultado, $ref, 'VALIDACION', 'Formato incorrecto (se esperaba ID::Título::Géneros)', $linea);
            continue;
        }
        $id = (int)$partes[0];
        $titulo = trim($partes[1]);
        $latin = @iconv('UTF-8', 'ISO-8859-1', $titulo);
        if ($latin !== false && preg_match('/[ÃÂ]/u', $titulo) && mb_check_encoding($latin, 'UTF-8')) {
            $titulo = $latin;
        }
        $anio = null;
        if (preg_match('/\s\((\d{4})\)\s*$/', $titulo, $coincidencia)) {
            $anio = (int)$coincidencia[1];
            $titulo = trim(substr($titulo, 0, -strlen($coincidencia[0])));
        }
        if ($titulo === '') {
            registrar_problema($resultado, $ref, 'VALIDACION', 'El título está vacío', $linea);
            continue;
        }
        $existe->execute([$id]);
        if ($existe->fetchColumn()) {
            registrar_problema($resultado, $ref, 'DUPLICADO', "La película con ID $id ya existe", $linea);
            continue;
        }
        try {
            $insertar->execute([$id, mb_substr($titulo, 0, 300), $anio]);
            foreach (explode('|', trim($partes[2])) as $genero) {
                $genero = trim($genero);
                if ($genero !== '' && $genero !== '(no genres listed)') {
                    $relacionar->execute([$id, catalogo_id('genero', 'nombre', 'id_genero', mb_substr($genero, 0, 60))]);
                }
            }
            $resultado['insertados']++;
        } catch (PDOException $e) {
            registrar_problema($resultado, $ref, 'VALIDACION', 'Error en base de datos: ' . $e->getMessage(), $linea);
        }
    }
}

function validar_libro(array $b): array
{
    $errores = [];
    $titulo = texto($b['title'] ?? '', 300);
    $calificacion = trim((string)($b['average_rating'] ?? ''));
    $paginas = trim((string)($b['num_pages'] ?? ''));
    $idioma = trim((string)($b['language_code'] ?? ''));
    $isbn13 = trim((string)($b['isbn13'] ?? ''));
    $fecha = DateTimeImmutable::createFromFormat('!n/j/Y', trim((string)($b['publication_date'] ?? '')));
    $calificacionValida = preg_match('/^\d(\.\d{1,2})?$/', $calificacion) && (float)$calificacion <= 5;
    $contadoresValidos = is_int($b['ratings_count'] ?? null) && is_int($b['text_reviews_count'] ?? null)
        && $b['ratings_count'] >= 0 && $b['text_reviews_count'] >= 0;
    if ($titulo === '') {
        $errores[] = 'Título vacío';
    }
    if (!$calificacionValida) {
        $errores[] = 'Calificación no válida';
    }
    if (!ctype_digit($paginas)) {
        $errores[] = 'Número de páginas no válido';
    }
    if (!preg_match('/^[a-z]{2,3}(-[A-Za-z]{2})?$/', $idioma)) {
        $errores[] = 'Idioma no válido';
    }
    if (!preg_match('/^\d{13}$/', $isbn13)) {
        $errores[] = 'ISBN-13 no válido';
    }
    if (!$fecha) {
        $errores[] = 'Fecha de publicación no válida';
    }
    if (!$contadoresValidos) {
        $errores[] = 'Contadores de calificaciones no válidos';
    }
    if (!isset($b['bookID']) || !is_int($b['bookID'])) {
        $errores[] = 'ID de libro no válido';
    }
    return [$errores, [
        'id' => (int)($b['bookID'] ?? 0),
        'titulo' => $titulo,
        'isbn' => texto($b['isbn'] ?? '', 20) ?: null,
        'isbn13' => $isbn13,
        'idioma' => $idioma,
        'paginas' => ctype_digit($paginas) ? (int)$paginas : null,
        'calificacion' => round((float)$calificacion, 2),
        'calificaciones' => (int)($b['ratings_count'] ?? 0),
        'resenas' => (int)($b['text_reviews_count'] ?? 0),
        'fecha' => $fecha ? $fecha->format('Y-m-d') : null,
        'editorial' => texto($b['publisher'] ?? '', 150) ?: null,
        'autores' => (string)($b['authors'] ?? ''),
    ]];
}

function importar_libros(string $ruta, array &$resultado): void
{
    $datos = json_decode((string)file_get_contents($ruta), true);
    if (!is_array($datos) || ($datos && !array_is_list($datos))) {
        throw new RuntimeException('El JSON debe contener una lista de libros');
    }
    $pdo = conexion();
    $existe = $pdo->prepare('SELECT 1 FROM libro WHERE id_libro = ? OR isbn13 = ?');
    $insertar = $pdo->prepare(
        'INSERT INTO libro (id_libro, titulo, isbn, isbn13, codigo_idioma, num_paginas, calificacion_promedio,
            cantidad_calificaciones, cantidad_resenas, fecha_publicacion, id_editorial)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $relacionar = $pdo->prepare('INSERT IGNORE INTO libro_autor (id_libro, id_autor, orden) VALUES (?, ?, ?)');
    foreach ($datos as $n => $libro) {
        $resultado['total']++;
        $ref = 'Libros registro ' . ($n + 1);
        $contenido = json_encode($libro, JSON_UNESCAPED_UNICODE);
        if (!is_array($libro)) {
            registrar_problema($resultado, $ref, 'VALIDACION', 'El registro no es un objeto válido', (string)$contenido);
            continue;
        }
        [$errores, $v] = validar_libro($libro);
        if ($errores) {
            registrar_problema($resultado, $ref, 'VALIDACION', implode('; ', $errores), $contenido);
            continue;
        }
        $existe->execute([$v['id'], $v['isbn13']]);
        if ($existe->fetchColumn()) {
            registrar_problema($resultado, $ref, 'DUPLICADO', 'El libro ya existe (ID o ISBN-13 repetido)', $contenido);
            continue;
        }
        try {
            $editorial = $v['editorial'] !== null ? catalogo_id('editorial', 'nombre', 'id_editorial', $v['editorial']) : null;
            $insertar->execute([
                $v['id'], $v['titulo'], $v['isbn'], $v['isbn13'], $v['idioma'], $v['paginas'], $v['calificacion'],
                $v['calificaciones'], $v['resenas'], $v['fecha'], $editorial,
            ]);
            $orden = 0;
            foreach (array_filter(array_map('trim', explode('/', $v['autores']))) as $autor) {
                $orden++;
                $relacionar->execute([$v['id'], catalogo_id('autor', 'nombre', 'id_autor', mb_substr($autor, 0, 200)), $orden]);
            }
            $resultado['insertados']++;
        } catch (PDOException $e) {
            registrar_problema($resultado, $ref, 'VALIDACION', 'Error en base de datos: ' . $e->getMessage(), $contenido);
        }
    }
}

function procesar_importacion(string $tipo, string $ruta, string $nombreOriginal, ?string $periodo, ?int $idUsuario): array
{
    $resultado = nuevo_resultado();
    $pdo = conexion();
    $pdo->beginTransaction();
    try {
        if ($tipo === 'XLSX') {
            $hojas = leer_xlsx($ruta);
            $empleados = hoja_con_encabezado($hojas, 'NOMBRE DEL EMPLEADO');
            $novedades = hoja_con_encabezado($hojas, 'NOVEDAD INCAPACIDAD');
            if ($empleados === null && $novedades === null) {
                throw new RuntimeException('El XLSX no contiene una hoja de empleados ni una hoja de novedades');
            }
            if ($empleados !== null) {
                importar_empleados($empleados, $resultado);
            }
            if ($novedades !== null) {
                if ($periodo === null) {
                    throw new RuntimeException('Debe indicar el periodo MM/AAAA para importar novedades');
                }
                importar_novedades($novedades, $periodo, $resultado);
            }
        } elseif ($tipo === 'DAT') {
            importar_dat($ruta, $resultado);
        } elseif ($tipo === 'JSON') {
            importar_libros($ruta, $resultado);
        } else {
            throw new RuntimeException('Tipo de importación no válido');
        }
        $pdo->prepare(
            'INSERT INTO importacion (tipo_archivo, nombre_archivo, id_usuario, total_registros, registros_insertados, registros_duplicados, registros_error)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        )->execute([$tipo, mb_substr($nombreOriginal, 0, 255), $idUsuario, $resultado['total'], $resultado['insertados'], $resultado['duplicados'], $resultado['errores']]);
        $idImportacion = (int)$pdo->lastInsertId();
        $detalle = $pdo->prepare(
            'INSERT INTO importacion_detalle (id_importacion, referencia, tipo_error, motivo, contenido) VALUES (?, ?, ?, ?, ?)'
        );
        foreach ($resultado['detalles'] as $d) {
            $detalle->execute([$idImportacion, $d['referencia'], $d['tipo'], $d['motivo'], $d['contenido']]);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
    $resultado['id_importacion'] = $idImportacion;
    $resultado['detalles'] = array_slice($resultado['detalles'], 0, 50);
    return $resultado;
}
