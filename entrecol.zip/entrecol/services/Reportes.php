<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Respuesta.php';

function reporte_base(string $titulo, array $columnas, array $grupos, int $total, ?array $grafico = null): array
{
    return ['titulo' => $titulo, 'columnas' => $columnas, 'grupos' => $grupos, 'total' => $total, 'grafico' => $grafico];
}

function grupo(?string $encabezado, array $filas): array
{
    return ['encabezado' => $encabezado, 'total' => count($filas), 'filas' => $filas];
}

function serie(string $nombre, array $datos): array
{
    return ['nombre' => $nombre, 'datos' => array_values($datos)];
}

function grafico(string $tipo, array $etiquetas, array $series): array
{
    return ['tipo' => $tipo, 'etiquetas' => array_values($etiquetas), 'series' => $series];
}

function formato_pesos(mixed $valor): string
{
    return '$' . number_format((float)$valor, 0, ',', '.');
}

function formato_fecha(?string $fecha): string
{
    return $fecha ? date('d/m/Y', strtotime($fecha)) : '';
}

function rango_periodos(array $p): array
{
    $desde = periodo_mes($p['desde'] ?? '');
    $hasta = periodo_mes($p['hasta'] ?? '');
    if ($desde === null || $hasta === null) {
        throw new InvalidArgumentException('Los periodos deben tener el formato MM/AAAA');
    }
    if ($desde > $hasta) {
        throw new InvalidArgumentException('El periodo inicial no puede ser mayor al periodo final');
    }
    return [$desde, $hasta];
}

function rango_anios(array $p): array
{
    $desde = entero($p['desde'] ?? null) ?? 0;
    $hasta = entero($p['hasta'] ?? null) ?? 9999;
    if ($desde > $hasta) {
        throw new InvalidArgumentException('El año inicial no puede ser mayor al año final');
    }
    return [$desde, $hasta];
}

function entero_en_rango(mixed $valor, int $minimo, int $maximo, string $nombre): int
{
    $numero = entero($valor);
    if ($numero === null || $numero < $minimo || $numero > $maximo) {
        throw new InvalidArgumentException("$nombre debe estar entre $minimo y $maximo");
    }
    return $numero;
}

function construir_reporte(string $tipo, array $p): array
{
    $orden = orden_sql($p['orden'] ?? 'asc');
    return match ($tipo) {
        'empleados' => reporte_empleados($orden),
        'por_dependencia' => reporte_por_dependencia($orden),
        'cargo_dependencia' => reporte_cargo_dependencia($orden),
        'info_personal' => reporte_info_personal(entero($p['codigo'] ?? null)),
        'frecuencia_eps' => reporte_frecuencia('eps', 'EPS'),
        'frecuencia_pension' => reporte_frecuencia('pension', 'Fondo de pensión'),
        'eps_dependencia' => reporte_comparacion_dependencia('eps', 'EPS'),
        'pension_dependencia' => reporte_comparacion_dependencia('pension', 'Fondo de pensión'),
        'cargo_eps' => reporte_cargo_entidad('eps', 'EPS', $orden),
        'cargo_pension' => reporte_cargo_entidad('pension', 'Fondo de pensión', $orden),
        'novedades_rango' => reporte_novedades_rango($p, $orden),
        'novedades_cantidad' => reporte_novedades_cantidad($p),
        'peliculas_genero' => reporte_peliculas_genero($p, $orden),
        'top_libros' => reporte_top_libros(entero_en_rango($p['n'] ?? 10, 1, 500, 'N')),
        'top_anio' => reporte_top_anio(
            ($p['modo'] ?? 'mejores') === 'peores' ? 'peores' : 'mejores',
            entero_en_rango($p['n'] ?? 5, 1, 20, 'N')
        ),
        'peliculas_n_generos' => reporte_peliculas_n_generos(entero_en_rango($p['n'] ?? 2, 1, 20, 'N'), $orden),
        'frecuencia_generos' => reporte_frecuencia_generos(),
        'libros_anio' => reporte_libros_anio($p),
        'salario_promedio_cargo' => reporte_salario_promedio_cargo(),
        'peliculas_por_anio' => reporte_peliculas_por_anio(),
        default => throw new InvalidArgumentException('El reporte solicitado no existe'),
    };
}

function reporte_salario_promedio_cargo(): array
{
    $filas = conexion()->query(
        'SELECT cargo, ROUND(AVG(salario), 0) AS promedio, COUNT(*) AS empleados
         FROM vw_empleado_detalle GROUP BY cargo ORDER BY promedio DESC, cargo ASC'
    )->fetchAll(PDO::FETCH_NUM);
    $valores = array_map(fn($f) => (float)$f[1], $filas);
    $tabla = array_map(fn($f) => [$f[0], formato_pesos($f[1]), (int)$f[2]], $filas);
    return reporte_base(
        'Salario promedio por cargo',
        ['Cargo', 'Salario promedio', 'Empleados'],
        [grupo(null, $tabla)],
        count($tabla),
        grafico('bar', array_column($filas, 0), [serie('Salario promedio', $valores)])
    );
}

function reporte_peliculas_por_anio(): array
{
    $filas = conexion()->query(
        'SELECT anio, COUNT(*) AS total FROM pelicula WHERE anio IS NOT NULL GROUP BY anio ORDER BY anio ASC'
    )->fetchAll(PDO::FETCH_NUM);
    return reporte_base(
        'Películas por año',
        ['Año', 'Películas'],
        [grupo(null, $filas)],
        array_sum(array_column($filas, 1)),
        grafico('bar', array_column($filas, 0), [serie('Películas', array_column($filas, 1))])
    );
}

function reporte_empleados(string $orden): array
{
    $filas = conexion()->query(
        "SELECT codigo, nombre_completo, dependencia, cargo FROM vw_empleado_detalle ORDER BY nombre_completo $orden"
    )->fetchAll(PDO::FETCH_NUM);
    return reporte_base('Listado de empleados', ['Código', 'Nombre', 'Dependencia', 'Cargo'], [grupo(null, $filas)], count($filas));
}

function reporte_por_dependencia(string $orden): array
{
    $filas = conexion()->query(
        "SELECT dependencia, codigo, nombre_completo, cargo FROM vw_empleado_detalle ORDER BY dependencia ASC, nombre_completo $orden"
    )->fetchAll(PDO::FETCH_NUM);
    $porDependencia = [];
    foreach ($filas as $f) {
        $porDependencia[$f[0]][] = [$f[1], $f[2], $f[3]];
    }
    $grupos = [];
    $etiquetas = [];
    $datos = [];
    foreach ($porDependencia as $dependencia => $lista) {
        $grupos[] = grupo("Dependencia: $dependencia", $lista);
        $etiquetas[] = $dependencia;
        $datos[] = count($lista);
    }
    return reporte_base(
        'Empleados por dependencia',
        ['Código', 'Nombre', 'Cargo'],
        $grupos,
        count($filas),
        grafico('pie', $etiquetas, [serie('Empleados', $datos)])
    );
}

function reporte_cargo_dependencia(string $orden): array
{
    $filas = conexion()->query(
        "SELECT dependencia, cargo, codigo, nombre_completo FROM vw_empleado_detalle ORDER BY dependencia ASC, cargo ASC, nombre_completo $orden"
    )->fetchAll(PDO::FETCH_NUM);
    $cargos = conexion()->query('SELECT nombre FROM cargo ORDER BY nombre ASC')->fetchAll(PDO::FETCH_COLUMN);
    $jerarquia = [];
    $conteo = [];
    foreach ($filas as $f) {
        $jerarquia[$f[0]][$f[1]][] = [$f[2], $f[3]];
        $conteo[$f[0]][$f[1]] = ($conteo[$f[0]][$f[1]] ?? 0) + 1;
    }
    $grupos = [];
    $series = [];
    foreach ($jerarquia as $dependencia => $porCargo) {
        foreach ($porCargo as $cargo => $lista) {
            $grupos[] = grupo("Dependencia: $dependencia · Cargo: $cargo", $lista);
        }
        $series[] = serie($dependencia, array_map(fn($c) => $conteo[$dependencia][$c] ?? 0, $cargos));
    }
    return reporte_base(
        'Empleados por cargo y dependencia',
        ['Código', 'Nombre'],
        $grupos,
        count($filas),
        grafico('bar', $cargos, $series)
    );
}

function reporte_info_personal(?int $codigo): array
{
    $pdo = conexion();
    if ($codigo !== null) {
        $consulta = $pdo->prepare('SELECT * FROM vw_empleado_detalle WHERE codigo = ? ORDER BY nombre_completo');
        $consulta->execute([$codigo]);
    } else {
        $consulta = $pdo->query('SELECT * FROM vw_empleado_detalle ORDER BY nombre_completo');
    }
    $empleados = $consulta->fetchAll();
    if ($codigo !== null && !$empleados) {
        throw new InvalidArgumentException('El empleado indicado no existe');
    }
    $sqlNovedades = 'SELECT codigo, periodo, dias_incapacidad, dias_vacaciones, bonificacion FROM vw_novedades'
        . ($codigo !== null ? ' WHERE codigo = ?' : '') . ' ORDER BY periodo';
    $novedadesStmt = $pdo->prepare($sqlNovedades);
    $novedadesStmt->execute($codigo !== null ? [$codigo] : []);
    $novedades = [];
    foreach ($novedadesStmt->fetchAll() as $n) {
        $novedades[$n['codigo']][] = date('m/Y', strtotime($n['periodo']))
            . ': incapacidad ' . $n['dias_incapacidad'] . ' d, vacaciones ' . $n['dias_vacaciones']
            . ' d, bonificación ' . formato_pesos($n['bonificacion']);
    }
    $filas = [];
    foreach ($empleados as $e) {
        $filas[] = [
            $e['codigo'],
            $e['nombre_completo'],
            $e['dependencia'],
            $e['cargo'],
            formato_fecha($e['fecha_ingreso']),
            $e['eps'],
            $e['pension'],
            formato_pesos($e['salario']),
            isset($novedades[$e['codigo']]) ? implode('; ', $novedades[$e['codigo']]) : 'Sin novedades',
        ];
    }
    return reporte_base(
        'Información personal y laboral',
        ['Código', 'Nombre', 'Dependencia', 'Cargo', 'Fecha ingreso', 'EPS', 'Pensión', 'Salario', 'Novedades'],
        [grupo(null, $filas)],
        count($filas)
    );
}

function reporte_frecuencia(string $campo, string $titulo): array
{
    $filas = conexion()->query(
        "SELECT $campo AS nombre, COUNT(*) AS total FROM vw_empleado_detalle GROUP BY $campo ORDER BY total DESC, $campo ASC"
    )->fetchAll(PDO::FETCH_NUM);
    $total = array_sum(array_column($filas, 1));
    return reporte_base(
        "Frecuencia por $titulo",
        [$titulo, 'Empleados'],
        [grupo(null, $filas)],
        $total,
        grafico('pie', array_column($filas, 0), [serie('Empleados', array_column($filas, 1))])
    );
}

function reporte_comparacion_dependencia(string $campo, string $titulo): array
{
    $pdo = conexion();
    $entidades = $pdo->query("SELECT DISTINCT $campo FROM vw_empleado_detalle ORDER BY $campo ASC")->fetchAll(PDO::FETCH_COLUMN);
    $conteo = [];
    foreach ($pdo->query("SELECT dependencia, $campo AS entidad, COUNT(*) AS total FROM vw_empleado_detalle GROUP BY dependencia, $campo")->fetchAll(PDO::FETCH_NUM) as $f) {
        $conteo[$f[0]][$f[1]] = (int)$f[2];
    }
    $dependencias = array_keys($conteo);
    sort($dependencias, SORT_STRING);
    $filas = [];
    $series = [];
    foreach ($entidades as $entidad) {
        $series[$entidad] = [];
    }
    foreach ($dependencias as $dependencia) {
        $fila = [$dependencia];
        foreach ($entidades as $entidad) {
            $valor = $conteo[$dependencia][$entidad] ?? 0;
            $fila[] = $valor;
            $series[$entidad][] = $valor;
        }
        $filas[] = $fila;
    }
    $total = array_sum(array_map(fn($fila) => array_sum(array_slice($fila, 1)), $filas));
    $grafico = grafico('bar', $dependencias, array_map(fn($e) => serie($e, $series[$e]), $entidades));
    return reporte_base(
        "Comparación de $titulo por dependencia",
        array_merge(['Dependencia'], $entidades),
        [grupo(null, $filas)],
        $total,
        $grafico
    );
}

function reporte_cargo_entidad(string $campo, string $titulo, string $orden): array
{
    $filas = conexion()->query(
        "SELECT cargo, $campo AS entidad, codigo, nombre_completo, dependencia FROM vw_empleado_detalle ORDER BY cargo ASC, $campo ASC, nombre_completo $orden"
    )->fetchAll(PDO::FETCH_NUM);
    $grupos = [];
    $agrupado = [];
    foreach ($filas as $f) {
        $agrupado[$f[0]][$f[1]][] = [$f[2], $f[3], $f[4]];
    }
    foreach ($agrupado as $cargo => $porEntidad) {
        foreach ($porEntidad as $entidad => $lista) {
            $grupos[] = grupo("Cargo: $cargo · $titulo: $entidad", $lista);
        }
    }
    return reporte_base(
        "Empleados por cargo y $titulo",
        ['Código', 'Nombre', 'Dependencia'],
        $grupos,
        count($filas)
    );
}

function reporte_novedades_rango(array $p, string $orden): array
{
    [$desde, $hasta] = rango_periodos($p);
    $consulta = conexion()->prepare(
        'SELECT codigo, nombre_completo, dependencia, cargo, SUM(dias_incapacidad) AS incapacidad,
                SUM(dias_vacaciones) AS vacaciones, COUNT(*) AS meses
         FROM vw_novedades
         WHERE periodo BETWEEN ? AND ? AND (dias_incapacidad > 0 OR dias_vacaciones > 0)
         GROUP BY codigo, nombre_completo, dependencia, cargo
         ORDER BY nombre_completo ' . $orden
    );
    $consulta->execute([$desde, $hasta]);
    $filas = $consulta->fetchAll(PDO::FETCH_NUM);
    return reporte_base(
        'Empleados con novedades entre ' . date('m/Y', strtotime($desde)) . ' y ' . date('m/Y', strtotime($hasta)),
        ['Código', 'Nombre', 'Dependencia', 'Cargo', 'Días incapacidad', 'Días vacaciones', 'Meses con novedad'],
        [grupo(null, $filas)],
        count($filas)
    );
}

function reporte_novedades_cantidad(array $p): array
{
    [$desde, $hasta] = rango_periodos($p);
    $consulta = conexion()->prepare(
        'SELECT dependencia, cargo, COUNT(DISTINCT codigo) AS empleados, SUM(dias_incapacidad) AS incapacidad,
                SUM(dias_vacaciones) AS vacaciones
         FROM vw_novedades
         WHERE periodo BETWEEN ? AND ? AND (dias_incapacidad > 0 OR dias_vacaciones > 0)
         GROUP BY dependencia, cargo
         ORDER BY dependencia ASC, cargo ASC'
    );
    $consulta->execute([$desde, $hasta]);
    $filas = $consulta->fetchAll(PDO::FETCH_NUM);
    $porDependencia = [];
    foreach ($filas as $f) {
        $porDependencia[$f[0]] = ($porDependencia[$f[0]] ?? 0) + (int)$f[2];
    }
    return reporte_base(
        'Novedades por dependencia y cargo entre ' . date('m/Y', strtotime($desde)) . ' y ' . date('m/Y', strtotime($hasta)),
        ['Dependencia', 'Cargo', 'Empleados con novedades', 'Días incapacidad', 'Días vacaciones'],
        [grupo(null, $filas)],
        count($filas),
        grafico('bar', array_keys($porDependencia), [serie('Empleados con novedades', array_values($porDependencia))])
    );
}

function reporte_peliculas_genero(array $p, string $orden): array
{
    $genero = texto($p['genero'] ?? '', 60);
    if ($genero === '') {
        throw new InvalidArgumentException('Seleccione un género');
    }
    [$anioDesde, $anioHasta] = rango_anios($p);
    $consulta = conexion()->prepare(
        'SELECT p.titulo, p.anio, (
            SELECT GROUP_CONCAT(g2.nombre ORDER BY g2.nombre SEPARATOR \', \')
            FROM pelicula_genero pg2 JOIN genero g2 ON g2.id_genero = pg2.id_genero
            WHERE pg2.id_pelicula = p.id_pelicula) AS generos
         FROM pelicula p
         JOIN pelicula_genero pg ON pg.id_pelicula = p.id_pelicula
         JOIN genero g ON g.id_genero = pg.id_genero
         WHERE g.nombre = ? AND p.anio BETWEEN ? AND ?
         ORDER BY p.titulo ' . $orden
    );
    $consulta->execute([$genero, $anioDesde, $anioHasta]);
    $filas = $consulta->fetchAll(PDO::FETCH_NUM);
    return reporte_base(
        "Películas del género $genero entre $anioDesde y $anioHasta",
        ['Título', 'Año', 'Géneros'],
        [grupo(null, $filas)],
        count($filas)
    );
}

function reporte_top_libros(int $n): array
{
    $consulta = conexion()->prepare(
        'SELECT l.titulo, (
            SELECT GROUP_CONCAT(a.nombre ORDER BY la.orden SEPARATOR \' / \')
            FROM libro_autor la JOIN autor a ON a.id_autor = la.id_autor
            WHERE la.id_libro = l.id_libro) AS autores,
            l.calificacion_promedio, l.cantidad_calificaciones, l.anio_publicacion
         FROM libro l
         ORDER BY l.calificacion_promedio DESC, l.cantidad_calificaciones DESC, l.titulo ASC
         LIMIT ?'
    );
    $consulta->bindValue(1, $n, PDO::PARAM_INT);
    $consulta->execute();
    $filas = [];
    foreach ($consulta->fetchAll(PDO::FETCH_NUM) as $i => $f) {
        $filas[] = array_merge([$i + 1], $f);
    }
    return reporte_base(
        "Top $n libros con mejor rating",
        ['Posición', 'Título', 'Autores', 'Calificación', 'Calificaciones', 'Año'],
        [grupo(null, $filas)],
        count($filas)
    );
}

function reporte_top_anio(string $modo, int $n): array
{
    $direccion = $modo === 'peores' ? 'ASC' : 'DESC';
    $consulta = conexion()->prepare(
        "SELECT x.anio, x.posicion, x.titulo, x.autores, x.calificacion, x.calificaciones FROM (
            SELECT l.anio_publicacion AS anio, l.titulo, l.calificacion_promedio AS calificacion,
                l.cantidad_calificaciones AS calificaciones, (
                    SELECT GROUP_CONCAT(a.nombre ORDER BY la.orden SEPARATOR ' / ')
                    FROM libro_autor la JOIN autor a ON a.id_autor = la.id_autor
                    WHERE la.id_libro = l.id_libro) AS autores,
                ROW_NUMBER() OVER (
                    PARTITION BY l.anio_publicacion
                    ORDER BY l.calificacion_promedio $direccion, l.cantidad_calificaciones DESC, l.id_libro
                ) AS posicion
            FROM libro l
            WHERE l.anio_publicacion IS NOT NULL AND l.cantidad_calificaciones > 0
        ) x
        WHERE x.posicion <= ?
        ORDER BY x.anio ASC, x.posicion ASC"
    );
    $consulta->bindValue(1, $n, PDO::PARAM_INT);
    $consulta->execute();
    $grupos = [];
    foreach ($consulta->fetchAll(PDO::FETCH_NUM) as $f) {
        $grupos[$f[0]][] = [$f[1], $f[2], $f[3], $f[4], $f[5]];
    }
    $salida = [];
    $total = 0;
    foreach ($grupos as $anio => $lista) {
        $salida[] = grupo("Año $anio", $lista);
        $total += count($lista);
    }
    $nombre = $modo === 'peores' ? 'peor' : 'mejor';
    return reporte_base(
        "Top $n libros con $nombre rating por año",
        ['Posición', 'Título', 'Autores', 'Calificación', 'Calificaciones'],
        $salida,
        $total
    );
}

function reporte_peliculas_n_generos(int $n, string $orden): array
{
    $consulta = conexion()->prepare(
        "SELECT p.titulo, p.anio, COUNT(pg.id_genero) AS cantidad,
                GROUP_CONCAT(g.nombre ORDER BY g.nombre SEPARATOR ', ') AS generos
         FROM pelicula p
         JOIN pelicula_genero pg ON pg.id_pelicula = p.id_pelicula
         JOIN genero g ON g.id_genero = pg.id_genero
         GROUP BY p.id_pelicula, p.titulo, p.anio
         HAVING COUNT(pg.id_genero) = ?
         ORDER BY p.titulo $orden"
    );
    $consulta->bindValue(1, $n, PDO::PARAM_INT);
    $consulta->execute();
    $filas = $consulta->fetchAll(PDO::FETCH_NUM);
    return reporte_base(
        "Películas con $n género(s)",
        ['Título', 'Año', 'Cantidad de géneros', 'Géneros'],
        [grupo(null, $filas)],
        count($filas)
    );
}

function reporte_frecuencia_generos(): array
{
    $filas = conexion()->query(
        'SELECT g.nombre, COUNT(pg.id_pelicula) AS total
         FROM genero g LEFT JOIN pelicula_genero pg ON pg.id_genero = g.id_genero
         GROUP BY g.id_genero, g.nombre
         ORDER BY total DESC, g.nombre ASC'
    )->fetchAll(PDO::FETCH_NUM);
    return reporte_base(
        'Frecuencia de películas por género',
        ['Género', 'Películas'],
        [grupo(null, $filas)],
        array_sum(array_column($filas, 1)),
        grafico('bar', array_column($filas, 0), [serie('Películas', array_column($filas, 1))])
    );
}

function reporte_libros_anio(array $p): array
{
    [$desde, $hasta] = rango_anios($p);
    $consulta = conexion()->prepare(
        'SELECT anio_publicacion AS anio, COUNT(*) AS total FROM libro
         WHERE anio_publicacion BETWEEN ? AND ?
         GROUP BY anio_publicacion ORDER BY anio_publicacion ASC'
    );
    $consulta->execute([$desde, $hasta]);
    $filas = $consulta->fetchAll(PDO::FETCH_NUM);
    return reporte_base(
        "Libros por año de publicación entre $desde y $hasta",
        ['Año', 'Libros'],
        [grupo(null, $filas)],
        array_sum(array_column($filas, 1)),
        grafico('bar', array_column($filas, 0), [serie('Libros', array_column($filas, 1))])
    );
}
