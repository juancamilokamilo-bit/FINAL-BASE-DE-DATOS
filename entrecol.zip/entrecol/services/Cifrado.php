<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

function cifrar(string $texto): string
{
    $iv = random_bytes(12);
    $tag = '';
    $cifrado = openssl_encrypt($texto, 'aes-256-gcm', hex2bin(APP_CLAVE_CIFRADO), OPENSSL_RAW_DATA, $iv, $tag);
    return base64_encode($iv . $tag . $cifrado);
}

function descifrar(string $dato): string
{
    $binario = base64_decode($dato, true);
    if ($binario === false || strlen($binario) < 29) {
        throw new RuntimeException('Dato cifrado no válido');
    }
    $texto = openssl_decrypt(
        substr($binario, 28),
        'aes-256-gcm',
        hex2bin(APP_CLAVE_CIFRADO),
        OPENSSL_RAW_DATA,
        substr($binario, 0, 12),
        substr($binario, 12, 16)
    );
    if ($texto === false) {
        throw new RuntimeException('No se pudo descifrar el dato');
    }
    return $texto;
}
