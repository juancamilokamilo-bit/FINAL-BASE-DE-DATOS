<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Sesion.php';

metodo_permitido('GET');
$usuario = usuario_actual();
if ($usuario === null) {
    error_api('Debe iniciar sesión', 401);
}
ok_api(['usuario' => $usuario, 'csrf' => token_csrf()]);
