<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Sesion.php';
require_once __DIR__ . '/../../services/Totp.php';
require_once __DIR__ . '/../../services/Cifrado.php';
require_once __DIR__ . '/../../services/Recuperacion.php';
require_once __DIR__ . '/../../services/Auditoria.php';
require_once __DIR__ . '/../../services/Validacion.php';

$usuario = requerir_sesion();
$cuenta = cargar_usuario_completo((int)$usuario['id']);

ejecutar_api(function () use ($cuenta, $usuario) {
    $pdo = conexion();
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $accion = $_GET['accion'] ?? 'estado';
        if ($accion === 'estado') {
            ok_api(['activo' => (int)$cuenta['totp_activo'] === 1]);
        }
        if ($accion === 'iniciar') {
            if ((int)$cuenta['totp_activo'] === 1) {
                error_api('El doble factor ya está activo', 409);
            }
            iniciar_sesion_segura();
            $secreto = totp_generar_secreto();
            $_SESSION['totp_pendiente'] = $secreto;
            ok_api(['secreto' => $secreto, 'uri' => totp_uri($secreto, $usuario['usuario'], APP_NOMBRE)]);
        }
        error_api('Acción no válida', 400);
    }

    metodo_permitido('POST');
    $datos = entrada();
    $accion = $datos['accion'] ?? '';

    if ($accion === 'confirmar') {
        iniciar_sesion_segura();
        $secreto = $_SESSION['totp_pendiente'] ?? null;
        if ($secreto === null) {
            error_api('Primero genere el código QR', 400);
        }
        requerir_campos($datos, ['codigo']);
        if (!totp_verificar($secreto, (string)$datos['codigo'])) {
            error_api('El código no es válido. Verifique la hora de su celular.', 422);
        }
        $pdo->prepare('UPDATE usuario SET totp_secreto = ?, totp_activo = 1 WHERE id_usuario = ?')
            ->execute([cifrar($secreto), $usuario['id']]);
        unset($_SESSION['totp_pendiente']);
        $codigos = generar_codigos_recuperacion((int)$usuario['id']);
        auditar('ACTIVAR_2FA', 'auth', $usuario['usuario'], 'Doble factor activado');
        ok_api(['codigos' => $codigos], 'Doble factor activado. Guarde sus códigos de recuperación.');
    }

    if ($accion === 'desactivar') {
        requerir_campos($datos, ['clave']);
        if (!password_verify((string)$datos['clave'], $cuenta['password_hash'])) {
            error_api('La contraseña no es correcta', 401);
        }
        $pdo->prepare('UPDATE usuario SET totp_secreto = NULL, totp_activo = 0 WHERE id_usuario = ?')
            ->execute([$usuario['id']]);
        $pdo->prepare('DELETE FROM codigo_recuperacion WHERE id_usuario = ?')->execute([$usuario['id']]);
        auditar('DESACTIVAR_2FA', 'auth', $usuario['usuario'], 'Doble factor desactivado');
        ok_api([], 'Doble factor desactivado');
    }

    error_api('Acción no válida', 400);
});
