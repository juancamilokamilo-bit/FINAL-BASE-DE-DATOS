<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Sesion.php';
require_once __DIR__ . '/../../services/Totp.php';
require_once __DIR__ . '/../../services/Cifrado.php';
require_once __DIR__ . '/../../services/Recuperacion.php';
require_once __DIR__ . '/../../services/Auditoria.php';
require_once __DIR__ . '/../../services/Validacion.php';

metodo_permitido('POST');

ejecutar_api(function () {
    $pdo = conexion();
    iniciar_sesion_segura();
    $pendiente = $_SESSION['pendiente_2fa'] ?? null;
    if ($pendiente === null || $pendiente['expira'] < time()) {
        $_SESSION = [];
        error_api('La verificación expiró. Inicie sesión nuevamente.', 401);
    }

    $cuenta = cargar_usuario_completo((int)$pendiente['id']);
    if ($cuenta === null || !(bool)$cuenta['activo']) {
        $_SESSION = [];
        error_api('La cuenta no está disponible. Contacte al administrador.', 403);
    }
    if ($cuenta['bloqueado_hasta'] !== null && strtotime($cuenta['bloqueado_hasta']) > time()) {
        $_SESSION = [];
        error_api('La cuenta está bloqueada temporalmente. Intente más tarde.', 423);
    }

    $datos = entrada();
    requerir_campos($datos, ['codigo']);
    $codigo = trim((string)$datos['codigo']);

    $valido = false;
    if (!empty($cuenta['totp_secreto'])) {
        try {
            $valido = totp_verificar(descifrar($cuenta['totp_secreto']), $codigo);
        } catch (RuntimeException) {
            $valido = false;
        }
    }
    if (!$valido) {
        $valido = usar_codigo_recuperacion((int)$cuenta['id_usuario'], $codigo);
    }

    if (!$valido) {
        $intentosCuenta = (int)$cuenta['intentos_fallidos'] + 1;
        $bloqueo = null;
        if ($intentosCuenta >= INTENTOS_MAXIMOS) {
            $bloqueo = date('Y-m-d H:i:s', time() + BLOQUEO_MINUTOS * 60);
            $intentosCuenta = 0;
        }
        $pdo->prepare('UPDATE usuario SET intentos_fallidos = ?, bloqueado_hasta = ? WHERE id_usuario = ?')
            ->execute([$intentosCuenta, $bloqueo, $cuenta['id_usuario']]);
        $pdo->prepare(
            'INSERT INTO intento_login (nombre_usuario, id_usuario, ip, captcha_validado, exitoso) VALUES (?, ?, ?, 1, 0)'
        )->execute([$cuenta['nombre_usuario'], $cuenta['id_usuario'], $_SERVER['REMOTE_ADDR'] ?? null]);

        if ($bloqueo !== null) {
            $_SESSION = [];
            error_api('Demasiados intentos fallidos. La cuenta está bloqueada temporalmente.', 423);
        }
        $_SESSION['pendiente_2fa']['intentos']++;
        if ($_SESSION['pendiente_2fa']['intentos'] >= INTENTOS_MAXIMOS) {
            $_SESSION = [];
            error_api('Demasiados intentos. Inicie sesión nuevamente.', 401);
        }
        error_api('El código no es válido', 401);
    }

    $pdo->prepare('UPDATE usuario SET intentos_fallidos = 0, bloqueado_hasta = NULL WHERE id_usuario = ?')
        ->execute([$cuenta['id_usuario']]);
    iniciar_sesion_usuario($cuenta);
    auditar('LOGIN', 'auth', $cuenta['nombre_usuario'], 'Inicio de sesión con segundo factor', (int)$cuenta['id_usuario']);
    ok_api([], 'Bienvenido');
});
