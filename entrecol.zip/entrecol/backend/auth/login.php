<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Sesion.php';
require_once __DIR__ . '/../../services/Captcha.php';
require_once __DIR__ . '/../../services/Auditoria.php';
require_once __DIR__ . '/../../services/Validacion.php';

metodo_permitido('POST');

ejecutar_api(function () {
    $datos = entrada();
    requerir_campos($datos, ['usuario', 'clave', 'captcha']);
    $usuario = texto($datos['usuario'], 50);
    $clave = (string)$datos['clave'];
    $pdo = conexion();

    $registrar = function (bool $exitoso, bool $captchaOk, ?int $idUsuario) use ($pdo, $usuario) {
        $pdo->prepare(
            'INSERT INTO intento_login (nombre_usuario, id_usuario, ip, captcha_validado, exitoso) VALUES (?, ?, ?, ?, ?)'
        )->execute([$usuario, $idUsuario, $_SERVER['REMOTE_ADDR'] ?? null, (int)$captchaOk, (int)$exitoso]);
    };

    if (!captcha_validar((string)$datos['captcha'])) {
        $registrar(false, false, null);
        error_api('El código CAPTCHA no es correcto', 422);
    }

    $consulta = $pdo->prepare('SELECT id_usuario FROM usuario WHERE nombre_usuario = ?');
    $consulta->execute([$usuario]);
    $idEncontrado = $consulta->fetchColumn();
    if ($idEncontrado === false) {
        $registrar(false, true, null);
        error_api('Usuario o contraseña incorrectos', 401);
    }
    $idUsuario = (int)$idEncontrado;
    $cuenta = cargar_usuario_completo($idUsuario);

    if (!(bool)$cuenta['activo']) {
        $registrar(false, true, $idUsuario);
        error_api('La cuenta está desactivada. Contacte al administrador.', 403);
    }
    if ($cuenta['bloqueado_hasta'] !== null && strtotime($cuenta['bloqueado_hasta']) > time()) {
        $registrar(false, true, $idUsuario);
        error_api('La cuenta está bloqueada temporalmente. Intente más tarde.', 423);
    }
    if (!password_verify($clave, $cuenta['password_hash'])) {
        $intentos = (int)$cuenta['intentos_fallidos'] + 1;
        $bloqueo = null;
        if ($intentos >= INTENTOS_MAXIMOS) {
            $bloqueo = date('Y-m-d H:i:s', time() + BLOQUEO_MINUTOS * 60);
            $intentos = 0;
        }
        $pdo->prepare('UPDATE usuario SET intentos_fallidos = ?, bloqueado_hasta = ? WHERE id_usuario = ?')
            ->execute([$intentos, $bloqueo, $idUsuario]);
        $registrar(false, true, $idUsuario);
        error_api('Usuario o contraseña incorrectos', 401);
    }

    $pdo->prepare('UPDATE usuario SET intentos_fallidos = 0, bloqueado_hasta = NULL WHERE id_usuario = ?')
        ->execute([$idUsuario]);
    $registrar(true, true, $idUsuario);

    if ((int)$cuenta['totp_activo'] === 1) {
        iniciar_sesion_segura();
        session_regenerate_id(true);
        $_SESSION = [
            'pendiente_2fa' => ['id' => $idUsuario, 'expira' => time() + PENDIENTE_2FA_SEGUNDOS, 'intentos' => 0],
        ];
        ok_api(['requiere_2fa' => true], 'Ingrese el código de su aplicación de autenticación');
    }

    iniciar_sesion_usuario($cuenta);
    auditar('LOGIN', 'auth', $usuario, 'Inicio de sesión', $idUsuario);
    ok_api(['requiere_2fa' => false], 'Bienvenido');
});
