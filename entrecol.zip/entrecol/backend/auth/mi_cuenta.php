<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Sesion.php';
require_once __DIR__ . '/../../services/Auditoria.php';
require_once __DIR__ . '/../../services/Validacion.php';

$usuario = requerir_sesion();

ejecutar_api(function () use ($usuario) {
    $pdo = conexion();
    $cuenta = cargar_usuario_completo((int)$usuario['id']);

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        ok_api(['cuenta' => [
            'nombre' => $cuenta['nombre_completo'],
            'usuario' => $cuenta['nombre_usuario'],
            'rol' => $cuenta['rol'],
            'segundo_factor' => (int)$cuenta['totp_activo'] === 1,
        ]]);
    }

    metodo_permitido('POST');
    $datos = entrada();
    requerir_campos($datos, ['clave_actual', 'clave_nueva', 'confirmar']);

    if (!password_verify((string)$datos['clave_actual'], $cuenta['password_hash'])) {
        error_api('La contraseña actual no es correcta', 401);
    }
    $nueva = (string)$datos['clave_nueva'];
    if (mb_strlen($nueva) < 10) {
        throw new InvalidArgumentException('La nueva contraseña debe tener al menos 10 caracteres');
    }
    if (!preg_match('/[A-Za-z]/', $nueva) || !preg_match('/\d/', $nueva)) {
        throw new InvalidArgumentException('La nueva contraseña debe incluir letras y números');
    }
    if ($nueva !== (string)$datos['confirmar']) {
        throw new InvalidArgumentException('La confirmación no coincide con la nueva contraseña');
    }
    if (password_verify($nueva, $cuenta['password_hash'])) {
        throw new InvalidArgumentException('La nueva contraseña debe ser distinta a la actual');
    }

    $pdo->prepare('UPDATE usuario SET password_hash = ?, intentos_fallidos = 0, bloqueado_hasta = NULL WHERE id_usuario = ?')
        ->execute([password_hash($nueva, PASSWORD_DEFAULT), (int)$usuario['id']]);
    auditar('UPDATE', 'usuarios', $usuario['usuario'], 'Cambio de contraseña propia');
    ok_api([], 'Contraseña actualizada correctamente');
});
