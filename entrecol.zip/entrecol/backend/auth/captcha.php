<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Captcha.php';

metodo_permitido('GET');
captcha_generar_imagen();
