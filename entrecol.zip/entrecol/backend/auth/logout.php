<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Sesion.php';
require_once __DIR__ . '/../../services/Auditoria.php';
require_once __DIR__ . '/../../services/Validacion.php';

metodo_permitido('POST');
$usuario = requerir_sesion();
auditar('LOGOUT', 'auth', $usuario['usuario'], 'Cierre de sesión');
cerrar_sesion();
ok_api([], 'Sesión cerrada');
