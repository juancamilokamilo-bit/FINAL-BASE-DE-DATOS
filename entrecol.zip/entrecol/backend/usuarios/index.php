<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Sesion.php';
require_once __DIR__ . '/../../services/Auditoria.php';
require_once __DIR__ . '/../../services/Validacion.php';

$actual = requerir_sesion('usuarios.administrar');

ejecutar_api(function () use ($actual) {
    $pdo = conexion();
    switch ($_SERVER['REQUEST_METHOD']) {
        case 'GET':
            if (isset($_GET['roles'])) {
                ok_api(['roles' => $pdo->query('SELECT id_rol, nombre, descripcion FROM rol ORDER BY id_rol')->fetchAll()]);
            }
            [$condicion, $params] = filtros_sql([
                'q' => ['(u.nombre_completo LIKE ? OR u.nombre_usuario LIKE ?)', 'like'],
                'rol' => ['u.id_rol = ?', 'entero'],
                'activo' => ['u.activo = ?', 'entero'],
            ], $_GET);
            $consulta = $pdo->prepare(
                'SELECT u.id_usuario, u.nombre_completo, u.nombre_usuario, u.correo, u.activo, u.totp_activo,
                        u.ultimo_acceso, u.id_rol, r.nombre AS rol
                 FROM usuario u JOIN rol r ON r.id_rol = u.id_rol'
                . $condicion
                . ' ORDER BY u.nombre_completo'
            );
            $consulta->execute($params);
            ok_api(['usuarios' => $consulta->fetchAll()]);

        case 'POST':
            $d = entrada();
            requerir_campos($d, ['nombre_completo', 'nombre_usuario', 'correo', 'clave', 'id_rol']);
            $nombreUsuario = texto($d['nombre_usuario'], 50);
            if (!preg_match('/^[A-Za-z0-9._-]{3,50}$/', $nombreUsuario)) {
                throw new InvalidArgumentException('El nombre de usuario solo puede tener letras, números, punto, guion y guion bajo');
            }
            if (!filter_var($d['correo'], FILTER_VALIDATE_EMAIL)) {
                throw new InvalidArgumentException('El correo no es válido');
            }
            if (mb_strlen((string)$d['clave']) < 10) {
                throw new InvalidArgumentException('La contraseña debe tener al menos 10 caracteres');
            }
            $pdo->prepare(
                'INSERT INTO usuario (nombre_completo, nombre_usuario, correo, password_hash, id_rol, activo)
                 VALUES (?, ?, ?, ?, ?, 1)'
            )->execute([
                texto($d['nombre_completo'], 120),
                $nombreUsuario,
                texto($d['correo'], 120),
                password_hash((string)$d['clave'], PASSWORD_DEFAULT),
                entero($d['id_rol']),
            ]);
            auditar('INSERT', 'usuarios', $nombreUsuario, 'Usuario creado');
            ok_api([], 'Usuario creado correctamente');

        case 'PUT':
            $d = entrada();
            requerir_campos($d, ['id_usuario', 'nombre_completo', 'correo', 'id_rol']);
            $id = entero($d['id_usuario']);
            if ($id === $actual['id'] && (int)($d['activo'] ?? 1) === 0) {
                throw new InvalidArgumentException('No puede desactivar su propia cuenta');
            }
            if (!filter_var($d['correo'], FILTER_VALIDATE_EMAIL)) {
                throw new InvalidArgumentException('El correo no es válido');
            }
            $pdo->prepare(
                'UPDATE usuario SET nombre_completo = ?, correo = ?, id_rol = ?, activo = ? WHERE id_usuario = ?'
            )->execute([
                texto($d['nombre_completo'], 120),
                texto($d['correo'], 120),
                entero($d['id_rol']),
                (int)($d['activo'] ?? 1) === 1 ? 1 : 0,
                $id,
            ]);
            if (!empty($d['clave'])) {
                if (mb_strlen((string)$d['clave']) < 10) {
                    throw new InvalidArgumentException('La contraseña debe tener al menos 10 caracteres');
                }
                $pdo->prepare('UPDATE usuario SET password_hash = ?, intentos_fallidos = 0, bloqueado_hasta = NULL WHERE id_usuario = ?')
                    ->execute([password_hash((string)$d['clave'], PASSWORD_DEFAULT), $id]);
            }
            auditar('UPDATE', 'usuarios', (string)$id, 'Usuario actualizado');
            ok_api([], 'Usuario actualizado correctamente');
    }
    error_api('Método HTTP no permitido', 405);
});
