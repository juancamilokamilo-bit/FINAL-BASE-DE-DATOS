<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Sesion.php';
require_once __DIR__ . '/../../services/Validacion.php';

metodo_permitido('GET');
requerir_sesion('auditoria.consultar');

ejecutar_api(function () {
    $where = [];
    $params = [];
    if (!empty($_GET['modulo'])) {
        $where[] = 'a.modulo = ?';
        $params[] = texto($_GET['modulo'], 40);
    }
    if (!empty($_GET['accion'])) {
        $where[] = 'a.accion = ?';
        $params[] = texto($_GET['accion'], 30);
    }
    if (!empty($_GET['usuario'])) {
        $where[] = 'u.nombre_usuario LIKE ?';
        $params[] = '%' . texto($_GET['usuario'], 50) . '%';
    }
    $desde = fecha_iso($_GET['desde'] ?? null);
    $hasta = fecha_iso($_GET['hasta'] ?? null);
    if ($desde === false || $hasta === false) {
        throw new InvalidArgumentException('Las fechas de auditoría no son válidas (AAAA-MM-DD)');
    }
    if ($desde) {
        $where[] = 'a.fecha_hora >= ?';
        $params[] = $desde . ' 00:00:00';
    }
    if ($hasta) {
        $where[] = 'a.fecha_hora <= ?';
        $params[] = $hasta . ' 23:59:59';
    }
    $condicion = $where ? ' WHERE ' . implode(' AND ', $where) : '';
    $registros = consultar_paginado(
        conexion(),
        'SELECT a.id_auditoria, a.fecha_hora, u.nombre_usuario AS usuario, a.accion, a.modulo,
                a.registro_afectado, a.descripcion, a.ip
         FROM auditoria a LEFT JOIN usuario u ON u.id_usuario = a.id_usuario' . $condicion
        . ' ORDER BY a.id_auditoria DESC LIMIT ? OFFSET ?',
        $params,
        500,
        0
    );
    ok_api(['registros' => $registros]);
});
