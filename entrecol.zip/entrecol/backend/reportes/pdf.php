<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Sesion.php';
require_once __DIR__ . '/../../services/Reportes.php';
require_once __DIR__ . '/../../services/Pdf.php';
require_once __DIR__ . '/../../services/Auditoria.php';
require_once __DIR__ . '/../../services/Validacion.php';

metodo_permitido('GET');
requerir_sesion('reportes.exportar_pdf');

ejecutar_api(function () {
    $tipo = (string)($_GET['tipo'] ?? '');
    $reporte = construir_reporte($tipo, $_GET);
    $contenido = pdf_reporte($reporte);
    $nombre = 'reporte_' . preg_replace('/[^a-z_]/', '', $tipo) . '_' . date('Ymd_His') . '.pdf';
    file_put_contents(__DIR__ . '/../../generated_reports/' . $nombre, $contenido);
    auditar('PDF', 'reportes', $tipo, 'Reporte PDF generado: ' . $reporte['titulo']);
    header('Content-Type: application/pdf');
    header('Content-Length: ' . strlen($contenido));
    header('Content-Disposition: ' . (isset($_GET['descargar']) ? 'attachment' : 'inline') . '; filename="' . $nombre . '"');
    echo $contenido;
    exit;
});
