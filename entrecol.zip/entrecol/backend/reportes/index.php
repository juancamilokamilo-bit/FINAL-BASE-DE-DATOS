<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Sesion.php';
require_once __DIR__ . '/../../services/Reportes.php';
require_once __DIR__ . '/../../services/Validacion.php';

metodo_permitido('GET');
requerir_sesion('reportes.consultar');

ejecutar_api(function () {
    if (isset($_GET['generos'])) {
        ok_api(['generos' => conexion()->query('SELECT nombre FROM genero ORDER BY nombre')->fetchAll(PDO::FETCH_COLUMN)]);
    }
    ok_api(['reporte' => construir_reporte((string)($_GET['tipo'] ?? ''), $_GET)]);
});
