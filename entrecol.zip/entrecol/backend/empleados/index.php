<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Sesion.php';
require_once __DIR__ . '/../../services/Auditoria.php';
require_once __DIR__ . '/../../services/Validacion.php';

const CATALOGOS = [
    'dependencias' => ['tabla' => 'dependencia', 'id' => 'id_dependencia', 'etiqueta' => 'Dependencia'],
    'cargos' => ['tabla' => 'cargo', 'id' => 'id_cargo', 'etiqueta' => 'Cargo'],
    'eps' => ['tabla' => 'eps', 'id' => 'id_eps', 'etiqueta' => 'EPS'],
    'pensiones' => ['tabla' => 'fondo_pension', 'id' => 'id_pension', 'etiqueta' => 'Fondo de pensión'],
    'arl' => ['tabla' => 'arl', 'id' => 'id_arl', 'etiqueta' => 'ARL'],
];

function config_catalogo(?string $nombre): array
{
    if (!isset(CATALOGOS[$nombre])) {
        throw new InvalidArgumentException('Catálogo no válido');
    }
    return CATALOGOS[$nombre];
}

function listar_catalogo(array $c): array
{
    return conexion()->query("SELECT {$c['id']} AS id, nombre FROM {$c['tabla']} ORDER BY nombre")->fetchAll();
}

function datos_empleado(array $d): array
{
    requerir_campos($d, ['nombre_completo', 'id_dependencia', 'id_cargo', 'fecha_ingreso', 'id_eps', 'id_arl', 'id_pension', 'salario']);
    $ingreso = fecha_iso($d['fecha_ingreso']);
    if (!$ingreso) {
        throw new InvalidArgumentException('La fecha de ingreso no es válida (AAAA-MM-DD)');
    }
    $salario = decimal($d['salario']);
    if ($salario === null || $salario <= 0) {
        throw new InvalidArgumentException('El salario debe ser mayor a cero');
    }
    $dependencia = entero($d['id_dependencia']);
    $cargo = entero($d['id_cargo']);
    $eps = entero($d['id_eps']);
    $arl = entero($d['id_arl']);
    $pension = entero($d['id_pension']);
    if (in_array(null, [$dependencia, $cargo, $eps, $arl, $pension], true)) {
        throw new InvalidArgumentException('Seleccione dependencia, cargo, EPS, ARL y pensión');
    }
    return [texto($d['nombre_completo'], 150), $dependencia, $cargo, $ingreso, $eps, $arl, $pension, $salario];
}

ejecutar_api(function () {
    $pdo = conexion();
    $metodo = $_SERVER['REQUEST_METHOD'];

    if ($metodo === 'GET') {
        requerir_sesion('nomina.consultar');
        if (isset($_GET['catalogo'])) {
            if ($_GET['catalogo'] === 'todos') {
                $todos = [];
                foreach (array_keys(CATALOGOS) as $nombre) {
                    $todos[$nombre] = listar_catalogo(CATALOGOS[$nombre]);
                }
                ok_api(['catalogos' => $todos]);
            }
            ok_api(['items' => listar_catalogo(config_catalogo($_GET['catalogo']))]);
        }
        if (isset($_GET['id'])) {
            $consulta = $pdo->prepare(
                'SELECT e.id_empleado AS codigo, e.nombre_completo, e.id_dependencia, d.nombre AS dependencia,
                        e.id_cargo, c.nombre AS cargo, e.fecha_ingreso, e.id_eps, eps.nombre AS eps,
                        e.id_pension, fp.nombre AS pension, e.id_arl, arl.nombre AS arl, e.salario
                 FROM empleado e
                 JOIN dependencia d ON d.id_dependencia = e.id_dependencia
                 JOIN cargo c ON c.id_cargo = e.id_cargo
                 JOIN eps ON eps.id_eps = e.id_eps
                 JOIN fondo_pension fp ON fp.id_pension = e.id_pension
                 JOIN arl ON arl.id_arl = e.id_arl
                 WHERE e.id_empleado = ?'
            );
            $consulta->execute([entero($_GET['id'])]);
            $empleado = $consulta->fetch();
            if (!$empleado) {
                error_api('Empleado no encontrado', 404);
            }
            ok_api(['empleado' => $empleado]);
        }
        [$condicion, $params] = filtros_sql([
            'q' => ['e.nombre_completo LIKE ?', 'like'],
            'dependencia' => ['e.id_dependencia = ?', 'entero'],
            'cargo' => ['e.id_cargo = ?', 'entero'],
            'eps' => ['e.id_eps = ?', 'entero'],
            'pension' => ['e.id_pension = ?', 'entero'],
            'arl' => ['e.id_arl = ?', 'entero'],
            'ingreso_desde' => ['e.fecha_ingreso >= ?', 'fecha'],
            'ingreso_hasta' => ['e.fecha_ingreso <= ?', 'fecha'],
            'salario_min' => ['e.salario >= ?', 'decimal'],
            'salario_max' => ['e.salario <= ?', 'decimal'],
        ], $_GET);
        $orden = orden_columna([
            'nombre' => 'e.nombre_completo',
            'codigo' => 'e.id_empleado',
            'ingreso' => 'e.fecha_ingreso',
            'salario' => 'e.salario',
            'dependencia' => 'd.nombre',
        ], $_GET['orden'] ?? 'nombre', 'e.nombre_completo');
        $sql = 'SELECT e.id_empleado AS codigo, e.nombre_completo, d.id_dependencia AS id_dependencia, d.nombre AS dependencia,
                       c.id_cargo AS id_cargo, c.nombre AS cargo, e.fecha_ingreso, eps.id_eps AS id_eps, eps.nombre AS eps,
                       fp.id_pension AS id_pension, fp.nombre AS pension, arl.id_arl AS id_arl, arl.nombre AS arl, e.salario
                FROM empleado e
                JOIN dependencia d ON d.id_dependencia = e.id_dependencia
                JOIN cargo c ON c.id_cargo = e.id_cargo
                JOIN eps ON eps.id_eps = e.id_eps
                JOIN fondo_pension fp ON fp.id_pension = e.id_pension
                JOIN arl ON arl.id_arl = e.id_arl'
            . $condicion
            . " ORDER BY $orden " . orden_sql($_GET['dir'] ?? 'asc');
        $consulta = $pdo->prepare($sql);
        $consulta->execute($params);
        $empleados = $consulta->fetchAll();
        if (($_GET['exportar'] ?? '') === 'csv') {
            enviar_csv(
                'nomina',
                ['Código', 'Nombre', 'Dependencia', 'Cargo', 'Fecha ingreso', 'EPS', 'Pensión', 'ARL', 'Salario'],
                array_map(fn($e) => [
                    $e['codigo'], $e['nombre_completo'], $e['dependencia'], $e['cargo'], $e['fecha_ingreso'],
                    $e['eps'], $e['pension'], $e['arl'], $e['salario'],
                ], $empleados)
            );
        }
        ok_api(['empleados' => $empleados, 'total' => count($empleados)]);
    }

    requerir_sesion('nomina.editar');

    if ($metodo === 'POST') {
        $d = entrada();
        if (isset($d['catalogo'])) {
            $c = config_catalogo($d['catalogo']);
            requerir_campos($d, ['nombre']);
            $pdo->prepare("INSERT INTO {$c['tabla']} (nombre) VALUES (?)")->execute([texto($d['nombre'], 100)]);
            auditar('INSERT', 'nomina', $c['etiqueta'] . ': ' . texto($d['nombre'], 100), 'Catálogo creado');
            ok_api([], 'Registro creado correctamente');
        }
        requerir_campos($d, ['codigo']);
        $codigo = entero($d['codigo']);
        if ($codigo === null || $codigo <= 0) {
            throw new InvalidArgumentException('El código del empleado no es válido');
        }
        $pdo->prepare(
            'INSERT INTO empleado (id_empleado, nombre_completo, id_dependencia, id_cargo, fecha_ingreso, id_eps, id_arl, id_pension, salario, activo)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)'
        )->execute(array_merge([$codigo], datos_empleado($d)));
        auditar('INSERT', 'nomina', (string)$codigo, 'Empleado registrado');
        ok_api([], 'Empleado registrado correctamente');
    }

    if ($metodo === 'PUT') {
        $d = entrada();
        if (isset($d['catalogo'])) {
            $c = config_catalogo($d['catalogo']);
            requerir_campos($d, ['id', 'nombre']);
            $pdo->prepare("UPDATE {$c['tabla']} SET nombre = ? WHERE {$c['id']} = ?")
                ->execute([texto($d['nombre'], 100), entero($d['id'])]);
            auditar('UPDATE', 'nomina', $c['etiqueta'] . ' ' . entero($d['id']), 'Catálogo actualizado');
            ok_api([], 'Registro actualizado correctamente');
        }
        requerir_campos($d, ['codigo']);
        $codigo = entero($d['codigo']);
        $pdo->prepare(
            'UPDATE empleado SET nombre_completo = ?, id_dependencia = ?, id_cargo = ?, fecha_ingreso = ?, id_eps = ?,
                    id_arl = ?, id_pension = ?, salario = ? WHERE id_empleado = ?'
        )->execute(array_merge(datos_empleado($d), [$codigo]));
        auditar('UPDATE', 'nomina', (string)$codigo, 'Empleado actualizado');
        ok_api([], 'Empleado actualizado correctamente');
    }

    if ($metodo === 'DELETE') {
        if (isset($_GET['catalogo'])) {
            $c = config_catalogo($_GET['catalogo']);
            $pdo->prepare("DELETE FROM {$c['tabla']} WHERE {$c['id']} = ?")->execute([entero($_GET['id'] ?? null)]);
            auditar('DELETE', 'nomina', $c['etiqueta'] . ' ' . ($_GET['id'] ?? ''), 'Catálogo eliminado');
            ok_api([], 'Registro eliminado correctamente');
        }
        $codigo = entero($_GET['id'] ?? null);
        $pdo->prepare('DELETE FROM empleado WHERE id_empleado = ?')->execute([$codigo]);
        auditar('DELETE', 'nomina', (string)$codigo, 'Empleado eliminado');
        ok_api([], 'Empleado eliminado correctamente');
    }

    error_api('Método HTTP no permitido', 405);
});
