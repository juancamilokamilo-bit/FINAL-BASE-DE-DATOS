<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Sesion.php';
require_once __DIR__ . '/../../services/Auditoria.php';
require_once __DIR__ . '/../../services/Validacion.php';
require_once __DIR__ . '/../../services/Importador.php';

$usuario = requerir_sesion('importar.ejecutar');

ejecutar_api(function () use ($usuario) {
    $pdo = conexion();

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (isset($_GET['id'])) {
            $detalle = $pdo->prepare(
                'SELECT referencia, tipo_error, motivo, contenido FROM importacion_detalle WHERE id_importacion = ? ORDER BY id_detalle LIMIT 500'
            );
            $detalle->execute([entero($_GET['id'])]);
            ok_api(['detalles' => $detalle->fetchAll()]);
        }
        [$condicion, $params] = filtros_sql([
            'tipo' => ['i.tipo_archivo = ?', 'texto'],
            'usuario' => ['u.nombre_usuario LIKE ?', 'like'],
            'archivo' => ['i.nombre_archivo LIKE ?', 'like'],
            'desde' => ['DATE(i.fecha_hora) >= ?', 'fecha'],
            'hasta' => ['DATE(i.fecha_hora) <= ?', 'fecha'],
        ], $_GET);
        $consulta = $pdo->prepare(
            'SELECT i.id_importacion, i.tipo_archivo, i.nombre_archivo, i.fecha_hora, u.nombre_usuario AS usuario,
                    i.total_registros, i.registros_insertados, i.registros_duplicados, i.registros_error
             FROM importacion i LEFT JOIN usuario u ON u.id_usuario = i.id_usuario'
            . $condicion
            . ' ORDER BY i.id_importacion DESC LIMIT 100'
        );
        $consulta->execute($params);
        ok_api(['historial' => $consulta->fetchAll()]);
    }

    metodo_permitido('POST');

    $tipo = strtoupper(texto($_POST['tipo'] ?? '', 10));
    $extensiones = ['XLSX' => 'xlsx', 'DAT' => 'dat', 'JSON' => 'json'];
    if (!isset($extensiones[$tipo])) {
        throw new InvalidArgumentException('Seleccione un tipo de archivo válido (XLSX, DAT o JSON)');
    }
    if (!isset($_FILES['archivo']) || $_FILES['archivo']['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('No se recibió el archivo. Verifique el tamaño permitido por el servidor.');
    }
    $archivo = $_FILES['archivo'];
    if ($archivo['size'] > TAMANO_MAXIMO_ARCHIVO) {
        throw new RuntimeException('El archivo supera el tamaño máximo permitido (20 MB)');
    }
    $extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
    if ($extension !== $extensiones[$tipo]) {
        throw new InvalidArgumentException("El archivo debe tener extensión .{$extensiones[$tipo]} para el tipo $tipo");
    }
    if (!is_uploaded_file($archivo['tmp_name'])) {
        throw new RuntimeException('El archivo recibido no es válido');
    }

    $periodo = null;
    if (($_POST['periodo'] ?? '') !== '') {
        $periodo = periodo_mes($_POST['periodo']);
        if ($periodo === null) {
            throw new InvalidArgumentException('El periodo de novedades debe tener el formato MM/AAAA');
        }
    }

    $destino = __DIR__ . '/../../uploads/' . bin2hex(random_bytes(8)) . '.' . $extension;
    if (!move_uploaded_file($archivo['tmp_name'], $destino)) {
        throw new RuntimeException('No se pudo guardar el archivo en la carpeta uploads');
    }
    if ($tipo === 'XLSX' && file_get_contents($destino, false, null, 0, 2) !== 'PK') {
        throw new InvalidArgumentException('El archivo no es un XLSX válido');
    }

    $resultado = procesar_importacion($tipo, $destino, $archivo['name'], $periodo, (int)$usuario['id']);
    auditar(
        'IMPORT',
        'importaciones',
        $archivo['name'],
        "Importación $tipo: {$resultado['insertados']} insertados, {$resultado['duplicados']} duplicados, {$resultado['errores']} errores"
    );
    ok_api($resultado, 'Importación finalizada');
});
