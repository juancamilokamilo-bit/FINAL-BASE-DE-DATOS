<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Sesion.php';
require_once __DIR__ . '/../../services/Auditoria.php';
require_once __DIR__ . '/../../services/Validacion.php';

const PELICULAS_POR_PAGINA = 50;

function guardar_generos_pelicula(PDO $pdo, int $id, array $generos): void
{
    $pdo->prepare('DELETE FROM pelicula_genero WHERE id_pelicula = ?')->execute([$id]);
    $relacionar = $pdo->prepare('INSERT IGNORE INTO pelicula_genero (id_pelicula, id_genero) VALUES (?, ?)');
    $nombres = array_unique(array_filter(array_map(fn($g) => texto($g, 60), $generos), fn($g) => $g !== ''));
    foreach ($nombres as $nombre) {
        $relacionar->execute([$id, catalogo_id('genero', 'nombre', 'id_genero', $nombre)]);
    }
}

function datos_pelicula(array $d): array
{
    requerir_campos($d, ['titulo']);
    $anio = null;
    if (isset($d['anio']) && $d['anio'] !== '') {
        $anio = entero($d['anio']);
        if ($anio === null || $anio < 1880 || $anio > 2100) {
            throw new InvalidArgumentException('El año de la película no es válido');
        }
    }
    return [texto($d['titulo'], 300), $anio];
}

ejecutar_api(function () {
    $pdo = conexion();
    $metodo = $_SERVER['REQUEST_METHOD'];

    if ($metodo === 'GET') {
        requerir_sesion('peliculas.consultar');
        if (isset($_GET['generos'])) {
            ok_api(['generos' => $pdo->query('SELECT id_genero AS id, nombre FROM genero ORDER BY nombre')->fetchAll()]);
        }
        if (isset($_GET['id'])) {
            $consulta = $pdo->prepare('SELECT id_pelicula, titulo, anio FROM pelicula WHERE id_pelicula = ?');
            $consulta->execute([entero($_GET['id'])]);
            $pelicula = $consulta->fetch();
            if (!$pelicula) {
                error_api('Película no encontrada', 404);
            }
            $generos = $pdo->prepare(
                'SELECT g.nombre FROM pelicula_genero pg JOIN genero g ON g.id_genero = pg.id_genero WHERE pg.id_pelicula = ? ORDER BY g.nombre'
            );
            $generos->execute([$pelicula['id_pelicula']]);
            $pelicula['generos'] = $generos->fetchAll(PDO::FETCH_COLUMN);
            ok_api(['pelicula' => $pelicula]);
        }

        [$condicion, $params] = filtros_sql([
            'q' => ['p.titulo LIKE ?', 'like'],
            'genero' => ['EXISTS (SELECT 1 FROM pelicula_genero pg JOIN genero g ON g.id_genero = pg.id_genero WHERE pg.id_pelicula = p.id_pelicula AND g.nombre = ?)', 'texto'],
            'anio_desde' => ['p.anio >= ?', 'entero'],
            'anio_hasta' => ['p.anio <= ?', 'entero'],
        ], $_GET);
        $orden = orden_columna(['titulo' => 'p.titulo', 'anio' => 'p.anio', 'id' => 'p.id_pelicula'], $_GET['orden'] ?? 'titulo', 'p.titulo');
        $sentido = orden_sql($_GET['dir'] ?? 'asc');
        $seleccion = 'SELECT p.id_pelicula, p.titulo, p.anio, (
                SELECT GROUP_CONCAT(g.nombre ORDER BY g.nombre SEPARATOR \', \')
                FROM pelicula_genero pg JOIN genero g ON g.id_genero = pg.id_genero
                WHERE pg.id_pelicula = p.id_pelicula) AS generos
             FROM pelicula p';
        if (($_GET['exportar'] ?? '') === 'csv') {
            $exportacion = $pdo->prepare($seleccion . $condicion . " ORDER BY $orden $sentido");
            $exportacion->execute($params);
            enviar_csv('peliculas', ['ID', 'Título', 'Año', 'Géneros'], $exportacion->fetchAll(PDO::FETCH_NUM));
        }
        $total = contar_registros($pdo, 'SELECT COUNT(*) FROM pelicula p' . $condicion, $params);
        $pagina = pagina_actual();
        $filas = consultar_paginado(
            $pdo,
            $seleccion . $condicion . " ORDER BY $orden $sentido LIMIT ? OFFSET ?",
            $params,
            PELICULAS_POR_PAGINA,
            ($pagina - 1) * PELICULAS_POR_PAGINA
        );
        ok_api([
            'peliculas' => $filas,
            'total' => $total,
            'pagina' => $pagina,
            'paginas' => max(1, (int)ceil($total / PELICULAS_POR_PAGINA)),
        ]);
    }

    requerir_sesion('peliculas.editar');

    if ($metodo === 'POST') {
        $d = entrada();
        [$titulo, $anio] = datos_pelicula($d);
        $pdo->beginTransaction();
        $id = (int)$pdo->query('SELECT COALESCE(MAX(id_pelicula), 0) + 1 FROM pelicula')->fetchColumn();
        $pdo->prepare('INSERT INTO pelicula (id_pelicula, titulo, anio) VALUES (?, ?, ?)')->execute([$id, $titulo, $anio]);
        guardar_generos_pelicula($pdo, $id, (array)($d['generos'] ?? []));
        $pdo->commit();
        auditar('INSERT', 'peliculas', (string)$id, "Película creada: $titulo");
        ok_api(['id' => $id], 'Película registrada correctamente');
    }

    if ($metodo === 'PUT') {
        $d = entrada();
        requerir_campos($d, ['id_pelicula']);
        [$titulo, $anio] = datos_pelicula($d);
        $id = entero($d['id_pelicula']);
        $pdo->beginTransaction();
        $pdo->prepare('UPDATE pelicula SET titulo = ?, anio = ? WHERE id_pelicula = ?')->execute([$titulo, $anio, $id]);
        guardar_generos_pelicula($pdo, $id, (array)($d['generos'] ?? []));
        $pdo->commit();
        auditar('UPDATE', 'peliculas', (string)$id, "Película actualizada: $titulo");
        ok_api([], 'Película actualizada correctamente');
    }

    if ($metodo === 'DELETE') {
        $id = entero($_GET['id'] ?? null);
        $pdo->prepare('DELETE FROM pelicula WHERE id_pelicula = ?')->execute([$id]);
        auditar('DELETE', 'peliculas', (string)$id, 'Película eliminada');
        ok_api([], 'Película eliminada correctamente');
    }

    error_api('Método HTTP no permitido', 405);
});
