<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Sesion.php';
require_once __DIR__ . '/../../services/Auditoria.php';
require_once __DIR__ . '/../../services/Validacion.php';

function datos_novedad(array $d): array
{
    requerir_campos($d, ['id_empleado', 'periodo']);
    $periodo = periodo_mes($d['periodo']);
    if ($periodo === null) {
        throw new InvalidArgumentException('El periodo debe tener el formato MM/AAAA');
    }
    $trabajados = entero($d['dias_trabajados'] ?? 0);
    $incapacidad = entero($d['dias_incapacidad'] ?? 0);
    $vacaciones = entero($d['dias_vacaciones'] ?? 0);
    if ($trabajados === null || $incapacidad === null || $vacaciones === null
        || $trabajados < 0 || $incapacidad < 0 || $vacaciones < 0
        || $trabajados + $incapacidad + $vacaciones > 31) {
        throw new InvalidArgumentException('Los días reportados no son válidos (la suma no puede superar 31)');
    }
    $fechas = [
        fecha_iso($d['fecha_inicio_incapacidad'] ?? null),
        fecha_iso($d['fecha_fin_incapacidad'] ?? null),
        fecha_iso($d['fecha_inicio_vacaciones'] ?? null),
        fecha_iso($d['fecha_fin_vacaciones'] ?? null),
    ];
    if (in_array(false, $fechas, true)) {
        throw new InvalidArgumentException('Una de las fechas de la novedad no es válida');
    }
    return [
        entero($d['id_empleado']), $periodo, $trabajados, $incapacidad, $vacaciones,
        ...$fechas,
        decimal($d['bonificacion'] ?? 0) ?? 0,
        decimal($d['auxilio_transporte'] ?? 0) ?? 0,
    ];
}

ejecutar_api(function () {
    $pdo = conexion();
    $metodo = $_SERVER['REQUEST_METHOD'];

    if ($metodo === 'GET') {
        requerir_sesion('nomina.consultar');
        if (isset($_GET['periodos'])) {
            $periodos = $pdo->query("SELECT DATE_FORMAT(periodo, '%m/%Y') AS periodo FROM novedad_mensual GROUP BY periodo ORDER BY periodo DESC")
                ->fetchAll(PDO::FETCH_COLUMN);
            ok_api(['periodos' => $periodos]);
        }
        if (isset($_GET['pendientes'])) {
            $periodo = periodo_mes($_GET['periodo'] ?? '');
            if ($periodo === null) {
                throw new InvalidArgumentException('Seleccione un periodo válido (MM/AAAA)');
            }
            $consulta = $pdo->prepare(
                "SELECT e.id_empleado AS codigo, e.nombre_completo, d.nombre AS dependencia, c.nombre AS cargo, e.salario
                 FROM empleado e
                 JOIN dependencia d ON d.id_dependencia = e.id_dependencia
                 JOIN cargo c ON c.id_cargo = e.id_cargo
                 WHERE e.activo = 1 AND NOT EXISTS (
                    SELECT 1 FROM novedad_mensual n WHERE n.id_empleado = e.id_empleado AND n.periodo = ?)
                 ORDER BY e.nombre_completo ASC"
            );
            $consulta->execute([$periodo]);
            $pendientes = $consulta->fetchAll();
            if (($_GET['exportar'] ?? '') === 'csv') {
                enviar_csv(
                    'novedades_pendientes_' . str_replace('-', '', substr($periodo, 0, 7)),
                    ['Código', 'Nombre', 'Dependencia', 'Cargo', 'Salario'],
                    array_map(fn($p) => [$p['codigo'], $p['nombre_completo'], $p['dependencia'], $p['cargo'], $p['salario']], $pendientes)
                );
            }
            ok_api(['pendientes' => $pendientes, 'total' => count($pendientes)]);
        }
        [$condicion, $params] = filtros_sql([
            'periodo' => ['n.periodo = ?', 'periodo'],
            'q' => ['e.nombre_completo LIKE ?', 'like'],
            'dependencia' => ['e.id_dependencia = ?', 'entero'],
            'dias_incapacidad_min' => ['n.dias_incapacidad >= ?', 'entero'],
            'dias_vacaciones_min' => ['n.dias_vacaciones >= ?', 'entero'],
        ], $_GET);
        $consulta = $pdo->prepare(
            "SELECT n.id_novedad, e.id_empleado AS codigo, e.nombre_completo, d.nombre AS dependencia, c.nombre AS cargo,
                    DATE_FORMAT(n.periodo, '%m/%Y') AS periodo, n.dias_trabajados, n.dias_incapacidad, n.dias_vacaciones,
                    n.fecha_inicio_incapacidad, n.fecha_fin_incapacidad, n.fecha_inicio_vacaciones, n.fecha_fin_vacaciones,
                    n.bonificacion, n.auxilio_transporte
             FROM novedad_mensual n
             JOIN empleado e ON e.id_empleado = n.id_empleado
             JOIN dependencia d ON d.id_dependencia = e.id_dependencia
             JOIN cargo c ON c.id_cargo = e.id_cargo"
            . $condicion
            . ' ORDER BY e.nombre_completo ASC'
        );
        $consulta->execute($params);
        ok_api(['novedades' => $consulta->fetchAll()]);
    }

    requerir_sesion('nomina.editar');

    if ($metodo === 'POST') {
        $datos = datos_novedad(entrada());
        $pdo->prepare(
            'INSERT INTO novedad_mensual (id_empleado, periodo, dias_trabajados, dias_incapacidad, dias_vacaciones,
                fecha_inicio_incapacidad, fecha_fin_incapacidad, fecha_inicio_vacaciones, fecha_fin_vacaciones,
                bonificacion, auxilio_transporte)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute($datos);
        auditar('INSERT', 'novedades', $datos[0] . ' ' . $datos[1], 'Novedad registrada');
        ok_api([], 'Novedad registrada correctamente');
    }

    if ($metodo === 'PUT') {
        $d = entrada();
        requerir_campos($d, ['id_novedad']);
        $datos = datos_novedad($d);
        $pdo->prepare(
            'UPDATE novedad_mensual SET id_empleado = ?, periodo = ?, dias_trabajados = ?, dias_incapacidad = ?, dias_vacaciones = ?,
                fecha_inicio_incapacidad = ?, fecha_fin_incapacidad = ?, fecha_inicio_vacaciones = ?, fecha_fin_vacaciones = ?,
                bonificacion = ?, auxilio_transporte = ?
             WHERE id_novedad = ?'
        )->execute(array_merge($datos, [entero($d['id_novedad'])]));
        auditar('UPDATE', 'novedades', (string)entero($d['id_novedad']), 'Novedad actualizada');
        ok_api([], 'Novedad actualizada correctamente');
    }

    if ($metodo === 'DELETE') {
        $id = entero($_GET['id'] ?? null);
        $pdo->prepare('DELETE FROM novedad_mensual WHERE id_novedad = ?')->execute([$id]);
        auditar('DELETE', 'novedades', (string)$id, 'Novedad eliminada');
        ok_api([], 'Novedad eliminada correctamente');
    }

    error_api('Método HTTP no permitido', 405);
});
