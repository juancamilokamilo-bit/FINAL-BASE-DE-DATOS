<?php
declare(strict_types=1);

require_once __DIR__ . '/../../services/Sesion.php';
require_once __DIR__ . '/../../services/Auditoria.php';
require_once __DIR__ . '/../../services/Validacion.php';

const LIBROS_POR_PAGINA = 50;

function autores_lista(mixed $valor): array
{
    $lista = is_array($valor) ? $valor : explode('/', (string)$valor);
    $limpios = array_map(fn($a) => mb_substr(trim((string)$a), 0, 200), $lista);
    return array_values(array_unique(array_filter($limpios, fn($a) => $a !== '')));
}

function guardar_autores_libro(PDO $pdo, int $id, array $autores): void
{
    $pdo->prepare('DELETE FROM libro_autor WHERE id_libro = ?')->execute([$id]);
    $relacionar = $pdo->prepare('INSERT INTO libro_autor (id_libro, id_autor, orden) VALUES (?, ?, ?)');
    foreach ($autores as $i => $nombre) {
        $relacionar->execute([$id, catalogo_id('autor', 'nombre', 'id_autor', $nombre), $i + 1]);
    }
}

function datos_libro(array $d): array
{
    requerir_campos($d, ['titulo', 'isbn13', 'codigo_idioma', 'calificacion_promedio']);
    $isbn13 = trim((string)$d['isbn13']);
    if (!preg_match('/^\d{13}$/', $isbn13)) {
        throw new InvalidArgumentException('El ISBN-13 debe tener exactamente 13 dígitos');
    }
    $calificacion = decimal($d['calificacion_promedio']);
    if ($calificacion === null || $calificacion < 0 || $calificacion > 5) {
        throw new InvalidArgumentException('La calificación debe estar entre 0 y 5');
    }
    $fecha = fecha_iso($d['fecha_publicacion'] ?? null);
    if ($fecha === false) {
        throw new InvalidArgumentException('La fecha de publicación no es válida (AAAA-MM-DD)');
    }
    $paginas = isset($d['num_paginas']) && $d['num_paginas'] !== '' ? entero($d['num_paginas']) : null;
    return [
        texto($d['titulo'], 300),
        texto($d['isbn'] ?? '', 20) ?: null,
        $isbn13,
        texto($d['codigo_idioma'], 10),
        $paginas,
        round($calificacion, 2),
        max(0, entero($d['cantidad_calificaciones'] ?? 0) ?? 0),
        max(0, entero($d['cantidad_resenas'] ?? 0) ?? 0),
        $fecha,
        texto($d['editorial'] ?? '', 150) ?: null,
    ];
}

ejecutar_api(function () {
    $pdo = conexion();
    $metodo = $_SERVER['REQUEST_METHOD'];

    if ($metodo === 'GET') {
        requerir_sesion('libros.consultar');
        $seleccion = 'SELECT l.id_libro, l.titulo, l.isbn, l.isbn13, l.codigo_idioma, l.num_paginas,
                l.calificacion_promedio, l.cantidad_calificaciones, l.cantidad_resenas, l.fecha_publicacion,
                l.anio_publicacion, ed.nombre AS editorial, (
                    SELECT GROUP_CONCAT(a.nombre ORDER BY la.orden SEPARATOR \' / \')
                    FROM libro_autor la JOIN autor a ON a.id_autor = la.id_autor
                    WHERE la.id_libro = l.id_libro) AS autores
             FROM libro l LEFT JOIN editorial ed ON ed.id_editorial = l.id_editorial';

        if (isset($_GET['id'])) {
            $consulta = $pdo->prepare($seleccion . ' WHERE l.id_libro = ?');
            $consulta->execute([entero($_GET['id'])]);
            $libro = $consulta->fetch();
            if (!$libro) {
                error_api('Libro no encontrado', 404);
            }
            ok_api(['libro' => $libro]);
        }

        [$condicion, $params] = filtros_sql([
            'q' => ['(l.titulo LIKE ? OR EXISTS (SELECT 1 FROM libro_autor la2 JOIN autor a2 ON a2.id_autor = la2.id_autor WHERE la2.id_libro = l.id_libro AND a2.nombre LIKE ?))', 'like'],
            'rating_min' => ['l.calificacion_promedio >= ?', 'decimal'],
            'rating_max' => ['l.calificacion_promedio <= ?', 'decimal'],
            'anio_desde' => ['l.anio_publicacion >= ?', 'entero'],
            'anio_hasta' => ['l.anio_publicacion <= ?', 'entero'],
            'fecha_desde' => ['l.fecha_publicacion >= ?', 'fecha'],
            'fecha_hasta' => ['l.fecha_publicacion <= ?', 'fecha'],
            'editorial' => ['ed.nombre LIKE ?', 'like'],
            'idioma' => ['l.codigo_idioma LIKE ?', 'like'],
            'paginas_min' => ['l.num_paginas >= ?', 'entero'],
            'paginas_max' => ['l.num_paginas <= ?', 'entero'],
        ], $_GET);
        $orden = orden_columna([
            'titulo' => 'l.titulo',
            'calificacion' => 'l.calificacion_promedio',
            'resenas' => 'l.cantidad_resenas',
            'anio' => 'l.anio_publicacion',
            'paginas' => 'l.num_paginas',
        ], $_GET['orden'] ?? 'titulo', 'l.titulo');
        $sentido = orden_sql($_GET['dir'] ?? 'asc');
        if (($_GET['exportar'] ?? '') === 'csv') {
            $exportacion = $pdo->prepare($seleccion . $condicion . " ORDER BY $orden $sentido");
            $exportacion->execute($params);
            $filasCsv = array_map(fn($l) => [
                $l['isbn13'], $l['titulo'], $l['autores'], $l['editorial'], $l['codigo_idioma'], $l['num_paginas'],
                $l['calificacion_promedio'], $l['cantidad_calificaciones'], $l['cantidad_resenas'], $l['fecha_publicacion'],
            ], $exportacion->fetchAll());
            enviar_csv('libros', ['ISBN-13', 'Título', 'Autores', 'Editorial', 'Idioma', 'Páginas', 'Calificación', 'Calificaciones', 'Reseñas', 'Fecha publicación'], $filasCsv);
        }
        $total = contar_registros(
            $pdo,
            'SELECT COUNT(*) FROM libro l LEFT JOIN editorial ed ON ed.id_editorial = l.id_editorial' . $condicion,
            $params
        );
        $pagina = pagina_actual();
        $filas = consultar_paginado(
            $pdo,
            $seleccion . $condicion . " ORDER BY $orden $sentido LIMIT ? OFFSET ?",
            $params,
            LIBROS_POR_PAGINA,
            ($pagina - 1) * LIBROS_POR_PAGINA
        );
        ok_api([
            'libros' => $filas,
            'total' => $total,
            'pagina' => $pagina,
            'paginas' => max(1, (int)ceil($total / LIBROS_POR_PAGINA)),
        ]);
    }

    requerir_sesion('libros.editar');

    if ($metodo === 'POST') {
        $d = entrada();
        $v = datos_libro($d);
        $autores = autores_lista($d['autores'] ?? '');
        $pdo->beginTransaction();
        $id = (int)$pdo->query('SELECT COALESCE(MAX(id_libro), 0) + 1 FROM libro')->fetchColumn();
        $editorial = $v[9] !== null ? catalogo_id('editorial', 'nombre', 'id_editorial', $v[9]) : null;
        $pdo->prepare(
            'INSERT INTO libro (id_libro, titulo, isbn, isbn13, codigo_idioma, num_paginas, calificacion_promedio,
                cantidad_calificaciones, cantidad_resenas, fecha_publicacion, id_editorial)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([$id, $v[0], $v[1], $v[2], $v[3], $v[4], $v[5], $v[6], $v[7], $v[8], $editorial]);
        guardar_autores_libro($pdo, $id, $autores);
        $pdo->commit();
        auditar('INSERT', 'libros', (string)$id, "Libro creado: {$v[0]}");
        ok_api(['id' => $id], 'Libro registrado correctamente');
    }

    if ($metodo === 'PUT') {
        $d = entrada();
        requerir_campos($d, ['id_libro']);
        $id = entero($d['id_libro']);
        $v = datos_libro($d);
        $autores = autores_lista($d['autores'] ?? '');
        $pdo->beginTransaction();
        $editorial = $v[9] !== null ? catalogo_id('editorial', 'nombre', 'id_editorial', $v[9]) : null;
        $pdo->prepare(
            'UPDATE libro SET titulo = ?, isbn = ?, isbn13 = ?, codigo_idioma = ?, num_paginas = ?, calificacion_promedio = ?,
                cantidad_calificaciones = ?, cantidad_resenas = ?, fecha_publicacion = ?, id_editorial = ?
             WHERE id_libro = ?'
        )->execute([$v[0], $v[1], $v[2], $v[3], $v[4], $v[5], $v[6], $v[7], $v[8], $editorial, $id]);
        guardar_autores_libro($pdo, $id, $autores);
        $pdo->commit();
        auditar('UPDATE', 'libros', (string)$id, "Libro actualizado: {$v[0]}");
        ok_api([], 'Libro actualizado correctamente');
    }

    if ($metodo === 'DELETE') {
        $id = entero($_GET['id'] ?? null);
        $pdo->prepare('DELETE FROM libro WHERE id_libro = ?')->execute([$id]);
        auditar('DELETE', 'libros', (string)$id, 'Libro eliminado');
        ok_api([], 'Libro eliminado correctamente');
    }

    error_api('Método HTTP no permitido', 405);
});
