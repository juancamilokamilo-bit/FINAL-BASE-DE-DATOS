<?php
declare(strict_types=1);

const DB_HOST = 'localhost';
const DB_PUERTO = 3306;
const DB_NOMBRE = 'entrecol';
const DB_USUARIO = 'entrecol_app';
const DB_CLAVE = 'EntreCOL_App2026!';
const APP_NOMBRE = 'EntreCOL+';
const APP_CLAVE_CIFRADO = '447204e02babcf344c907b1b6cf33fb0dac451cdc99a21052663758cd2f782a6';
const CAPTCHA_EXPIRA_SEGUNDOS = 300;
const INTENTOS_MAXIMOS = 5;
const BLOQUEO_MINUTOS = 15;
const PENDIENTE_2FA_SEGUNDOS = 300;
const TAMANO_MAXIMO_ARCHIVO = 20971520;

function conexion(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PUERTO . ';dbname=' . DB_NOMBRE . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USUARIO, DB_CLAVE, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
    return $pdo;
}
